#!/bin/bash
# ══════════════════════════════════════════
# LogistiX Build Script
# Combines all src/ files into a single HTML
# Usage: ./build.sh
# Output: /mnt/user-data/outputs/logistix.html
# ══════════════════════════════════════════

DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="/mnt/user-data/outputs/logistix.html"

cat "$DIR/src/template_head.html"

echo "<style>"
cat "$DIR/src/css/main.css"
echo "</style>"
echo "</head>"

cat "$DIR/src/template_body.html"

echo "<script>"
# JS in dependency order
cat "$DIR/src/js/data/cities.js"
cat "$DIR/src/js/data/constants.js"
cat "$DIR/src/js/helpers.js"
cat "$DIR/src/js/game/state.js"
cat "$DIR/src/js/game/cache.js"
cat "$DIR/src/js/game/quests.js"
cat "$DIR/src/js/game/actions.js"
cat "$DIR/src/js/game/alliance.js"
cat "$DIR/src/js/game/tick.js"
cat "$DIR/src/js/ui/map.js"
cat "$DIR/src/js/ui/search.js"
# UI modules (split from render.js for maintainability)
cat "$DIR/src/js/ui/core.js"        # Globals, view toggle
cat "$DIR/src/js/ui/dashboard.js"   # renDash()
cat "$DIR/src/js/ui/computer.js"    # openComputer, ren(), ua(), uhud()
cat "$DIR/src/js/ui/tips.js"        # TAB_TIPS, tipBtn, tabHead
cat "$DIR/src/js/ui/terminal.js"    # renComp(), explorer rendering
cat "$DIR/src/js/ui/missions.js"    # compMissions
cat "$DIR/src/js/ui/dealer.js"      # compDealer (buy/sell)
cat "$DIR/src/js/ui/fleet.js"       # compFleet, send popups
cat "$DIR/src/js/ui/logistics.js"   # compLogistics, compOrders
cat "$DIR/src/js/ui/inventory.js"   # compInventory, compMarket
cat "$DIR/src/js/ui/routes.js"      # compRoutes, compTransfer, compStanding
cat "$DIR/src/js/ui/buildings.js"   # compBuildings, compInfra
cat "$DIR/src/js/ui/popups.js"      # showProfile, showLeaderboard
cat "$DIR/src/js/ui/wiki.js"        # showWiki
cat "$DIR/src/js/ui/alliance_ui.js" # compAlliance, toast, vehicles overview
cat "$DIR/src/js/game/admin.js"
cat "$DIR/src/js/init.js"
echo "</script>"
echo "</body></html>"
