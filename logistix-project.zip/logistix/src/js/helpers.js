// ══════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════

const ALLCITIES=DB.map(d=>({name:d[0],co:d[1],pop:d[2],lat:d[3],lng:d[4],harbor:d[5],airport:d[6],rail:d[2]>80000?1:0,_s:(d[0]+' '+d[1]).toLowerCase(),id:d[0].toLowerCase().replace(/[^a-z0-9äöüß]/g,'')}));
function searchCities(q){const ql=q.toLowerCase();return ALLCITIES.filter(c=>c._s.includes(ql)).sort((a,b)=>{const ai=a._s.indexOf(ql),bi=b._s.indexOf(ql);if(ai===0&&bi!==0)return-1;if(bi===0&&ai!==0)return 1;return b.pop-a.pop}).slice(0,12)}

const hav=(a,b,c,d)=>{const R=6371,x=(c-a)*Math.PI/180,y=(d-b)*Math.PI/180,z=Math.sin(x/2)**2+Math.cos(a*Math.PI/180)*Math.cos(c*Math.PI/180)*Math.sin(y/2)**2;return R*2*Math.atan2(Math.sqrt(z),Math.sqrt(1-z))};
const fmt=n=>n.toLocaleString('de-DE',{style:'currency',currency:'EUR',maximumFractionDigits:0});
const cSz=p=>p>10e6?'Megastadt':p>1e6?'Metropole':p>1e5?'Großstadt':p>2e4?'Mittelstadt':p>5000?'Kleinstadt':'Dorf';
const cSzIcon=p=>p>10e6?'🌐':p>1e6?'🌃':p>1e5?'🌆':p>2e4?'🏙️':p>5000?'🏘️':'🏡';
const mxB=p=>p>10e6?10:p>1e6?7:p>1e5?5:p>2e4?4:p>5000?3:2;
const uid=()=>'i'+Date.now()+Math.random().toString(36).substr(2,5);
const tripT=(a,b,s)=>{if(!a||!b)return 999;return Math.max(5,Math.round(hav(a.lat,a.lng,b.lat,b.lng)/s*TF))};
function ftime(s){if(s<60)return s+'s';if(s<3600)return Math.floor(s/60)+'m';return Math.floor(s/3600)+'h'+Math.floor((s%3600)/60)+'m'}
function fdist(a,b){return Math.round(hav(a.lat,a.lng,b.lat,b.lng))}
function unlockCost(lat,lng,pop){let md=99999;cities.forEach(c=>{const d=hav(c.lat,c.lng,lat,lng);if(d<md)md=d});return Math.max(1000,1000+Math.round(md*5)+Math.round((pop||50000)/50))}

// Company value = cash + vehicles + buildings + infra + stored goods
function companyValue(){
  if(!G)return 0;
  let val=G.money;
  // Vehicles (current market value = 70% of buy price + wagon upgrades)
  G.vehs.forEach(v=>{const vt=VT[v.type];if(vt)val+=Math.floor(vt.price*.7);if(v.wagons)val+=v.wagons*Math.floor(WAGON_UPGRADE.baseCost*.5)});
  // Buildings (50% of build price + upgrade investments)
  Object.values(G.blds).forEach(bs=>bs.forEach(b=>{const d=BLD[b.type];if(d)val+=Math.floor(d.price*.5);if(b.ups)Object.entries(b.ups).forEach(([track,lvl])=>{for(let i=0;i<lvl;i++)val+=Math.floor(upCost(track,i)*.4)})}));
  // Infrastructure (60% of build price)
  if(G.infra)Object.values(G.infra).forEach(arr=>arr.forEach(i=>{const d=INFRA[i.type];if(d)val+=Math.floor(d.price*.6)}));
  // Stored goods (at base price)
  Object.values(G.stor).forEach(s=>Object.entries(s).forEach(([g,a])=>{if(GOODS[g])val+=a*GOODS[g].bp}));
  return val;
}

// Track supply for market pricing
function trackSupply(good,amt){if(!G||!G.supplyTrack)return;G.supplyTrack[good]=(G.supplyTrack[good]||0)+amt}
