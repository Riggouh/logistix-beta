// ═══ MULTI-DASHBOARD SYSTEM ═══
const DASHBOARDS=[
  {id:'hq',name:'HQ',em:'🧭',desc:'CEO-Übersicht'},
  {id:'orders',name:'Aufträge',em:'📋',desc:'Aktive & offene Aufträge'},
  {id:'market',name:'Markt',em:'📊',desc:'Preise & Events'},
  {id:'production',name:'Produktion',em:'🏭',desc:'Gebäude & Effizienz'},
  {id:'logistics',name:'Logistik',em:'🚚',desc:'Fahrzeuge & Routen'},
  {id:'finance',name:'Finanzen',em:'💰',desc:'Einnahmen & Ausgaben'},
  {id:'inventory',name:'Lager',em:'📦',desc:'Warenbestand'},
  {id:'map',name:'Karte',em:'🗺️',desc:'Strategische Übersicht'},
  {id:'analytics',name:'Analyse',em:'🔬',desc:'KPIs & Performance'},
  {id:'alerts',name:'Alerts',em:'🔔',desc:'Probleme & Chancen'},
  {id:'alliance',name:'Allianz',em:'🤝',desc:'Allianz-Übersicht'},
];
if(!window._dashTab)window._dashTab='hq';

function renDash(){
  const el=document.getElementById('dashBody');if(!el||!G)return;
  let h='<div class="dash-search" id="dashSearchSlot"></div>';
  // Dashboard tabs
  h+='<div style="display:flex;gap:3px;flex-wrap:wrap;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--bd)">';
  DASHBOARDS.forEach(d=>{
    if(d.id==='alliance'&&!G.alliance)return;
    const active=window._dashTab===d.id;
    h+='<button style="padding:4px 10px;border-radius:8px;border:1px solid '+(active?'var(--a)':'var(--bd)')+';background:'+(active?'rgba(61,214,140,.1)':'transparent')+';color:'+(active?'var(--a)':'var(--td)')+';font-size:11px;font-family:var(--mono);cursor:pointer;transition:.15s" onclick="window._dashTab=\''+d.id+'\';renDash()">'+d.em+' '+d.name+'</button>'});
  h+='</div>';

  const tab=window._dashTab||'hq';
  try{
    if(tab==='hq')h+=dashHQ();
    else if(tab==='orders')h+=dashOrders();
    else if(tab==='market')h+=dashMarket();
    else if(tab==='production')h+=dashProduction();
    else if(tab==='logistics')h+=dashLogistics();
    else if(tab==='finance')h+=dashFinance();
    else if(tab==='inventory')h+=dashInventory();
    else if(tab==='map')h+=dashMap();
    else if(tab==='analytics')h+=dashAnalytics();
    else if(tab==='alerts')h+=dashAlerts();
    else if(tab==='alliance')h+=dashAlliance();
    else h+=dashHQ();
  }catch(e){
    console.error('Dashboard render error ('+tab+'):',e);
    h+='<div style="padding:20px;color:var(--r)">⚠️ Dashboard-Fehler: '+e.message+'<br><button class="btn sm" style="margin-top:8px" onclick="window._dashTab=\'hq\';renDash()">↩️ Zurück zum HQ</button></div>';
  }

  const swEl2=document.getElementById('sw');
  el.innerHTML=h;
  const ds=document.getElementById('dashSearchSlot');
  if(ds&&swEl2)ds.appendChild(swEl2);
}

// ═══ HQ DASHBOARD ═══
function dashHQ(){
  let h='<div class="dash-grid">';
  const lvl=playerLvl();const li=LEVELS[lvl-1];const cv=companyValue();
  // Financials
  h+='<div class="dash-card"><div class="dash-card-title">'+li.em+' Level '+lvl+' · '+li.name+'</div>';
  h+='<div class="dash-big">'+fmt(cv)+'</div><div class="dash-sub">Unternehmenswert</div>';
  h+='<div class="dash-big sec" style="font-size:16px;margin-top:4px">'+fmt(G.money)+'</div><div class="dash-sub">Kontostand</div>';
  h+='<div style="margin-top:4px;font-size:10px;color:var(--td)">💰 '+fmt(G.earned)+' verdient · 📦 '+(G.dels||0)+' Lieferungen</div>';
  // Level requirements
  if(lvl<LEVELS.length){
    const next=LEVELS[lvl]; // next level (0-indexed: lvl=1 → LEVELS[1] is lvl 2)
    const lu=canLevelUp();
    h+='<div style="margin-top:6px;padding:6px 8px;border-radius:8px;border:1px solid var(--bd);background:rgba(255,255,255,.02)">';
    h+='<div style="font-size:10px;color:var(--td);margin-bottom:4px">⬆️ <b>Level '+(lvl+1)+' · '+next.em+' '+next.name+'</b></div>';
    // Requirements with progress bars
    const reqs=[
      {label:'Lieferungen',cur:G.dels||0,need:next.dels,em:'📦'},
      {label:'Unternehmenswert',cur:companyValue(),need:next.value,em:'💰',fmt:true},
      {label:'Standorte',cur:cities.length,need:next.cities,em:'🏙️'},
      {label:'Kosten',cur:G.money,need:next.cost,em:'🪙',fmt:true},
    ];
    reqs.forEach(rq=>{const pct=Math.min(rq.cur/Math.max(rq.need,1),1);const done=rq.cur>=rq.need;
      h+='<div style="margin:3px 0"><div style="display:flex;justify-content:space-between;font-size:9px;color:'+(done?'var(--a)':'var(--td)')+'">';
      h+='<span>'+rq.em+' '+rq.label+'</span><span>'+(rq.fmt?fmt(rq.cur)+'/'+fmt(rq.need):rq.cur+'/'+rq.need)+(done?' ✅':'')+'</span></div>';
      h+='<div class="pb" style="height:3px;margin-top:1px"><div class="pf" style="width:'+pct*100+'%;background:'+(done?'var(--a)':'var(--go)')+'"></div></div></div>'});
    h+='<div class="sub" style="margin-top:3px">🆕 '+next.desc+'</div>';
    if(lu&&!lu.blocked)h+='<button class="btn sm" style="margin-top:4px;background:var(--a);color:var(--bg);border-color:var(--a)" onclick="doLevelUp()">⬆️ Level Up! (-'+fmt(next.cost)+')</button>';
    h+='</div>';}
  // Quick production summary
  let prodActive=0,prodIdle=0;
  cities.forEach(c=>{(G.blds[c.id]||[]).forEach(b=>{if(b.active!==false)prodActive++;else prodIdle++})});
  h+='<div class="dash-card-title" style="margin-top:8px">Produktion</div>';
  h+='<div style="display:flex;gap:8px;font-size:11px"><span style="color:var(--a)">🟢 '+prodActive+' aktiv</span><span style="color:var(--td)">⏸ '+prodIdle+' idle</span></div>';
  h+='</div>';

  // Alerts card
  h+='<div class="dash-card"><div class="dash-card-title">⚠️ Aufmerksamkeit nötig</div>';
  const alerts=[];
  // Maintenance alerts
  const needsMaint=G.vehs.filter(v=>vehCondition(v)<30);
  if(needsMaint.length)alerts.push({em:'🔧',text:needsMaint.length+' Fahrzeug'+(needsMaint.length>1?'e':'')+' unter 30% Zustand',act:"openComputer();setCompTab('fleet');G.fleetSub='maint'"});
  // Full storage
  cities.forEach(c=>{const cap=cityCap(c.id);const used=Object.values(G.stor[c.id]||{}).reduce((s,v)=>s+v,0);if(used>=cap*0.9)alerts.push({em:'📦',text:c.name+': Lager '+Math.round(used/cap*100)+'% voll',act:"selectLocation('"+c.id+"');openComputer();setCompTab('inventory')"})});
  // Expiring orders
  G.orders.filter(o=>o.acc).forEach(o=>{const rem=o.tl-(G.tick-o.born);if(rem<120)alerts.push({em:'⏱',text:'Auftrag '+fmtOrd(o.num)+' läuft gleich ab!',act:"openComputer();setCompTab('logistics')"})});
  // Idle vehicles
  const idleCount=G.vehs.filter(v=>v.st==='idle').length;
  const totalV=G.vehs.length;
  if(idleCount>totalV*0.6&&totalV>2)alerts.push({em:'🚛',text:idleCount+'/'+totalV+' Fahrzeuge untätig',act:"window._dashTab='logistics';renDash()"});
  // Unaccepted orders
  const openOrds=G.orders.filter(o=>!o.acc);
  if(openOrds.length>3)alerts.push({em:'📋',text:openOrds.length+' Aufträge warten',act:"openComputer();setCompTab('logistics')"});
  if(!alerts.length)h+='<div class="sub" style="padding:8px;text-align:center;color:var(--a)">✅ Alles läuft rund!</div>';
  alerts.slice(0,5).forEach(a=>{
    h+='<div style="padding:4px 0;font-size:11px;cursor:pointer;border-bottom:1px solid var(--bd)" onclick="'+a.act+'"><span>'+a.em+' '+a.text+' <span style="color:var(--a)">→</span></span></div>'});
  h+='</div>';

  // Orders + Vehicles summary
  h+='<div class="dash-card"><div class="dash-card-title">📋 Aufträge</div>';
  const runOrd=G.orders.filter(o=>o.acc&&G.vehs.find(v=>v.cargo?.oid===o.id));
  h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px;text-align:center;margin-bottom:6px">';
  h+='<div><div style="font-size:18px;font-family:var(--mono);color:var(--go)">'+runOrd.length+'</div><div class="dash-sub">Laufend</div></div>';
  h+='<div><div style="font-size:18px;font-family:var(--mono);color:var(--bl)">'+G.orders.filter(o=>o.acc).length+'</div><div class="dash-sub">Aktiv</div></div>';
  h+='<div><div style="font-size:18px;font-family:var(--mono);color:var(--td)">'+openOrds.length+'</div><div class="dash-sub">Offen</div></div></div>';
  runOrd.slice(0,3).forEach(o=>{const v=G.vehs.find(x=>x.cargo?.oid===o.id);if(!v)return;const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
    const vt=VT[v.type],tn=tripT(f,t,vt.spd),pct=Math.min(v.prog/tn,1);
    h+='<div class="sub" style="padding:2px 0">'+vt.em+' '+(GOODS[o.good]?.em||'')+' '+f.name+'→'+t.name+' <span style="color:var(--a)">'+Math.floor(pct*100)+'%</span> '+ftime(Math.max(0,tn-v.prog))+'</div>'});
  if(openOrds.length){h+='<div class="sub" style="margin-top:3px;font-size:10px;font-weight:600">Offen:</div>';
    openOrds.slice(0,2).forEach(o=>{const rem=o.tl-(G.tick-(o.born||0));
      h+='<div class="sub" style="padding:1px 0;'+(rem<120?'color:var(--r)':'')+'">'+(GOODS[o.good]?.em||'')+' '+o.amt+'× '+fmt(o.rew)+' ⏱'+ftime(Math.max(0,rem))+'</div>'});}
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'logistics\')">→ Logistik</button></div>';

  // Standorte + Vehicles
  h+='<div class="dash-card"><div class="dash-card-title">🏙️ Standorte · '+cities.length+'</div>';
  cities.slice(0,6).forEach(c=>{const bCount=(G.blds[c.id]||[]).length;const vCount=G.vehs.filter(v=>v.loc===c.id&&v.st==='idle').length;
    h+='<div style="display:flex;justify-content:space-between;padding:2px 0;font-size:11px;border-bottom:1px solid var(--bd);cursor:pointer" onclick="selectLocation(\''+c.id+'\');toggleView()"><span>📍 '+c.name+'</span><span class="sub">🏭'+bCount+' 🚛'+vCount+'</span></div>'});
  if(cities.length>6)h+='<div class="sub" style="margin-top:3px">+'+(cities.length-6)+' weitere</div>';
  h+='<button class="btn sm" style="margin-top:4px" onclick="toggleView()">🗺️ Karte öffnen</button>';
  h+='<div class="dash-card-title" style="margin-top:8px">🚛 Fahrzeuge · '+G.vehs.length+'</div>';
  const idle=G.vehs.filter(v=>v.st==='idle').length;const moving=G.vehs.filter(v=>v.st==='moving').length;
  h+='<div style="display:flex;gap:6px;font-size:11px"><span style="color:var(--a)">🟢 '+idle+' frei</span><span style="color:var(--go)">🔶 '+moving+' unterwegs</span></div>';
  h+='</div>';

  // Events
  const evts=typeof activeEvents==='function'?activeEvents():[];
  h+='<div class="dash-card"><div class="dash-card-title">⚡ Events & Markt</div>';
  if(evts.length){evts.forEach(e=>{const def=EVENTS.find(x=>x.id===e.id);if(!def)return;
    h+='<div style="padding:3px 0;font-size:11px"><span style="color:var(--go)">'+def.icon+' '+def.name+'</span> <span class="sub">'+ftime(e.endTick-G.tick)+'</span></div>'});}
  else h+='<div class="sub" style="opacity:.5">Keine aktiven Events</div>';
  const myRegs=new Set();cities.forEach(c=>myRegs.add(getRegion((c.co||'').toUpperCase())));
  const topG=Object.keys(BASE_PRICES).sort((a2,b)=>(BASE_PRICES[b]||0)-(BASE_PRICES[a2]||0)).slice(0,4);
  h+='<div class="dash-card-title" style="margin-top:6px">Top-Preise</div>';
  topG.forEach(g=>{const gd=GOODS[g];const mP=Math.max(...[...myRegs].map(r=>marketPrice(g,r)));
    h+='<div class="sub">'+(gd?.em||'')+' '+(gd?.name||'')+': <span style="color:var(--a)">'+fmt(mP)+'</span></div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="window._dashTab=\'market\';renDash()">→ Markt</button></div>';

  h+='</div>';return h;
}

// ═══ ORDERS DASHBOARD ═══
function dashOrders(){
  let h='<div class="dash-grid">';
  const acc=G.orders.filter(o=>o.acc);const open=G.orders.filter(o=>!o.acc);
  // Active
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📋 Aktive Aufträge · '+acc.length+'</div>';
  if(!acc.length)h+='<div class="sub" style="padding:6px;text-align:center">Keine aktiven Aufträge</div>';
  acc.forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
    const v=G.vehs.find(x=>x.cargo?.oid===o.id&&x.st==='moving');
    const del=o.delivered||0;const pct=del/o.amt;
    h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>'+(GOODS[o.good]?.em||'')+' '+o.amt+'× '+f.name+'→'+t.name+'</span><span style="font-family:var(--mono);color:var(--a)">'+fmt(o.rew)+'</span></div>';
    h+='<div class="pb" style="height:3px;margin:2px 0"><div class="pf" style="width:'+pct*100+'%"></div></div>';
    h+='<div class="sub">✅'+del+'/'+o.amt+(v?' · 🚛'+Math.floor(Math.min(v.prog/(tripT(f,t,VT[v.type].spd)||1),1)*100)+'%':'')+'</div></div>'});
  h+='</div>';
  // Available
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📬 Verfügbar · '+open.length+'</div>';
  if(!open.length)h+='<div class="sub" style="padding:6px;text-align:center">Keine offenen Aufträge</div>';
  open.slice(0,8).forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
    const inS=(G.stor[o.from]?.[o.good]||0);const tl=Math.max(0,o.tl-(G.tick-o.born));
    const avl=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from).length;
    h+='<div class="crd" style="padding:4px 8px;'+(o.type==='express'?'border-left:3px solid var(--go)':'')+'"><div class="rw"><span>'+(o.type==='express'?'⚡ ':'')+(GOODS[o.good]?.em||'')+' '+o.amt+'× '+f.name+'→'+t.name+'</span><span style="font-family:var(--mono);color:var(--a)">'+fmt(o.rew)+'</span></div>';
    h+='<div class="sub">📦'+inS+'/'+o.amt+' · 🚛'+avl+' · ⏱'+ftime(tl)+'</div></div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'logistics\')">→ Terminal</button></div>';
  h+='</div>';return h;
}

// ═══ MARKET DASHBOARD ═══
function dashMarket(){
  let h='<div class="dash-grid">';
  const myRegs=new Set();cities.forEach(c=>myRegs.add(getRegion((c.co||'').toUpperCase())));const regs=[...myRegs];
  const gm=eventEffect('globalMult')||1;
  // Events
  const evts=typeof activeEvents==='function'?activeEvents():[];
  h+='<div class="dash-card"><div class="dash-card-title">⚡ Aktive Events</div>';
  if(evts.length){evts.forEach(e=>{const def=EVENTS.find(x=>x.id===e.id);if(!def)return;
    h+='<div style="padding:4px 0;font-size:11px">'+def.icon+' <b>'+def.name+'</b><div class="sub">'+def.desc+' · '+ftime(e.endTick-G.tick)+'</div></div>'});}
  else h+='<div class="sub" style="padding:8px;text-align:center">Keine Events aktiv</div>';
  h+='</div>';
  // Top prices
  h+='<div class="dash-card"><div class="dash-card-title">💰 Höchste Preise</div>';
  const priceList=Object.keys(BASE_PRICES).map(g=>{const maxP=Math.max(...regs.map(r=>marketPrice(g,r)));return{g,p:maxP}}).sort((a,b)=>b.p-a.p);
  priceList.slice(0,10).forEach(({g,p})=>{const gd=GOODS[g];const bp=BASE_PRICES[g]||100;const diff=Math.round((p/bp-1)*100);
    h+='<div style="display:flex;justify-content:space-between;padding:2px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>'+(gd?.em||'')+' '+(gd?.name||g)+'</span><span style="font-family:var(--mono)"><span style="color:var(--a)">'+fmt(p)+'</span> <span style="color:'+(diff>10?'var(--a)':'var(--td)')+';font-size:9px">'+(diff>0?'+':'')+diff+'%</span></span></div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'market\')">→ Markt</button></div>';
  // Regional
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">🌍 Regionale Preise</div>';
  h+='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:10px"><tr><th style="text-align:left;padding:3px 4px;color:var(--td)">Ware</th>';
  regs.forEach(r=>{const ri=REGIONS[r];h+='<th style="padding:3px 4px;color:var(--td)">'+(ri?.em||'')+' '+(ri?.name||r)+'</th>'});
  h+='</tr>';
  Object.keys(BASE_PRICES).slice(0,12).forEach(g=>{const gd=GOODS[g];
    h+='<tr style="border-bottom:1px solid var(--bd)"><td style="padding:2px 4px">'+(gd?.em||'')+' '+(gd?.name||g)+'</td>';
    regs.forEach(r=>{const p=marketPrice(g,r);const bp=BASE_PRICES[g];const diff=Math.round((p/bp-1)*100);
      h+='<td style="text-align:center;padding:2px 4px;color:'+(diff>15?'var(--a)':diff<-10?'var(--r)':'var(--td)')+'">'+fmt(p)+'</td>'});
    h+='</tr>'});
  h+='</table></div></div>';
  h+='</div>';return h;
}

// ═══ PRODUCTION DASHBOARD ═══
function dashProduction(){
  let h='<div class="dash-grid">';
  const allBlds=[];cities.forEach(c=>{(G.blds[c.id]||[]).forEach(b=>{allBlds.push({...b,city:c.id,cityName:c.name})})});
  // Summary
  h+='<div class="dash-card"><div class="dash-card-title">🏭 Produktionsübersicht</div>';
  h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:6px">';
  const active=allBlds.filter(b=>b.active!==false).length;
  h+='<div class="crd" style="text-align:center;padding:6px"><div style="font-size:18px;font-family:var(--mono);color:var(--a)">'+active+'</div><div class="dash-sub">Aktiv</div></div>';
  h+='<div class="crd" style="text-align:center;padding:6px"><div style="font-size:18px;font-family:var(--mono)">'+allBlds.length+'</div><div class="dash-sub">Gesamt</div></div></div>';
  // By type
  const byType={};allBlds.forEach(b=>{const d=BLD[b.type];if(d){if(!byType[d.cat])byType[d.cat]=0;byType[d.cat]++}});
  Object.entries(byType).forEach(([cat,n])=>{h+='<div class="sub">'+cat+': '+n+'</div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'buildings\')">→ Gebäude</button></div>';
  // Bottlenecks
  h+='<div class="dash-card"><div class="dash-card-title">⚠️ Engpässe</div>';
  const bottlenecks=[];
  allBlds.forEach(b=>{const d=BLD[b.type];if(!d||!d.input)return;
    Object.entries(d.input).forEach(([g,need])=>{const stock=G.stor[b.city]?.[g]||0;
      if(stock<need)bottlenecks.push({city:b.cityName,building:d.name,good:g,have:stock,need})})});
  if(!bottlenecks.length)h+='<div class="sub" style="padding:6px;text-align:center;color:var(--a)">✅ Keine Engpässe</div>';
  bottlenecks.slice(0,6).forEach(bn=>{
    h+='<div style="padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span style="color:var(--r)">'+(GOODS[bn.good]?.em||'')+' '+(GOODS[bn.good]?.name||'')+' fehlt</span> <span class="sub">'+bn.building+' in '+bn.city+' ('+bn.have+'/'+bn.need+')</span></div>'});
  h+='</div>';
  // Per city
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📍 Standorte</div>';
  cities.forEach(c=>{const blds=G.blds[c.id]||[];if(!blds.length)return;
    h+='<div class="crd" style="padding:4px 8px;cursor:pointer" onclick="selectLocation(\''+c.id+'\');openComputer();setCompTab(\'buildings\')">';
    h+='<div class="rw"><span style="font-weight:600">📍 '+c.name+'</span><span class="sub">'+blds.length+' Gebäude</span></div>';
    h+='<div style="display:flex;gap:3px;flex-wrap:wrap;margin-top:2px">';
    blds.forEach(b=>{const d=BLD[b.type];if(d)h+='<span class="tg" style="font-size:9px">'+d.em+' '+d.name+'</span>'});
    h+='</div></div>'});
  h+='</div></div>';return h;
}

// ═══ LOGISTICS DASHBOARD ═══
function dashLogistics(){
  let h='<div class="dash-grid">';
  const idle=G.vehs.filter(v=>v.st==='idle');const moving=G.vehs.filter(v=>v.st==='moving');
  const onOrder=moving.filter(v=>v.cargo?.oid);const onMarket=moving.filter(v=>v.cargo?.market||v.cargo?.allianceDelivery);
  const returning=moving.filter(v=>!v.cargo||v.cargo.returning);
  // Summary
  h+='<div class="dash-card"><div class="dash-card-title">🚛 Flottenübersicht</div>';
  h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px;text-align:center">';
  [['🟢',idle.length,'Frei'],['📋',onOrder.length,'Im Auftrag'],['💰',onMarket.length,'Markt/Allianz']].forEach(([em,n,l])=>{
    h+='<div class="crd" style="padding:6px"><div style="font-size:16px;font-family:var(--mono);color:var(--a)">'+n+'</div><div class="dash-sub">'+em+' '+l+'</div></div>'});
  h+='</div>';
  // Utilization
  const util=G.vehs.length?Math.round(moving.length/G.vehs.length*100):0;
  h+='<div style="margin-top:6px"><div class="sub">Auslastung: <b style="color:var(--a)">'+util+'%</b></div>';
  h+='<div class="pb" style="height:6px;margin-top:3px"><div class="pf" style="width:'+util+'%"></div></div></div>';
  if(returning.length)h+='<div class="sub" style="margin-top:4px;color:var(--td)">🔙 '+returning.length+' auf Rückweg (leer)</div>';
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'fleet\')">→ Fuhrpark</button></div>';
  // Active routes
  h+='<div class="dash-card"><div class="dash-card-title">🗺️ Aktive Routen · '+moving.length+'</div>';
  if(!moving.length)h+='<div class="sub" style="padding:6px;text-align:center">Keine aktiven Routen</div>';
  moving.slice(0,6).forEach(v=>{const vt=VT[v.type];if(!vt)return;
    const f=Cx(v.rt?.from);const t=Cx(v.rt?.to)||(v.rt?.toLat?{name:v.rt.toName||'?'}:null);if(!f||!t)return;
    const tn=v.rt?.tripTime||tripT(f,t,vt.spd);const pct=Math.min(v.prog/(tn||1),1);
    const isM=v.cargo?.market;const isA=v.cargo?.allianceDelivery;
    h+='<div style="padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><div class="rw"><span>'+vt.em+' '+vehName(v)+(isM?' 💰':isA?' 🤝':'')+'</span><span style="color:var(--a)">'+Math.floor(pct*100)+'%</span></div>';
    h+='<div class="pb" style="height:2px"><div class="pf" style="width:'+pct*100+'%;background:'+(isA?'#a855f7':isM?'var(--go)':'var(--a)')+'"></div></div></div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'logistics\');G.logSub=\'vehicles\'">→ Alle Fahrzeuge</button></div>';
  // By city
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📍 Fahrzeuge pro Standort</div>';
  const byCty={};G.vehs.forEach(v=>{const loc=v.st==='idle'?v.loc:(v.depot||v.loc);if(!byCty[loc])byCty[loc]={idle:0,moving:0};if(v.st==='idle')byCty[loc].idle++;else byCty[loc].moving++});
  Object.entries(byCty).sort((a,b)=>(b[1].idle+b[1].moving)-(a[1].idle+a[1].moving)).forEach(([loc,d])=>{const c=C(loc);if(!c)return;
    h+='<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>📍 '+c.name+'</span><span><span style="color:var(--a)">🟢'+d.idle+'</span> <span style="color:var(--go)">🔶'+d.moving+'</span></span></div>'});
  h+='</div></div>';return h;
}

// ═══ FINANCE DASHBOARD ═══
function dashFinance(){
  let h='<div class="dash-grid">';
  h+='<div class="dash-card"><div class="dash-card-title">💰 Finanzen</div>';
  h+='<div class="dash-big">'+fmt(G.money)+'</div><div class="dash-sub">Kontostand</div>';
  h+='<div style="margin-top:6px"><div class="sub">Gesamtumsatz: <b style="color:var(--a)">'+fmt(G.earned||0)+'</b></div>';
  h+='<div class="sub">Unternehmenswert: <b>'+fmt(companyValue())+'</b></div></div></div>';
  // Revenue breakdown by good
  h+='<div class="dash-card"><div class="dash-card-title">📊 Umsatz nach Ware</div>';
  const gS={};(G.history||[]).forEach(x=>{if(!gS[x.good])gS[x.good]=0;gS[x.good]+=x.rew});
  const sorted=Object.entries(gS).sort((a,b)=>b[1]-a[1]);
  if(!sorted.length)h+='<div class="sub" style="padding:6px;text-align:center">Noch keine Umsätze</div>';
  sorted.slice(0,8).forEach(([g,rev])=>{const gd=GOODS[g];const pct=Math.round(rev/(G.earned||1)*100);
    h+='<div style="padding:2px 0;font-size:11px;border-bottom:1px solid var(--bd)"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||g)+'</span><span style="font-family:var(--mono);color:var(--a)">'+fmt(rev)+' ('+pct+'%)</span></div></div>'});
  h+='</div>';
  // Cost analysis
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📉 Kostenanalyse</div>';
  const bldCost=Object.values(G.blds).flat().reduce((s,b)=>{const d=BLD[b.type];return s+(d?d.price:0)},0);
  const infraCost=Object.values(G.infra||{}).flat().reduce((s,i)=>s+(i.cost||0),0);
  const vehCost2=G.vehs.reduce((s,v)=>{const vt=VT[v.type];return s+(vt?vt.price:0)},0);
  const spent=bldCost+infraCost+vehCost2;
  h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px">';
  [['🏭',fmt(bldCost),'Gebäude'],['🏢',fmt(infraCost),'Infrastruktur'],['🚛',fmt(vehCost2),'Fahrzeuge']].forEach(([em,val,lbl])=>{
    h+='<div class="crd" style="text-align:center;padding:6px"><div style="font-size:14px;font-family:var(--mono)">'+val+'</div><div class="dash-sub">'+em+' '+lbl+'</div></div>'});
  h+='</div>';
  const profit=(G.earned||0)-spent;
  h+='<div style="margin-top:6px;padding:6px;border-radius:8px;background:rgba('+(profit>=0?'61,214,140':'248,113,113')+',.06);border:1px solid rgba('+(profit>=0?'61,214,140':'248,113,113')+',.15)">';
  h+='<div class="rw"><span style="font-weight:600">Netto-Ergebnis</span><span style="font-family:var(--mono);font-weight:700;color:'+(profit>=0?'var(--a)':'var(--r)')+'">'+fmt(profit)+'</span></div></div>';
  h+='</div></div>';return h;
}

// ═══ INVENTORY DASHBOARD ═══
function dashInventory(){
  let h='<div class="dash-grid">';
  const allStock={};let totalItems=0;let totalCap=0;let totalUsed=0;
  cities.forEach(c=>{const cap2=cityCap(c.id);const s=G.stor[c.id]||{};const used=Object.values(s).reduce((s2,v)=>s2+v,0);totalCap+=cap2;totalUsed+=used;
    Object.entries(s).forEach(([g,v])=>{allStock[g]=(allStock[g]||0)+v;totalItems+=v})});
  // Summary
  h+='<div class="dash-card"><div class="dash-card-title">📦 Lagerübersicht</div>';
  h+='<div class="dash-big">'+totalItems+'</div><div class="dash-sub">Waren gesamt</div>';
  const usePct=totalCap?Math.round(totalUsed/totalCap*100):0;
  h+='<div style="margin-top:6px"><div class="sub">Kapazität: '+totalUsed+'/'+totalCap+' ('+usePct+'%)</div>';
  h+='<div class="pb" style="height:6px;margin-top:3px"><div class="pf" style="width:'+usePct+'%;background:'+(usePct>90?'var(--r)':usePct>70?'var(--go)':'var(--a)')+'"></div></div></div>';
  h+='<button class="btn sm" style="margin-top:4px" onclick="openComputer();setCompTab(\'inventory\')">→ Lager</button></div>';
  // All goods
  h+='<div class="dash-card"><div class="dash-card-title">📊 Warenbestand</div>';
  const sorted=Object.entries(allStock).sort((a,b)=>b[1]-a[1]);
  if(!sorted.length)h+='<div class="sub" style="padding:6px;text-align:center">Leer</div>';
  sorted.forEach(([g,amt])=>{const gd=GOODS[g];const bp=BASE_PRICES[g]||gd?.bp||100;
    h+='<div style="display:flex;justify-content:space-between;padding:2px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>'+(gd?.em||'')+' '+(gd?.name||g)+'</span><span><b>'+amt+'×</b> <span style="color:var(--a)">~'+fmt(amt*bp)+'</span></span></div>'});
  h+='</div>';
  // Per city capacity
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">📍 Lager pro Standort</div>';
  cities.forEach(c=>{const cap2=cityCap(c.id);const s=G.stor[c.id]||{};const used=Object.values(s).reduce((s2,v)=>s2+v,0);const pct2=cap2?Math.round(used/cap2*100):0;
    h+='<div style="padding:3px 0;border-bottom:1px solid var(--bd)"><div class="rw" style="font-size:11px"><span>📍 '+c.name+'</span><span>'+used+'/'+cap2+' ('+pct2+'%)</span></div>';
    h+='<div class="pb" style="height:3px;margin-top:2px"><div class="pf" style="width:'+pct2+'%;background:'+(pct2>90?'var(--r)':'var(--a)')+'"></div></div></div>'});
  h+='</div></div>';return h;
}

// ═══ ALLIANCE DASHBOARD ═══
function dashAlliance(){
  let h='<div class="dash-grid">';
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">🤝 Allianz</div>';
  h+='<div class="sub" style="padding:8px;text-align:center">Öffne das Allianz-Terminal für Details</div>';
  h+='<button class="btn full" style="background:rgba(168,85,247,.1);color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="openAlliancePanel()">🤝 Allianz-Terminal öffnen</button></div>';
  h+='</div>';return h;
}

// ═══ MAP/NETWORK DASHBOARD ═══
function dashMap(){
  let h='<div class="dash-grid">';
  // Standorte overview
  h+='<div class="dash-card"><div class="dash-card-title">🏙️ Standorte · '+cities.length+'</div>';
  cities.forEach(c=>{
    const bCount=(G.blds[c.id]||[]).length;const vIdle=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id).length;
    const vMoving=G.vehs.filter(v=>v.st==='moving'&&(v.rt?.from===c.id||v.depot===c.id)).length;
    const stor=G.stor[c.id]||{};const items=Object.values(stor).reduce((s,v)=>s+v,0);const cap=cityCap(c.id);
    const inf=G.infra[c.id]||[];const hasRail=inf.find(i=>i.type==='bahnhof');const hasPort=inf.find(i=>i.type==='hafen');const hasAir=inf.find(i=>i.type==='flughafen');
    h+='<div class="crd" style="padding:5px 8px;cursor:pointer" onclick="selectLocation(\''+c.id+'\');toggleView()">';
    h+='<div class="rw"><span style="font-weight:600">📍 '+c.name+'</span>';
    h+='<span style="font-size:10px">'+(hasRail?'🚉':'')+(hasPort?'⚓':'')+(hasAir?'✈️':'')+'</span></div>';
    h+='<div style="display:flex;gap:8px;font-size:10px;color:var(--td)">';
    h+='<span>🏭'+bCount+'</span><span>🚛'+vIdle+'<span style="color:var(--go)">/'+vMoving+'</span></span>';
    h+='<span>📦'+items+'/'+cap+'</span></div></div>'});
  h+='<button class="btn sm" style="margin-top:4px" onclick="toggleView()">🗺️ Vollbild-Karte</button></div>';

  // Infrastructure overview
  h+='<div class="dash-card"><div class="dash-card-title">🏢 Infrastruktur</div>';
  const infraCount={depot:0,bahnhof:0,hafen:0,flughafen:0,logistikzentrum:0,tankstelle:0};
  cities.forEach(c=>{(G.infra[c.id]||[]).forEach(i=>{if(infraCount[i.type]!==undefined)infraCount[i.type]++})});
  Object.entries(infraCount).forEach(([k,n])=>{const d=typeof INFRA!=='undefined'?INFRA[k]:null;
    if(d)h+='<div style="display:flex;justify-content:space-between;padding:2px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>'+d.em+' '+d.name+'</span><span style="font-family:var(--mono);color:var(--a)">'+n+'×</span></div>'});
  h+='</div>';

  // Active routes map
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title">🗺️ Aktive Verbindungen</div>';
  const routes={};
  G.vehs.filter(v=>v.st==='moving'&&v.rt).forEach(v=>{
    const from=C(v.rt.from)?.name||Cx(v.rt.from)?.name||'?';
    const to=Cx(v.rt.to)?.name||v.rt.toName||'?';
    const key=from+'→'+to;if(!routes[key])routes[key]={count:0,types:new Set()};
    routes[key].count++;routes[key].types.add(VT[v.type]?.em||'🚛')});
  if(!Object.keys(routes).length)h+='<div class="sub" style="padding:6px;text-align:center">Keine aktiven Routen</div>';
  Object.entries(routes).sort((a,b)=>b[1].count-a[1].count).forEach(([route,d])=>{
    h+='<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>'+[...d.types].join('')+' '+route+'</span><span class="tg">'+d.count+'×</span></div>'});
  h+='</div></div>';return h;
}

// ═══ ANALYTICS/PERFORMANCE DASHBOARD ═══
function dashAnalytics(){
  let h='<div class="dash-grid">';
  const hist=G.history||[];
  // KPIs
  const totalDels=G.dels||0;const totalRev=G.earned||0;const totalKm=G.vehs.reduce((s,v)=>s+(v.km||0),0);
  const avgRevPerDel=totalDels?Math.round(totalRev/totalDels):0;
  const avgKmPerDel=totalDels?Math.round(totalKm/totalDels):0;
  const profitPerKm=totalKm?Math.round(totalRev/totalKm):0;
  h+='<div class="dash-card"><div class="dash-card-title">📊 Key Performance Indicators</div>';
  h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">';
  [['📦',totalDels,'Lieferungen'],['💰',fmt(avgRevPerDel),'⌀ pro Lieferung'],['🛣️',avgKmPerDel+' km','⌀ Distanz'],['💵',fmt(profitPerKm)+'/km','Umsatz/km']].forEach(([em,val,lbl])=>{
    h+='<div class="crd" style="text-align:center;padding:6px"><div style="font-size:14px;font-family:var(--mono);color:var(--a)">'+val+'</div><div class="dash-sub">'+em+' '+lbl+'</div></div>'});
  h+='</div></div>';

  // Top routes
  h+='<div class="dash-card"><div class="dash-card-title">🏆 Top-Routen (nach Umsatz)</div>';
  const routeStats={};hist.forEach(x=>{
    const from=C(x.from)?.name||'?';const to=C(x.to)?.name||Cx(x.to)?.name||'Markt';
    const key=from+'→'+to;if(!routeStats[key])routeStats[key]={cnt:0,rev:0};routeStats[key].cnt++;routeStats[key].rev+=x.rew});
  const topRoutes=Object.entries(routeStats).sort((a,b)=>b[1].rev-a[1].rev).slice(0,8);
  if(!topRoutes.length)h+='<div class="sub" style="padding:6px;text-align:center">Noch keine Daten</div>';
  topRoutes.forEach(([route,s],i)=>{
    h+='<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span>'+(i+1)+'. '+route+'</span><span style="font-family:var(--mono)"><span style="color:var(--a)">'+fmt(s.rev)+'</span> <span style="color:var(--td)">'+s.cnt+'×</span></span></div>'});
  h+='</div>';

  // Vehicle efficiency
  h+='<div class="dash-card"><div class="dash-card-title">🚛 Fahrzeug-Effizienz</div>';
  const vehStats={};G.vehs.forEach(v=>{const cat=VT[v.type]?.cat||'?';if(!vehStats[cat])vehStats[cat]={count:0,km:0,idle:0,moving:0};vehStats[cat].count++;vehStats[cat].km+=(v.km||0);if(v.st==='idle')vehStats[cat].idle++;else vehStats[cat].moving++});
  Object.entries(vehStats).forEach(([cat,s])=>{const util=s.count?Math.round(s.moving/s.count*100):0;
    const catName={land:'🚛 Land',rail:'🚆 Schiene',sea:'🚢 See',air:'✈️ Luft'}[cat]||cat;
    h+='<div style="padding:4px 0;border-bottom:1px solid var(--bd)"><div class="rw" style="font-size:11px"><span>'+catName+' ('+s.count+')</span><span>Auslastung: <b style="color:var(--a)">'+util+'%</b></span></div>';
    h+='<div class="pb" style="height:3px;margin-top:2px"><div class="pf" style="width:'+util+'%"></div></div>';
    h+='<div class="sub">'+s.km.toLocaleString('de-DE')+' km gefahren</div></div>'});
  h+='</div>';

  // Bottleneck scanner
  h+='<div class="dash-card"><div class="dash-card-title">⚠️ Bottleneck-Scanner</div>';
  const bottlenecks=[];
  // Full storage
  cities.forEach(c=>{const cap2=cityCap(c.id);const used=Object.values(G.stor[c.id]||{}).reduce((s,v)=>s+v,0);
    if(used>=cap2*0.85)bottlenecks.push({type:'lager',em:'📦',text:c.name+': Lager '+Math.round(used/cap2*100)+'% voll',severity:used>=cap2?3:2})});
  // Missing inputs
  cities.forEach(c=>{(G.blds[c.id]||[]).forEach(b=>{const d=BLD[b.type];if(!d||!d.input)return;
    Object.entries(d.input).forEach(([g,need])=>{const stock=G.stor[c.id]?.[g]||0;
      if(stock<need)bottlenecks.push({type:'input',em:'🏭',text:d.name+' in '+c.name+': '+(GOODS[g]?.name||g)+' fehlt ('+stock+'/'+need+')',severity:1})})})});
  // Idle vehicles > 60%
  const idlePct=G.vehs.length?Math.round(G.vehs.filter(v=>v.st==='idle').length/G.vehs.length*100):0;
  if(idlePct>60&&G.vehs.length>2)bottlenecks.push({type:'idle',em:'🚛',text:idlePct+'% Fahrzeuge untätig',severity:1});
  // Low condition
  const lowCond=G.vehs.filter(v=>vehCondition(v)<20);
  if(lowCond.length)bottlenecks.push({type:'maint',em:'🔧',text:lowCond.length+' Fahrzeuge unter 20% Zustand',severity:2});

  bottlenecks.sort((a,b)=>b.severity-a.severity);
  if(!bottlenecks.length)h+='<div style="padding:8px;text-align:center;color:var(--a)">✅ Keine Engpässe erkannt</div>';
  bottlenecks.slice(0,8).forEach(bn=>{const clr=bn.severity>=3?'var(--r)':bn.severity>=2?'var(--go)':'var(--td)';
    h+='<div style="padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)"><span style="color:'+clr+'">'+bn.em+' '+bn.text+'</span></div>'});
  h+='</div></div>';return h;
}

// ═══ ALERTS DASHBOARD ═══
function dashAlerts(){
  let h='<div class="dash-grid">';
  const problems=[];const opportunities=[];const info=[];

  // PROBLEMS
  // Maintenance critical
  G.vehs.filter(v=>vehCondition(v)<20).forEach(v=>{problems.push({em:'🔧',text:vehName(v)+' kritisch ('+vehCondition(v)+'%)',act:"openComputer();setCompTab('fleet');G.fleetSub='maint'",sev:3})});
  // Expiring orders
  G.orders.filter(o=>o.acc).forEach(o=>{const rem=o.tl-(G.tick-o.born);
    if(rem<60)problems.push({em:'🔴',text:'Auftrag '+fmtOrd(o.num)+' läuft in '+ftime(rem)+' ab!',act:"openComputer();setCompTab('logistics')",sev:3});
    else if(rem<180)problems.push({em:'🟡',text:'Auftrag '+fmtOrd(o.num)+' noch '+ftime(rem),act:"openComputer();setCompTab('logistics')",sev:2})});
  // Full storage
  cities.forEach(c=>{const cap=cityCap(c.id);const used=Object.values(G.stor[c.id]||{}).reduce((s,v)=>s+v,0);
    if(used>=cap)problems.push({em:'📦',text:c.name+': Lager VOLL!',act:"selectLocation('"+c.id+"');openComputer();setCompTab('inventory')",sev:3});
    else if(used>=cap*0.9)problems.push({em:'📦',text:c.name+': Lager '+Math.round(used/cap*100)+'%',act:"selectLocation('"+c.id+"');openComputer();setCompTab('inventory')",sev:1})});
  // Missing production inputs
  cities.forEach(c=>{(G.blds[c.id]||[]).forEach(b=>{const d=BLD[b.type];if(!d||!d.input||b.active===false)return;
    Object.entries(d.input).forEach(([g,need])=>{const stock=G.stor[c.id]?.[g]||0;
      if(stock<need)problems.push({em:'🏭',text:d.name+' in '+c.name+': '+(GOODS[g]?.name||g)+' fehlt',act:"selectLocation('"+c.id+"');openComputer();setCompTab('buildings')",sev:1})})})});

  // OPPORTUNITIES
  // Events that boost prices
  const evts=typeof activeEvents==='function'?activeEvents():[];
  evts.forEach(e=>{const def=EVENTS.find(x=>x.id===e.id);if(!def)return;
    if(def.effect.globalMult>1||def.effect.regionBonus||def.effect.goodBonus||def.effect.farmMult>1)
      opportunities.push({em:def.icon,text:def.name+' aktiv! '+def.desc+' ('+ftime(e.endTick-G.tick)+')',act:"window._dashTab='market';renDash()"})});
  // High-value orders available
  G.orders.filter(o=>!o.acc).sort((a,b)=>b.rew-a.rew).slice(0,3).forEach(o=>{
    if(o.rew>5000)opportunities.push({em:'💰',text:fmt(o.rew)+' Auftrag: '+(GOODS[o.good]?.em||'')+(GOODS[o.good]?.name||''),act:"openComputer();setCompTab('logistics')"})});
  // Idle vehicles with stock
  const idleWithStock=[];
  cities.forEach(c=>{const stock=Object.values(G.stor[c.id]||{}).reduce((s,v)=>s+v,0);
    const idleV=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id).length;
    if(stock>5&&idleV>0)idleWithStock.push(c.name)});
  if(idleWithStock.length)opportunities.push({em:'🚛',text:'Fahrzeuge + Ware bereit in: '+idleWithStock.join(', '),act:"openComputer();setCompTab('logistics')"});

  // INFO
  const totalV=G.vehs.length;const idlePct=totalV?Math.round(G.vehs.filter(v=>v.st==='idle').length/totalV*100):0;
  info.push({em:'🚛',text:'Flottenauslastung: '+(100-idlePct)+'%'});
  info.push({em:'📦',text:(G.dels||0)+' Lieferungen · '+fmt(G.earned||0)+' verdient'});
  info.push({em:'🏙️',text:cities.length+' Standorte · '+Object.values(G.blds).flat().length+' Gebäude'});

  // Render
  h+='<div class="dash-card" style="grid-column:span 2"><div class="dash-card-title" style="color:var(--r)">🔴 Probleme · '+problems.length+'</div>';
  if(!problems.length)h+='<div style="padding:8px;text-align:center;color:var(--a)">✅ Keine Probleme!</div>';
  problems.sort((a,b)=>b.sev-a.sev).forEach(p=>{const clr=p.sev>=3?'var(--r)':p.sev>=2?'var(--go)':'var(--td)';
    h+='<div style="padding:4px 0;font-size:11px;border-bottom:1px solid var(--bd);cursor:pointer" onclick="'+p.act+'"><span style="color:'+clr+'">'+p.em+' '+p.text+' <span style="color:var(--a)">→</span></span></div>'});
  h+='</div>';

  h+='<div class="dash-card"><div class="dash-card-title" style="color:var(--go)">💡 Chancen · '+opportunities.length+'</div>';
  if(!opportunities.length)h+='<div class="sub" style="padding:6px;text-align:center">Keine besonderen Chancen</div>';
  opportunities.forEach(o=>{
    h+='<div style="padding:4px 0;font-size:11px;border-bottom:1px solid var(--bd);cursor:pointer" onclick="'+o.act+'"><span style="color:var(--go)">'+o.em+' '+o.text+' <span style="color:var(--a)">→</span></span></div>'});
  h+='</div>';

  h+='<div class="dash-card"><div class="dash-card-title">ℹ️ Status</div>';
  info.forEach(i=>{h+='<div style="padding:3px 0;font-size:11px;border-bottom:1px solid var(--bd)">'+i.em+' '+i.text+'</div>'});
  // Recent events log
  const log=document.getElementById('log');
  if(log){const entries=log.textContent.split('\n').filter(x=>x.trim()).slice(0,5);
    if(entries.length){h+='<div class="dash-card-title" style="margin-top:6px">📝 Letzte Aktionen</div>';
      entries.forEach(e=>{h+='<div style="padding:1px 0;font-size:10px;color:var(--td)">'+e+'</div>'})}}
  h+='</div></div>';return h;
}
