// ═══ WIKI ═══
function showWiki(section){
  let existing=document.getElementById('wikiPopup');if(existing)existing.remove();
  if(!section)section='overview';
  const popup=document.createElement('div');popup.id='wikiPopup';popup.className='unlock-bg';
  const ic={overview:'ri-compass-3-line',alliance:'ri-team-line',levels:'ri-bar-chart-box-line',vehicles:'ri-truck-line',orders:'ri-file-list-3-line',market:'ri-line-chart-line',production:'ri-building-line',infra:'ri-community-line',events:'ri-flashlight-line',tips:'ri-lightbulb-line'};
  const W={
    overview:{t:'Übersicht',c:`
      <div class="wk-hero">🏭 Willkommen bei LogistiX</div>
      <div class="wk-desc">Baue ein globales Logistik-Imperium auf. Produziere Waren, transportiere sie per LKW, Zug, Schiff oder Flugzeug und handle auf dem Weltmarkt.</div>
      <div class="wk-grid">
        <div class="wk-card"><div class="wk-card-ico" style="background:rgba(61,214,140,.1);color:var(--a)"><i class="ri-map-pin-add-line"></i></div><div class="wk-card-t">Standorte</div><div class="wk-card-d">Städte weltweit freischalten. Jede Stadt hat eigene Gebäude, Lager und Infrastruktur.</div></div>
        <div class="wk-card"><div class="wk-card-ico" style="background:rgba(56,189,248,.1);color:var(--a2)"><i class="ri-building-line"></i></div><div class="wk-card-t">Produktion</div><div class="wk-card-d">Rohstoffe → Verarbeitung → Luxusgüter. Über 40 Gebäudetypen und 50+ Waren.</div></div>
        <div class="wk-card"><div class="wk-card-ico" style="background:rgba(251,191,36,.1);color:var(--go)"><i class="ri-truck-line"></i></div><div class="wk-card-t">Transport</div><div class="wk-card-d">17 Fahrzeugtypen. Depot-System mit Wartung. Fahrzeuge auf der Karte verfolgen.</div></div>
        <div class="wk-card"><div class="wk-card-ico" style="background:rgba(168,85,247,.1);color:#a855f7"><i class="ri-line-chart-line"></i></div><div class="wk-card-t">Wirtschaft</div><div class="wk-card-d">Dynamische Marktpreise, Events, Express-Aufträge. Strategie entscheidet!</div></div>
      </div>
      <div class="wk-h2">Spielablauf</div>
      <div class="wk-steps">
        <div class="wk-step"><span class="wk-num">1</span>Stadt freischalten & Gebäude bauen</div>
        <div class="wk-step"><span class="wk-num">2</span>Fahrzeuge kaufen & Depot einrichten</div>
        <div class="wk-step"><span class="wk-num">3</span>Waren produzieren & im Lager sammeln</div>
        <div class="wk-step"><span class="wk-num">4</span>Aufträge annehmen oder am Markt verkaufen</div>
        <div class="wk-step"><span class="wk-num">5</span>Gewinne investieren & expandieren</div>
      </div>`},
    levels:{t:'Level-System',c:`
      <div class="wk-h2">15 Level · Gründer bis Legende</div>
      <div class="wk-desc">Jedes Level schaltet neue Gebäude, Fahrzeuge und Regionen frei. Aufstieg durch Unternehmenswert + Standorte + Lieferungen.</div>
      <div class="wk-h3">Entfernungs-Progression</div>
      <div class="wk-table"><table><tr><th>Level</th><th>Radius</th><th>Beispiel</th></tr>
        <tr><td>1 Gründer</td><td>25 km</td><td>Nachbarstädte</td></tr>
        <tr><td>2 Landwirt</td><td>35 km</td><td>Regionale Städte</td></tr>
        <tr><td>3 Händler</td><td>50 km</td><td>Großstädte in der Nähe</td></tr>
        <tr><td>4-5</td><td>100-200 km</td><td>Landesweit</td></tr>
        <tr><td>6-8</td><td>500-5.000 km</td><td>Europaweit</td></tr>
        <tr><td>9-12</td><td>10.000+ km</td><td>Interkontinental</td></tr>
        <tr><td>13-15</td><td>25.000 km</td><td>Weltweit</td></tr>
      </table></div>
      <div class="wk-h3">Freischaltungen</div>
      <div class="wk-desc">Level 1-3: Farmen, Kleintransporter · Level 4-6: Fabriken, Züge, Schiffe · Level 7-10: Hightech, Flugzeuge · Level 11-15: Luxus, Spezialfahrzeuge</div>`},
    vehicles:{t:'Fahrzeuge',c:`
      <div class="wk-h2">17 Fahrzeugtypen · 4 Kategorien</div>
      <div class="wk-h3">Benennung: EU/ALZ-KT01</div>
      <div class="wk-desc">Region (EU/NA/SA/AS/AF/OZ) / Stadt (3 Buchstaben) - Typkürzel + Nummer</div>
      <div class="wk-h3">🚛 Land</div>
      <div class="wk-table"><table><tr><th>Fahrzeug</th><th>Kap.</th><th>Speed</th><th>Wartung</th></tr>
        <tr><td>Kleintransporter</td><td>6t</td><td>70 km/h</td><td>alle 10.000 km</td></tr>
        <tr><td>LKW 7.5t</td><td>10t</td><td>65 km/h</td><td>alle 10.000 km</td></tr>
        <tr><td>Sattelzug</td><td>18t</td><td>55 km/h</td><td>alle 10.000 km</td></tr>
      </table></div>
      <div class="wk-h3">🚆 Schiene · 🚢 See · ✈️ Luft</div>
      <div class="wk-desc">Züge: Wartung alle 25.000 km · Schiffe: 50.000 km · Flugzeuge: 15.000 km<br>Infrastruktur an BEIDEN Endpunkten erforderlich!</div>
      <div class="wk-h3">🏢 Depot-System</div>
      <div class="wk-desc">Ohne Depot: 2 Fahrzeuge · Mit Depot (15.000€): 3 Stellplätze · 5× upgradbar (+2 = max 13)<br>Verkauf nur im Heimat-Depot möglich. Wartungskosten: 8% des Kaufpreises.</div>`},
    orders:{t:'Aufträge & Logistik',c:`
      <div class="wk-h2">Aufträge · Express · Auto-Manager</div>
      <div class="wk-h3">Normale Aufträge</div>
      <div class="wk-desc">Erscheinen automatisch wenn Waren im Lager sind. Ziele: alle Städte im Umkreis (auch nicht freigeschaltete 🔓). Preis: <b>1,3-3,0× Marktpreis</b> — immer mehr als Marktverkauf!</div>
      <div class="wk-h3">⚡ Express-Aufträge</div>
      <div class="wk-desc">Alle 2 Minuten, 2× Marktpreis aber mit Zeitlimit. Gedeckelt auf 5% des Unternehmenswerts.</div>
      <div class="wk-h3">Preis-Breakdown</div>
      <div class="wk-desc">Jeder Auftrag zeigt: Preis/Stück · % über Markt · geschätzte Transportkosten · Nettogewinn</div>
      <div class="wk-h3">🤖 Auto-Manager (ab Level 5)</div>
      <div class="wk-desc">Akzeptiert automatisch Aufträge wo Ware + Fahrzeug verfügbar sind und verschickt sofort.</div>
      <div class="wk-h3">Nicht-freigeschaltete Ziele 🔓</div>
      <div class="wk-desc">Fahrzeug liefert und kehrt automatisch zum nächsten eigenen Standort zurück.</div>`},
    market:{t:'Marktplatz',c:`
      <div class="wk-h2">Dynamische Preise · Regionale Nachfrage</div>
      <div class="wk-h3">Preisbildung</div>
      <div class="wk-desc">Basispreis × Regionale Nachfrage × Event-Multiplikator ± 15% Schwankung</div>
      <div class="wk-h3">Regionale Nachfrage</div>
      <div class="wk-table"><table><tr><th>Region</th><th>Hoch</th><th>Niedrig</th></tr>
        <tr><td>🇪🇺 Europa</td><td>Elektronik +30%, Autos +20%</td><td>Bier -20%</td></tr>
        <tr><td>🌎 Nordamerika</td><td>Autos +40%, Chips +30%</td><td>Öl -30%</td></tr>
        <tr><td>🌏 Asien</td><td>Möbel +30%, Stahl +20%</td><td>Reis -40%, Elektronik -20%</td></tr>
        <tr><td>🌍 Afrika</td><td>Elektronik +60%, Medikamente +50%</td><td>—</td></tr>
      </table></div>
      <div class="wk-h3">Verkauf am Markt</div>
      <div class="wk-desc">Popup mit Zielstadt, Menge, Preiskalkulation. Fahrzeug fährt sichtbar zum Markt (Hin- und Rückfahrt). Logistikzentrum-Infrastruktur gibt +15%.</div>
      <div class="wk-h3">Aufträge vs. Markt</div>
      <div class="wk-desc"><b>Aufträge:</b> 1,3-3× Marktpreis, aber man muss auf passende warten.<br><b>Markt:</b> Sofort verkaufbar, aber weniger Gewinn.</div>`},
    production:{t:'Produktion',c:`
      <div class="wk-h2">3 Produktionsstufen</div>
      <div class="wk-steps">
        <div class="wk-step"><span class="wk-num" style="background:rgba(61,214,140,.15);color:var(--a)">1</span><b>Rohstoffe</b> — Farmen, Minen, Plantagen. Produzieren ohne Input (25-35s)</div>
        <div class="wk-step"><span class="wk-num" style="background:rgba(56,189,248,.15);color:var(--a2)">2</span><b>Verarbeitung</b> — Mühle, Bäckerei, Molkerei. Brauchen Rohstoffe</div>
        <div class="wk-step"><span class="wk-num" style="background:rgba(168,85,247,.15);color:#a855f7">3</span><b>Luxus</b> — Juwelier, Chipfabrik, Automobilwerk. Brauchen verarbeitete Waren</div>
      </div>
      <div class="wk-h3">Gebäudekapazität & Überlauf</div>
      <div class="wk-desc">Jedes Gebäude speichert intern. Wenn voll → Überlauf ins Stadtlager oder Produktion pausiert (einstellbar).</div>
      <div class="wk-h3">Regionale Gebäude</div>
      <div class="wk-desc">☕ Kaffee: Südamerika/Afrika · 🌿 Tee: Asien · 🍫 Kakao: Südamerika · 🌴 Kautschuk: Asien/Afrika · 🏔️ Erz/Kohle: überall</div>`},
    infra:{t:'Infrastruktur',c:`
      <div class="wk-h2">7 Infrastruktur-Typen</div>
      <div class="wk-table"><table><tr><th>Infrastruktur</th><th>Preis</th><th>Effekt</th></tr>
        <tr><td>🏢 Depot</td><td>15.000€</td><td>3 Stellplätze, 5× upgradbar (+2)</td></tr>
        <tr><td>📦 Lagererweiterung</td><td>8.000€</td><td>+200 Lagerplätze (einmalig)</td></tr>
        <tr><td>🚉 Bahnhof</td><td>35.000€</td><td>Züge nutzbar (beide Enden!)</td></tr>
        <tr><td>⚓ Hafen</td><td>150.000€</td><td>Schiffe (nur Hafenstädte)</td></tr>
        <tr><td>✈️ Flughafen</td><td>200.000€</td><td>Flugzeuge (nur Flughafenstädte)</td></tr>
        <tr><td>📦 Logistikzentrum</td><td>80.000€</td><td>+15% Marktpreise</td></tr>
        <tr><td>⛽ Tankstelle</td><td>8.000€</td><td>+10% Fahrzeugspeed</td></tr>
      </table></div>
      <div class="wk-h3">Wichtig</div>
      <div class="wk-desc">Verkehrsinfrastruktur (Bahnhof, Hafen, Flughafen) muss an <b>beiden Endpunkten</b> einer Route vorhanden sein!</div>`},
    events:{t:'Events',c:`
      <div class="wk-h2">10 zufällige Events · ~6-10 Stunden Dauer</div>
      <div class="wk-desc">Max 2 gleichzeitig aktiv. Neues Event ca. alle 6 Stunden. Events beeinflussen Preise, Geschwindigkeit und Produktion.</div>
      <div class="wk-table"><table><tr><th>Event</th><th>Effekt</th><th>Dauer</th></tr>
        <tr><td>🌊 Sturmwarnung</td><td>Schiffe 50% langsamer</td><td>~7h</td></tr>
        <tr><td>🚆 Bahnstreik</td><td>Züge stehen still</td><td>~6h</td></tr>
        <tr><td>⛽ Ölkrise</td><td>Wartung +20%</td><td>~8h</td></tr>
        <tr><td>📈 Asien/EU-Boom</td><td>Region +25-30%</td><td>~9h</td></tr>
        <tr><td>🌾 Rekordernte</td><td>Farmen ×2</td><td>~8h</td></tr>
        <tr><td>💻 Tech-Boom</td><td>Elektronik/Chips +40%</td><td>~8h</td></tr>
        <tr><td>🤝 Freihandel</td><td>Alle Preise +10%</td><td>~10h</td></tr>
        <tr><td>📉 Rezession</td><td>Alle Preise -15%</td><td>~7h</td></tr>
        <tr><td>🛣️ Freie Autobahn</td><td>LKW +25% schneller</td><td>~6h</td></tr>
      </table></div>`},
    alliance:{t:'Allianz-System',c:`
      <div class="wk-h2">🤝 Allianzen — Multiplayer-System</div>
      <div class="wk-desc">Gründe oder tritt einer Allianz bei. Gemeinsam könnt ihr Spezialwaren herstellen, die Einzelspieler nicht produzieren können.</div>
      <div class="wk-h3">Gründung & Kosten</div>
      <div class="wk-desc">Gründung: <b>200.000€</b> (davon 150.000€ Startkapital in der Allianzkasse). Name + Tag (2-4 Zeichen).</div>
      <div class="wk-h3">7 Ränge mit Spezialisierung</div>
      <div class="wk-table"><table><tr><th>Rang</th><th>Bauen</th><th>Gebiete</th><th>Personal</th><th>Produktion</th><th>Aufträge</th></tr>
        <tr><td>👑 CEO</td><td>✅</td><td>✅</td><td>✅</td><td>✅</td><td>✅</td></tr>
        <tr><td>🌟 Vizepräsident</td><td>✅</td><td>✅</td><td>✅</td><td>✅</td><td>✅</td></tr>
        <tr><td>👥 Personalmanager</td><td>—</td><td>—</td><td>✅</td><td>—</td><td>—</td></tr>
        <tr><td>🏭 Produktionsleiter</td><td>✅</td><td>—</td><td>—</td><td>✅</td><td>—</td></tr>
        <tr><td>📋 Auftragsmanager</td><td>—</td><td>—</td><td>—</td><td>—</td><td>✅</td></tr>
        <tr><td>🏴 Gebietsmanager</td><td>—</td><td>✅</td><td>—</td><td>—</td><td>—</td></tr>
        <tr><td>👤 Mitglied</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>
      </table></div>
      <div class="wk-desc">Ränge mehrfach vergebar! CEO vergibt Rollen im Übersicht-Tab.</div>
      <div class="wk-h3">Einnahmequellen</div>
      <div class="wk-desc">Kein privates Einzahlen! Allianz verdient durch:<br>• <b>Allianz-Aufträge</b>: 2× Basispreis, aus Allianz-Lager<br>• <b>Gebietsgebühren</b>: Passive Einnahmen (geplant)</div>
      <div class="wk-h3">Produktion (keine Rohstoffe!)</div>
      <div class="wk-desc">Allianzen können KEINE Rohstoffe produzieren. Spieler müssen Waren ins Allianz-Lager liefern. Daraus werden Spezialwaren hergestellt: ⛽📱🛥️💉🛰️🛡️⚡🤖</div>
      <div class="wk-h3">Gebiete (160 weltweit)</div>
      <div class="wk-desc">20 Länder × 8 Regionen. Kauf = 30× Tagesgebühr. Nach 7 unbezahlten Tagen verloren. Gebäude nur in eigenen Gebieten baubar. Regionabhängig!</div>
      <div class="wk-h3">Level-System</div>
      <div class="wk-desc">10 Level: Startup → Hegemonie. Start: 10 Mitglieder, +2 pro Level. Mehr Gebäude-Slots und Gebiete pro Level.</div>`},
    tips:{t:'Strategie-Tipps',c:`
      <div class="wk-h2">Tipps für jede Spielphase</div>
      <div class="wk-h3">🌱 Früh (Level 1-3)</div>
      <div class="wk-desc">• Sofort Depot + Bauernhof bauen<br>• Kurze Aufträge für schnellen Cashflow<br>• 2. Stadt freischalten sobald möglich<br>• Transporter sind günstig und reichen anfangs</div>
      <div class="wk-h3">📈 Mitte (Level 4-8)</div>
      <div class="wk-desc">• Verarbeitungsketten aufbauen (Getreide→Mehl→Brot→Pizza)<br>• Depot ausbauen für mehr Fahrzeuge<br>• Bahnhöfe für günstige Langstreckentransporte<br>• Daueraufträge für wiederkehrende Routen</div>
      <div class="wk-h3">🏆 Spät (Level 9-15)</div>
      <div class="wk-desc">• Events für Marktverkäufe nutzen (Tech-Boom = Elektronik verkaufen!)<br>• Auto-Manager ab Level 5 spart enorm viel Zeit<br>• Flugzeuge für Express-Aufträge<br>• Luxusgüter (Schmuck, Autos, Chips) bringen am meisten</div>
      <div class="wk-h3">💡 Allgemein</div>
      <div class="wk-desc">• Aufträge > Marktverkauf (1,3-3× Marktpreis)<br>• Wartung nicht vergessen — unter 30% wird es kritisch<br>• "Nach Auftrag → Depot" für geplanten Rückruf nutzen<br>• Wiki jederzeit über Hamburger-Menü erreichbar</div>`},
  };
  const sections2=Object.keys(W);
  let h='<div style="width:720px;max-width:95vw;height:82vh;display:flex;overflow:hidden;border-radius:14px;border:1px solid var(--bd2);background:var(--bg);box-shadow:0 20px 60px rgba(0,0,0,.5)">';
  // Sidebar
  h+='<div style="width:175px;min-width:175px;background:rgba(0,0,0,.25);border-right:1px solid var(--bd);overflow-y:auto;padding:10px 6px">';
  h+='<div style="font-family:var(--mono);font-size:14px;font-weight:700;color:var(--a);padding:10px 8px 12px;display:flex;align-items:center;gap:6px"><i class="ri-book-open-line"></i> Wiki</div>';
  sections2.forEach(s=>{const w=W[s];const active=section===s;
    h+='<div style="padding:7px 10px;border-radius:8px;cursor:pointer;font-size:12px;margin:1px 0;transition:.15s;'+(active?'background:rgba(61,214,140,.1);color:var(--a);font-weight:600':'color:var(--td);font-weight:400')+'" onclick="showWiki(\''+s+'\')">';
    h+='<i class="'+(ic[s]||'ri-file-text-line')+'" style="margin-right:6px"></i>'+w.t+'</div>'});
  h+='<div style="height:1px;background:var(--bd);margin:8px"></div>';
  h+='<div style="padding:7px 10px;border-radius:8px;cursor:pointer;font-size:12px;color:var(--td)" onclick="document.getElementById(\'wikiPopup\').remove()"><i class="ri-close-line" style="margin-right:6px"></i>Schließen</div>';
  h+='</div>';
  // Content
  const w=W[section]||W.overview;
  h+='<div style="flex:1;overflow-y:auto;padding:24px 28px">';
  h+='<div style="font-family:var(--mono);font-size:11px;color:var(--td);margin-bottom:12px"><i class="'+(ic[section]||'ri-file-text-line')+'"></i> '+w.t+'</div>';
  h+=w.c;
  h+='</div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}

// ═══ ALLIANCE TERMINAL ═══
let alliancePanelOpen=false;
