function compRoutes(el){
  if(routesSub==='standing'){compStanding(el);return}
  if(routesSub==='transfer'){compTransfer(el);return}
  let h=tabHead('routes','🗺️ Routen','Lieferungen planen und verwalten');
  // Fleet overview bar
  const idleV=G.vehs.filter(v=>v.st==='idle'),movingV=G.vehs.filter(v=>v.st==='moving');
  h+='<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">';
  h+='<span class="tg g">🟢 '+idleV.length+' bereit</span><span class="tg y">🔶 '+movingV.length+' unterwegs</span>';
  // Per-city idle vehicle summary
  const vehByCty={};idleV.forEach(v=>{vehByCty[v.loc]=(vehByCty[v.loc]||0)+1});
  Object.entries(vehByCty).forEach(([cid,n])=>{const cn=C(cid);if(cn)h+='<span class="tg">'+cn.name+' 🚛'+n+'</span>'});
  h+='</div>';
  const selCid=(!routesShowAll&&G.sel)?G.sel:null;
  const sc=selCid?C(selCid):null;
  if(sc)h+='<div class="sub" style="margin-bottom:8px;padding:6px 8px;background:rgba(61,214,140,.04);border:1px solid rgba(61,214,140,.15);border-radius:6px">📍 Filter: <b>'+sc.name+'</b> – nur Routen von/nach hier <button class="btn sm" onclick="routesShowAll=true;routesSub=\'all\';G.sel=null;renComp()" style="margin-left:6px">✕ Alle</button></div>';

  const allAcc=G.orders.filter(o=>o.acc);
  // Filter by city if selected
  const acc=selCid?allAcc.filter(o=>o.from===selCid||o.to===selCid):allAcc;
  if(selCid&&acc.length!==allAcc.length)h+='<div class="sub" style="margin-bottom:6px">Zeige '+acc.length+' von '+allAcc.length+' aktiven Aufträgen</div>';

  const unassigned=acc.filter(o=>{const rem=o.amt-(o.shipped||0);return rem>0&&!G.vehs.find(x=>x.cargo?.oid===o.id&&x.st==='moving')});
  const partialShipped=acc.filter(o=>(o.shipped||0)>0&&(o.shipped||0)<o.amt);
  const running=acc.filter(o=>G.vehs.find(x=>x.cargo?.oid===o.id&&x.st==='moving'));
  if(unassigned.length){h+='<div class="sec-label">Zuweisen · '+unassigned.length+'</div>';
    unassigned.forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
      const shipped=o.shipped||0;const remaining=o.amt-shipped;
      h+='<div class="crd"><div class="rw"><span>'+fmtOrd(o.num)+' '+(GOODS[o.good]?.em||'')+' '+o.amt+'×</span><span style="color:var(--a);font-family:var(--mono);font-size:14px;font-weight:700">'+fmt(o.rew)+'</span></div>';
      h+='<div class="sub">'+f.name+' → '+t.name+' · '+fdist(f,t)+' km</div>';
      if(shipped>0)h+='<div class="sub" style="color:var(--go)">📦 Bereits verschickt: '+shipped+'/'+o.amt+'<div class="pb"><div class="pf" style="width:'+(shipped/o.amt*100)+'%"></div></div></div>';
      const avl=G.vehs.filter(x=>x.st==='idle'&&x.loc===o.from&&canVehTravel(x,o.to));
      const remV=G.vehs.filter(x=>x.st==='idle'&&x.loc!==o.from&&canVehTravel(x,o.from));
      if(avl.length){
        h+='<div class="sub" style="margin:4px 0;font-weight:600">Fahrzeuge wählen ('+remaining+' verbleibend):</div>';
        avl.forEach(x=>{const xvt=VT[x.type],cap=vehCap(x);
          h+='<label class="veh-check"><input type="checkbox" class="vc" data-oid="'+o.id+'" data-vid="'+x.id+'" data-cap="'+cap+'" onchange="updateSelInfo(\''+o.id+'\','+remaining+')" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
          h+='<span>'+xvt.em+' '+xvt.name+' · Kap: <b>'+cap+'</b> · '+ftime(tripT(f,t,xvt.spd))+'</span></label>'});
        h+='<div class="sel-info" id="selInfo_'+o.id+'"><span class="sub">Keine Fahrzeuge ausgewählt</span></div>';
        h+='<div style="display:flex;gap:4px;margin-top:6px"><button class="btn full" onclick="multiAssign(\''+o.id+'\')">🚀 Ausgewählte losschicken</button>';
        h+='<button class="btn" style="background:rgba(251,191,36,.15);color:var(--go);border:1px solid rgba(251,191,36,.3)" onclick="autoAssign(\''+o.id+'\')">⚡ Auto</button></div>';
      } else {
        h+='<div class="sub" style="color:var(--r)">Kein Fahrzeug in '+f.name+'</div>';
      }
      // Always show remote vehicle option
      if(remV.length){
        h+='<div style="margin-top:4px"><button class="btn sm" style="color:var(--a2);border-color:rgba(56,189,248,.3)" onclick="G._remoteOid=\''+o.id+'\';G.logSub=\'orders\';renComp()">📍 Von anderem Standort senden ('+remV.length+')</button></div>';
      }
      h+='</div>'})}
  // Running orders
  if(running.length){h+='<div class="sec-label">Laufend · '+running.length+'</div>';
    const unasOrd=acc.filter(o2=>{const rem2=o2.amt-(o2.shipped||0);return rem2>0});
    running.forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;const v=G.vehs.find(x=>x.cargo?.oid===o.id);if(!v)return;const vt=VT[v.type],tn=tripT(f,t,vt.spd),pct=Math.min(v.prog/tn,1);
      h+='<div class="crd"><div class="rw"><span>'+fmtOrd(o.num)+' '+vt.em+'</span><span class="eta">'+Math.floor(pct*100)+'%</span></div><div class="sub">'+f.name+' → '+t.name+'</div>';
      h+='<div class="pb"><div class="pf" style="width:'+pct*100+'%"></div></div>';
      // Show current post-delivery / follow-up status
      const pd=v.postDelivery?C(v.postDelivery):null;
      const fuo=v.followUpOrder?G.orders.find(x=>x.id===v.followUpOrder):null;
      h+='<div style="margin-top:5px">';
      if(fuo){const fc=C(fuo.from),tc2=C(fuo.to);
        h+='<div class="sub" style="margin-bottom:3px"><span class="tg b">📋 Folgeauftrag</span> '+(GOODS[fuo.good]?.em||'')+' '+(fc?.name||'?')+' → '+(tc2?.name||'?')+' <button class="rs-rm" onclick="setFollowUpOrder(\''+v.id+'\',null)">✕</button></div>';
      } else if(pd){
        h+='<div class="sub" style="margin-bottom:3px"><span class="tg g">→ '+pd.name+'</span> <button class="rs-rm" onclick="setPostDelivery(\''+v.id+'\',null)">✕</button></div>';
      }
      // Combined dropdown: cities + follow-up orders
      h+='<select class="sl-action" onchange="const v2=this.value;if(!v2)return;if(v2.startsWith(\'ord:\'))setFollowUpOrder(\''+v.id+'\',v2.substr(4));else setPostDelivery(\''+v.id+'\',v2)">';
      h+='<option value="">Nach Lieferung…</option>';
      // Optgroup: follow-up orders
      if(unasOrd.length){h+='<optgroup label="📋 Folgeauftrag">';
        unasOrd.forEach(uo=>{const uf=C(uo.from),ut=C(uo.to);if(!uf||!ut)return;
          h+='<option value="ord:'+uo.id+'">'+fmtOrd(uo.num)+' '+(GOODS[uo.good]?.em||'')+' '+uf.name+'→'+ut.name+' '+fmt(uo.rew)+'</option>'});
        h+='</optgroup>'}
      // Optgroup: destination cities
      h+='<optgroup label="📍 Zielort">';
      reachableCities(v).forEach(x=>{h+='<option value="'+x.id+'">'+x.name+'</option>'});
      h+='</optgroup></select>';
      h+='</div></div>'})}
  // Market trips
  const mktVehs=G.vehs.filter(v=>v.st==='moving'&&v.cargo?.market);
  if(mktVehs.length){h+='<div class="sec-label" style="color:var(--go)">💰 Marktverkäufe · '+mktVehs.length+'</div>';
    mktVehs.forEach(v=>{const vt=VT[v.type];if(!vt)return;
      const f2=C(v.rt.from)||Cx(v.rt.from);const t2=Cx(v.rt.to)||(v.rt.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f2||!t2)return;
      const tn2=v.rt.tripTime||tripT(f2,t2,vt.spd);const pct2=Math.min(v.prog/(tn2||1),1);
      const isReturn=v.cargo.returning;
      h+='<div class="crd" style="border-left:3px solid var(--go);background:rgba(251,191,36,.02)">';
      h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="tg" style="background:rgba(251,191,36,.12);color:var(--go);border-color:rgba(251,191,36,.25)">'+(isReturn?'🔙 Rückfahrt':'💰 Marktfahrt')+'</span></span>';
      h+='<span class="eta">'+Math.floor(pct2*100)+'%</span></div>';
      h+='<div class="sub">'+(f2.name||'?')+' → '+(t2.name||'?')+'</div>';
      h+='<div class="pb"><div class="pf" style="width:'+pct2*100+'%;background:var(--go)"></div></div></div>'});}
  // Alliance deliveries
  const allyVehs=G.vehs.filter(v=>v.st==='moving'&&v.cargo?.allianceDelivery);
  if(allyVehs.length){h+='<div class="sec-label" style="color:#a855f7">🤝 Allianzlieferungen · '+allyVehs.length+'</div>';
    allyVehs.forEach(v=>{const vt=VT[v.type];if(!vt)return;
      const f3=C(v.rt.from)||Cx(v.rt.from);const t3=Cx(v.rt.to)||(v.rt.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f3||!t3)return;
      const tn3=v.rt.tripTime||tripT(f3,t3,vt.spd);const pct3=Math.min(v.prog/(tn3||1),1);
      const isReturn=v.cargo.returning;
      h+='<div class="crd" style="border-left:3px solid #a855f7;background:rgba(168,85,247,.02)">';
      h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="tg" style="background:rgba(168,85,247,.12);color:#a855f7;border-color:rgba(168,85,247,.25)">'+(isReturn?'🔙 Rückfahrt':'🤝 Allianzlieferung')+'</span>';
      if(!isReturn&&v.cargo.good)h+=' <span class="sub">'+(GOODS[v.cargo.good]?.em||'')+' '+v.cargo.amt+'×</span>';
      h+='</span><span class="eta">'+Math.floor(pct3*100)+'%</span></div>';
      h+='<div class="sub">'+(f3.name||'?')+' → '+(t3.name||'?')+'</div>';
      h+='<div class="pb"><div class="pf" style="width:'+pct3*100+'%;background:#a855f7"></div></div></div>'});}
  el.innerHTML=h}

// ═══ WARENTRANSFER TAB ═══
function compTransfer(el){
  let h=tabHead('routes','📦 Warentransfer','Waren zwischen eigenen Standorten versenden');
  h+='<button class="btn sm" style="margin-bottom:8px" onclick="routesSub=\'all\';routesShowAll=true;renComp()">← Zurück zu Aufträge</button>';
  // Per city: stock + send
  let eigCities=cities.filter(c=>{const s=G.stor[c.id];return s&&Object.values(s).some(a=>a>0)});
  const totalItems=eigCities.reduce((t,c)=>t+Object.values(G.stor[c.id]||{}).reduce((a,v)=>a+v,0),0);
  h+='<div class="sub" style="margin-bottom:6px">'+eigCities.length+' Standorte mit Bestand · '+totalItems+' Waren gesamt</div>';
  if(!eigCities.length)h+='<div class="sub" style="padding:12px;text-align:center">Kein Lagerbestand zum Versenden</div>';
  eigCities.forEach(c=>{const s=G.stor[c.id]||{};const items=Object.entries(s).filter(([,a])=>a>0);if(!items.length)return;
    const vHere=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id).length;
    const cCap3=cityCap(c.id);const tot=items.reduce((a,[,v])=>a+v,0);
    h+='<div class="crd"><div class="rw"><span style="font-weight:600">📍 '+c.name+'</span><span class="sub">📦 '+tot+'/'+cCap3+' · 🚛 '+vHere+'</span></div>';
    items.forEach(([g,amt])=>{
      h+='<div style="display:flex;align-items:center;justify-content:space-between;padding:3px 0;font-size:12px;border-top:1px solid var(--bd)">';
      h+='<span>'+(GOODS[g]?.em||'')+' '+(GOODS[g]?.name||'')+' <b>'+amt+'</b>×</span>';
      if(cities.length>1&&vHere>0)h+='<button class="btn sm" onclick="showSendGoodsPopup(\''+c.id+'\',\''+g+'\','+amt+')">📦 Senden</button>';
      else if(!vHere)h+='<span class="sub" style="color:var(--r)">Kein Fahrzeug</span>';
      h+='</div>'});
    h+='</div>'});
  el.innerHTML=h}

// ═══ STANDING ORDERS TAB ═══
function compStanding(el){
  let h=tabHead('standing','🔄 Daueraufträge','Automatische Lieferungen zwischen Standorten');
  const sos=G.standingOrders||[];
  const active=sos.filter(so=>so.active).length;
  h+='<div style="display:flex;gap:4px;margin-bottom:8px"><span class="tg g">'+active+' aktiv</span><span class="tg">'+(sos.length-active)+' pausiert</span><span class="tg">'+sos.length+' gesamt</span></div>';

  // Existing standing orders
  if(sos.length){
    sos.forEach(so=>{const fc=C(so.from),tc2=C(so.to),gd=GOODS[so.good];
      const vids=so.vehicleIds||( so.vehicleId?[so.vehicleId]:[]);
      const isFull=so.fillMode;
      const paused=!so.active;const autoPaused=so.autoPaused;
      // Find active vehicles for this standing order
      const activeVehs=G.vehs.filter(v=>v.st==='moving'&&v.cargo?.internal&&v.cargo.good===so.good&&v.rt?.from===so.from&&v.rt?.to===so.to);
      h+='<div class="crd" style="border-left:3px solid '+(paused?(autoPaused?'var(--go)':'var(--td)'):'var(--a)')+'">';
      h+='<div class="rw"><span>'+(gd?.em||'')+' <b>'+(gd?.name||'')+'</b></span>';
      h+='<div style="display:flex;gap:3px">';
      h+='<button class="btn sm" onclick="toggleStandingOrder(\''+so.id+'\')">'+(so.active?'⏸️':'▶️')+'</button>';
      h+='<button class="btn red sm" onclick="removeStandingOrder(\''+so.id+'\')">✕</button></div></div>';
      h+='<div class="sub">'+(fc?.name||'?')+' → '+(tc2?.name||'?')+'</div>';
      if(autoPaused)h+='<div class="sub" style="color:var(--go);margin-top:2px">⚠️ Auto-pausiert: Ziellager voll</div>';
      // Active vehicles underway
      if(activeVehs.length){h+='<div style="margin-top:3px">';
        activeVehs.forEach(v=>{const vt=VT[v.type];const f2=C(v.rt.from),t2=C(v.rt.to);
          if(!f2||!t2)return;const tn=tripT(f2,t2,vt.spd),pct=Math.min(v.prog/tn,1);
          h+='<div class="sub" style="padding:2px 0">'+vt.em+' '+v.cargo.amt+'× · '+Math.floor(pct*100)+'% · '+ftime(tn-v.prog)+' verbl.</div>'});
        h+='</div>'}
      // Amount
      h+='<div style="display:flex;align-items:center;gap:6px;margin-top:4px;padding-top:4px;border-top:1px solid var(--bd)">';
      h+='<label class="veh-check" style="flex:none;padding:3px 6px;margin:0;border-color:'+(isFull?'var(--a)':'var(--bd)')+'"><input type="checkbox" '+(isFull?'checked':'')+' onchange="toggleSOFillMode(\''+so.id+'\')"/><span style="font-size:9px">Voll beladen</span></label>';
      if(!isFull){
        h+='<input type="number" class="sl" value="'+so.amt+'" min="1" max="999" style="width:55px;font-size:11px;padding:4px;text-align:center" onfocus="renderBlocked=true" onblur="renderBlocked=false" onchange="updateSOAmt(\''+so.id+'\',this.value)"/>';
        h+='<span class="sub">× pro Fahrt</span>';
      } else h+='<span class="sub" style="color:var(--a)">→ Volle Kapazität</span>';
      h+='</div>';
      // Multi-vehicle assignment with checkboxes
      h+='<div style="margin-top:4px"><div class="sub" style="font-weight:600;margin-bottom:3px">Zugewiesene Fahrzeuge ('+vids.length+')</div>';
      const idleAtFrom=G.vehs.filter(v=>v.st==='idle'&&v.loc===so.from);
      idleAtFrom.forEach(v=>{const vt=VT[v.type];const isAssigned=vids.includes(v.id);
        h+='<label class="veh-check" style="padding:3px 6px;margin:1px 0;border-color:'+(isAssigned?'var(--a)':'var(--bd)')+'"><input type="checkbox" '+(isAssigned?'checked':'')+' onchange="toggleSOVehicle(\''+so.id+'\',\''+v.id+'\')"/>';
        h+='<span style="font-size:9px">'+vt.em+' '+vt.name+' · Kap: '+vehCap(v)+'</span></label>'});
      if(!idleAtFrom.length)h+='<div class="sub" style="opacity:.5">Keine Fahrzeuge in '+(fc?.name||'?')+'</div>';
      h+='</div></div>'});
  } else h+='<div class="sub" style="padding:10px;text-align:center">Noch keine Daueraufträge angelegt</div>';

  // New standing order form
  h+='<div class="sec-label" style="margin-top:12px">Neuer Dauerauftrag</div>';
  h+='<div class="crd"><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">';
  h+='<div><div class="sub" style="font-weight:600;margin-bottom:3px">Ware</div>';
  h+='<select class="sl" id="soGood" style="width:100%" onfocus="renderBlocked=true" onblur="renderBlocked=false"><option value="">Wählen…</option>';
  Object.entries(GOODS).forEach(([k,g])=>{h+='<option value="'+k+'">'+g.em+' '+g.name+'</option>'});h+='</select></div>';
  h+='<div><div class="sub" style="font-weight:600;margin-bottom:3px">Menge</div>';
  h+='<input type="number" class="sl" id="soAmt" value="5" min="1" max="50" style="width:100%" onfocus="renderBlocked=true" onblur="renderBlocked=false"/></div>';
  h+='<div><div class="sub" style="font-weight:600;margin-bottom:3px">Von</div>';
  h+='<select class="sl" id="soFrom" style="width:100%" onfocus="renderBlocked=true" onblur="renderBlocked=false"><option value="">Standort…</option>';
  cities.forEach(c=>{h+='<option value="'+c.id+'">'+c.name+'</option>'});h+='</select></div>';
  h+='<div><div class="sub" style="font-weight:600;margin-bottom:3px">Nach</div>';
  h+='<select class="sl" id="soTo" style="width:100%" onfocus="renderBlocked=true" onblur="renderBlocked=false"><option value="">Standort…</option>';
  cities.forEach(c=>{h+='<option value="'+c.id+'">'+c.name+'</option>'});h+='</select></div>';
  h+='</div><button class="btn full" style="margin-top:8px" onclick="createStandingOrder()">🔄 Dauerauftrag anlegen</button></div>';
  el.innerHTML=h}

// ═══ BUILDINGS (3 sub-tabs: Verwalten, Bauen, Infrastruktur) ═══
