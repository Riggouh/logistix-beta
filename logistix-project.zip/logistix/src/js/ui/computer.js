// ═══ COMPUTER ═══
function openComputer(){computerOpen=true;document.getElementById('computer').style.display='flex';
  if(!minimap){minimap=L.map('minimap',{zoomControl:false,attributionControl:false,dragging:true,scrollWheelZoom:true,doubleClickZoom:false}).setView([50,8],10);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',{maxZoom:19,subdomains:'abcd'}).addTo(minimap);setTimeout(()=>minimap.invalidateSize(),100)}
  document.getElementById('minimap-wrap').style.display=minimapOpen?'block':'none';updateMinimap();renComp()}
function closeComputer(){computerOpen=false;document.getElementById('computer').style.display='none';markDirty();applyView()}
function selectLocation(cid){G.sel=cid;routesShowAll=false;routesSub='city';try{udots()}catch(e){}if(computerOpen){updateMinimap();renComp()}else{const c=C(cid);if(c&&MP)MP.flyTo([c.lat,c.lng],Math.max(MP.getZoom(),9),{duration:.5});markDirty();ren()}}
function toggleBuildCity(cid){buildExpanded[cid]=!buildExpanded[cid];ren()}
function toggleMinimap(){minimapOpen=!minimapOpen;document.getElementById('minimap-wrap').style.display=minimapOpen?'block':'none';
  const btn=document.getElementById('mmToggle');if(btn){btn.innerHTML=minimapOpen?'🗺️ Karte ✓':'🗺️ Karte';btn.style.borderColor=minimapOpen?'var(--a)':'var(--bd)'}
  if(minimapOpen&&minimap)setTimeout(()=>{minimap.invalidateSize();updateMinimap()},100)}
function updateMinimap(){if(!minimap||!G)return;const c=G.sel?C(G.sel):null;if(c){minimap.setView([c.lat,c.lng],11,{animate:true,duration:.4});
  if(minimapPin)minimap.removeLayer(minimapPin);minimapPin=L.marker([c.lat,c.lng],{icon:L.divIcon({className:'',iconSize:[20,28],iconAnchor:[10,28],html:'<div style="font-size:24px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.6))">📍</div>'})}).addTo(minimap)}setTimeout(()=>minimap.invalidateSize(),150)}

// ═══ CORE RENDER ═══
function ua(){uhud();checkQuests();markDirty();ren();try{uvmk()}catch(e){}}
function full(){try{uhud()}catch(e){console.error(e)};markDirty();try{ren()}catch(e){console.error(e)};try{uvmk()}catch(e){}try{udots()}catch(e){}if(G)try{Object.keys(G.blds).forEach(ubmk)}catch(e){}updCnt()}
function updCnt(){try{document.getElementById('hCit').textContent=cities.length}catch(e){}}

function uhud(){if(!G)return;const m=fmt(G.money),cv=fmt(companyValue());
  const lvl=playerLvl();const li=LEVELS[lvl-1];
  try{document.getElementById('hLvl').innerHTML=li.em+' <b>'+lvl+'</b>';
  document.getElementById('hMoney').textContent=m;document.getElementById('hVal').textContent=cv;
  document.getElementById('hVeh').textContent=G.vehs.length;document.getElementById('hCit').textContent=cities.length;document.getElementById('hDel').textContent=G.dels}catch(e){}
  try{document.getElementById('cMoney').textContent=m;document.getElementById('cVeh').textContent=G.vehs.length;
  document.getElementById('cCities').textContent=cities.length;document.getElementById('cDel').textContent=G.dels}catch(e){}
}

let _dashDirty=true;
function ren(){
  if(!G)return;
  if(computerOpen){try{renComp()}catch(e){console.error('renComp error',e)};return}
  if(viewMode==='dashboard'){try{renDash()}catch(e){console.error('renDash error',e)}} // Always update for live countdowns
}
function markDirty(){_dashDirty=true}

function fmtOrd(n){return'#'+String(n||0).padStart(5,'0')}

function updateSelInfo(oid,needed){
  const el=document.getElementById('selInfo_'+oid);if(!el)return;
  const checks=document.querySelectorAll('.vc[data-oid="'+oid+'"]:checked');
  if(!checks.length){el.innerHTML='<span class="sub">Keine Fahrzeuge ausgewählt</span>';return}
  let totalCap=0,count=0;
  checks.forEach(cb=>{totalCap+=parseInt(cb.dataset.cap)||0;count++});
  const enough=totalCap>=needed;
  const color=enough?'var(--a)':'var(--go)';
  el.innerHTML='<span style="font-family:var(--mono);font-size:11px;font-weight:700;color:'+color+'">'+count+' Fahrzeug'+(count>1?'e':'')+' · Kapazität: '+totalCap+'/'+needed+(enough?' ✅':' ⚠️ reicht nicht')+'</span>';
}

