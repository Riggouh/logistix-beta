function compMissions(el){let h=tabHead('missions','<i class="ri-flag-line"></i> Missionen','Erfülle Aufgaben für Belohnungen');
  const tutDone=TUTORIAL.filter(q=>G.quests.tutorial[q.id]==='claimed').length;
  if(!G.quests.levelMissions)G.quests.levelMissions={};
  const lvl=playerLvl();
  const now=Date.now();
  // Tutorial icon mapping
  const tIco={t1:'ri-truck-line green',t2:'ri-building-line blue',t3:'ri-map-pin-add-line blue',t4:'ri-file-list-3-line gold',t5:'ri-checkbox-circle-line green',t6:'ri-box-3-line purple',t7:'ri-settings-3-line blue',t8:'ri-arrow-up-circle-line purple',t9:'ri-send-plane-line green',t10:'ri-refresh-line blue'};
  const lmIco={lm1:'ri-truck-fill green',lm2:'ri-leaf-line green',lm3:'ri-plant-line green',lm4:'ri-map-pin-line blue',lm5:'ri-truck-line green',lm6:'ri-link blue',lm7:'ri-building-fill blue',lm8:'ri-globe-line purple',lm9:'ri-box-3-fill green',lm10:'ri-earth-line blue',lm11:'ri-box-3-line purple',lm12:'ri-hammer-line gold',lm13:'ri-medal-line gold',lm14:'ri-globe-line purple',lm15:'ri-vip-crown-line gold',lm16:'ri-truck-fill green',lm17:'ri-earth-fill purple',lm18:'ri-star-fill gold'};

  // ── TUTORIAL ──
  h+='<div class="sec-label"><i class="ri-book-open-line"></i> Tutorial · '+tutDone+'/'+TUTORIAL.length+'</div>';
  if(tutDone<TUTORIAL.length){
    h+='<div class="pb" style="margin-bottom:8px"><div class="pf" style="width:'+(tutDone/TUTORIAL.length*100)+'%"></div></div>';
    let shown=0;
    TUTORIAL.forEach(q=>{const s=G.quests.tutorial[q.id];const done=s==='claimed';const rdy=s==='done';
      if(done)return;if(!rdy&&shown>=2)return;shown++;
      const ic=(tIco[q.id]||'ri-checkbox-blank-circle-line slate').split(' ');
      h+='<div class="crd q-card'+(rdy?' glow':'')+'">';
      h+='<div class="ico q-ico '+(rdy?'gold':ic[1])+'"><i class="'+(rdy?'ri-gift-line':ic[0])+'"></i></div>';
      h+='<div class="q-body">';
      h+='<div class="rw"><span class="q-title">'+q.name+'</span>';
      if(rdy)h+='<button class="btn sm" onclick="claimTutorial(\''+q.id+'\')"><i class="ri-gift-line"></i> '+fmt(q.reward)+'</button>';
      else h+='<span style="color:var(--go);font-family:var(--mono)">'+fmt(q.reward)+'</span>';
      h+='</div><div class="q-desc">'+q.desc+'</div>';
      if(q.prog&&!rdy){const p=q.prog();h+='<div class="q-prog"><div class="pb"><div class="pf" style="width:'+Math.min(100,p[1]?p[0]/p[1]*100:0)+'%"></div></div><span>'+p[0]+'/'+p[1]+'</span></div>'}
      h+='</div></div>'});
  } else h+='<div class="sub" style="text-align:center;color:var(--a);padding:6px"><i class="ri-check-double-line"></i> Alle Tutorials abgeschlossen!</div>';

  // ── LEVEL MISSIONS ──
  const availLM=LEVEL_MISSIONS.filter(q=>q.minLvl<=lvl);
  const lmDone=availLM.filter(q=>G.quests.levelMissions[q.id]==='claimed').length;
  if(availLM.length){
    h+='<div class="sec-label"><i class="ri-shield-star-line"></i> Level-Missionen · '+lmDone+'/'+availLM.length+'</div>';
    let lmShown=0;
    availLM.forEach(q=>{const s=G.quests.levelMissions[q.id];const done=s==='claimed';const rdy=s==='done';
      if(done)return;if(!rdy&&lmShown>=2)return;lmShown++;
      const ic=(lmIco[q.id]||'ri-star-line gold').split(' ');
      h+='<div class="crd q-card'+(rdy?' glow':'')+'">';
      h+='<div class="ico q-ico '+(rdy?'gold':ic[1])+'"><i class="'+(rdy?'ri-gift-line':ic[0])+'"></i></div>';
      h+='<div class="q-body">';
      h+='<div class="rw"><span class="q-title">'+q.name+'</span>';
      if(rdy)h+='<button class="btn sm" onclick="claimLevelMission(\''+q.id+'\')"><i class="ri-gift-line"></i> '+fmt(q.reward)+'</button>';
      else h+='<span style="color:var(--go);font-family:var(--mono)">'+fmt(q.reward)+'</span>';
      h+='</div><div class="q-desc">'+q.desc+'</div>';
      if(q.prog&&!rdy){const p=q.prog();h+='<div class="q-prog"><div class="pb"><div class="pf" style="width:'+Math.min(100,p[1]?p[0]/p[1]*100:0)+'%"></div></div><span>'+p[0]+'/'+p[1]+'</span></div>'}
      h+='</div></div>'});
    if(lmDone>=availLM.length&&availLM.length<LEVEL_MISSIONS.length){const nxt=LEVEL_MISSIONS.find(q=>q.minLvl>lvl);h+='<div class="sub" style="text-align:center;padding:4px"><i class="ri-lock-line"></i> Nächste ab Level '+(nxt?.minLvl||'?')+'</div>'}
  }

  // Icon mapping for quest types
  const qIco={d_del3:'ri-truck-line green',d_del6:'ri-truck-fill green',d_earn20:'ri-money-dollar-circle-line gold',d_earn50:'ri-money-dollar-circle-fill gold',d_build:'ri-building-line blue',d_upgrade2:'ri-arrow-up-circle-line purple',d_cities:'ri-map-pin-add-line blue',d_veh:'ri-truck-line green',
    w_del15:'ri-truck-line green',w_del30:'ri-truck-fill green',w_earn150:'ri-money-dollar-circle-line gold',w_earn500:'ri-coins-line gold',w_cities3:'ri-globe-line blue',w_build5:'ri-building-fill blue',w_upgrade5:'ri-arrow-up-circle-fill purple',w_km500:'ri-road-map-line green'};

  // ── DAILIES ──
  const ds=G.quests.dailies||[];
  if(ds.length){
    const nextDaily=G.quests.dailyTs?Math.max(0,G.quests.dailyTs+86400000-now):0;
    const dtStr=nextDaily>0?ftime(Math.floor(nextDaily/1000)):'bald';
    h+='<div class="sec-label"><i class="ri-calendar-line"></i> Tägliche Aufgaben <span style="font-weight:400;opacity:.6">· Neue in '+dtStr+'</span></div>';
    ds.forEach((q,i)=>{const def=DAILY_POOL.find(x=>x.id===q.id);if(!def)return;
      const p=def.prog?def.prog(q):null;const pct=p?Math.min(100,p[1]?p[0]/p[1]*100:0):0;
      const ic=qIco[q.id]||'ri-checkbox-blank-circle-line slate';const icParts=ic.split(' ');
      h+='<div class="crd q-card'+(q.done&&!q.claimed?' glow':'')+'">';
      h+='<div class="ico q-ico '+icParts[1]+'"><i class="'+icParts[0]+'"></i></div>';
      h+='<div class="q-body">';
      h+='<div class="rw"><span class="q-title">'+(def.name||'')+'</span>';
      if(q.done&&!q.claimed)h+='<button class="btn sm" onclick="claimDaily('+i+')"><i class="ri-gift-line"></i> '+fmt(q.reward)+'</button>';
      else if(q.claimed)h+='<span class="tg g"><i class="ri-check-line"></i> Erledigt</span>';
      else h+='<span style="color:var(--go);font-family:var(--mono)">'+fmt(q.reward)+'</span>';
      h+='</div>';
      if(!q.claimed){h+='<div class="q-desc">'+(def.desc||'')+'</div>';
        if(p){const fmtV=p[1]>=10000?fmt(Math.min(p[0],p[1]))+'/'+fmt(p[1]):Math.min(p[0],p[1])+'/'+p[1];
          h+='<div class="q-prog"><div class="pb"><div class="pf" style="width:'+pct+'%"></div></div><span>'+fmtV+'</span></div>'}}
      h+='</div></div>'})}

  // ── WEEKLIES ──
  const ws=G.quests.weeklies||[];
  if(ws.length){
    const nextWeekly=G.quests.weeklyTs?Math.max(0,G.quests.weeklyTs+604800000-now):0;
    const wtStr=nextWeekly>0?ftime(Math.floor(nextWeekly/1000)):'bald';
    h+='<div class="sec-label"><i class="ri-calendar-check-line"></i> Wöchentliche Aufgaben <span style="font-weight:400;opacity:.6">· Neue in '+wtStr+'</span></div>';
    ws.forEach((q,i)=>{const def=WEEKLY_POOL.find(x=>x.id===q.id);if(!def)return;
      const p=def.prog?def.prog(q):null;const pct=p?Math.min(100,p[1]?p[0]/p[1]*100:0):0;
      const ic=qIco[q.id]||'ri-checkbox-blank-circle-line slate';const icParts=ic.split(' ');
      h+='<div class="crd q-card'+(q.done&&!q.claimed?' glow':'')+'">';
      h+='<div class="ico q-ico '+icParts[1]+'"><i class="'+icParts[0]+'"></i></div>';
      h+='<div class="q-body">';
      h+='<div class="rw"><span class="q-title">'+(def.name||'')+'</span>';
      if(q.done&&!q.claimed)h+='<button class="btn sm" onclick="claimWeekly('+i+')"><i class="ri-gift-line"></i> '+fmt(q.reward)+'</button>';
      else if(q.claimed)h+='<span class="tg g"><i class="ri-check-line"></i> Erledigt</span>';
      else h+='<span style="color:var(--go);font-family:var(--mono)">'+fmt(q.reward)+'</span>';
      h+='</div>';
      if(!q.claimed){h+='<div class="q-desc">'+(def.desc||'')+'</div>';
        if(p){const fmtV=p[1]>=10000?fmt(Math.min(p[0],p[1]))+'/'+fmt(p[1]):Math.min(p[0],p[1])+'/'+p[1];
          h+='<div class="q-prog"><div class="pb"><div class="pf" style="width:'+pct+'%"></div></div><span>'+fmtV+'</span></div>'}}
      h+='</div></div>'})}
  el.innerHTML=h}

// ═══ LOCATIONS ═══
