// ══════════════════════════════════════════
// MAP (Leaflet + OSRM Road Routing)
// ══════════════════════════════════════════

let MP=null;
const cMk={},cLb={},bMk={},vMk={},rLn={};

function initMap(){
  if(MP)return;
  let mapEl=document.getElementById('map');
  if(!mapEl){
    mapEl=document.createElement('div');mapEl.id='map';
    mapEl.style.cssText='position:fixed;top:56px;left:0;right:0;bottom:0;display:none;z-index:3';
    document.body.appendChild(mapEl);
  }
  MP=L.map('map',{zoomControl:false,attributionControl:false}).setView([30,10],3);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',{
    maxZoom:19,subdomains:'abcd',
    attribution:'© <a href="https://www.openstreetmap.org/copyright">OSM</a> © <a href="https://carto.com/">CARTO</a>'
  }).addTo(MP);
  // Create search element
  let swEl=document.getElementById('sw');
  if(!swEl){
    swEl=document.createElement('div');swEl.id='sw';
    swEl.innerHTML='<span id="sico">🔍</span><input type="text" id="si" placeholder="Stadt suchen & freischalten..." autocomplete="off"/><div id="sr"></div>';
    document.body.appendChild(swEl);
    initGameSearch();
  }
}

// ── OSRM Route Fetching ──
async function fetchRoute(fLat,fLng,tLat,tLng){
  const key=fLat.toFixed(3)+','+fLng.toFixed(3)+'>'+tLat.toFixed(3)+','+tLng.toFixed(3);
  if(routeCache[key])return routeCache[key];
  try{
    const url='https://router.project-osrm.org/route/v1/driving/'+fLng+','+fLat+';'+tLng+','+tLat+'?overview=full&geometries=geojson';
    const r=await fetch(url);if(!r.ok)throw 0;
    const data=await r.json();
    if(data.routes&&data.routes[0]){
      const coords=data.routes[0].geometry.coordinates.map(c=>[c[1],c[0]]);
      routeCache[key]=coords;return coords;
    }
  }catch(e){}
  const fb=[[fLat,fLng],[tLat,tLng]];routeCache[key]=fb;return fb;
}

function ensureRoute(v){
  if(!v.rt)return;const f=C(v.rt.from)||Cx(v.rt.from),t=C(v.rt.to)||Cx(v.rt.to)||(v.rt.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);if(!f||!t)return;
  const key=f.lat.toFixed(3)+','+f.lng.toFixed(3)+'>'+t.lat.toFixed(3)+','+t.lng.toFixed(3);
  if(!routeCache[key])fetchRoute(f.lat,f.lng,t.lat,t.lng);
}

function interpRoute(coords,pct){
  if(!coords||coords.length<2)return null;
  if(pct<=0)return coords[0];if(pct>=1)return coords[coords.length-1];
  let td=0;const sd=[];
  for(let i=1;i<coords.length;i++){const d=Math.sqrt((coords[i][0]-coords[i-1][0])**2+(coords[i][1]-coords[i-1][1])**2);sd.push(d);td+=d}
  const tgt=pct*td;let acc=0;
  for(let i=0;i<sd.length;i++){if(acc+sd[i]>=tgt){const p=(tgt-acc)/sd[i];return[coords[i][0]+(coords[i+1][0]-coords[i][0])*p,coords[i][1]+(coords[i+1][1]-coords[i][1])*p]}acc+=sd[i]}
  return coords[coords.length-1];
}

function addCityMap(c){
  if(!MP)return;
  const sz=c.pop>5e6?18:c.pop>1e6?14:c.pop>5e5?11:c.pop>1e5?8:c.pop>20000?6:5;
  const mk=L.marker([c.lat,c.lng],{icon:L.divIcon({className:'',iconSize:[sz,sz],iconAnchor:[sz/2,sz/2],html:'<div class="city-dot" id="cd-'+c.id+'" style="width:'+sz+'px;height:'+sz+'px"></div>'})}).addTo(MP);
  mk.on('click',()=>sel(c.id));cMk[c.id]=mk;
  cLb[c.id]=L.marker([c.lat,c.lng],{icon:L.divIcon({className:'',iconSize:[0,0],iconAnchor:[-sz/2-3,7],html:'<div class="clb">'+c.name+'</div>'}),interactive:false}).addTo(MP);
}

function udots(){if(!MP)return;cities.forEach(c=>{const e=document.getElementById('cd-'+c.id);if(e)e.className='city-dot'+(G&&G.sel===c.id?' sel':'')+(((G&&G.blds[c.id]||[]).length>0)?' blt':'')})}
function updCnt_map(){try{document.getElementById('dbCit').textContent=cities.length}catch(e){}}

function ubmk(cid){
  if(!MP)return;
  (bMk[cid]||[]).forEach(m=>MP.removeLayer(m));bMk[cid]=[];
  if(!G)return;const c=C(cid),bs=G.blds[cid]||[];if(!c)return;
  bs.forEach((b,i)=>{const a=(i/Math.max(bs.length,1))*Math.PI*2,r=.006+i%2*.003;
    bMk[cid].push(L.marker([c.lat+Math.cos(a)*r,c.lng+Math.sin(a)*r*1.6],{icon:L.divIcon({className:'',iconSize:[24,24],iconAnchor:[12,12],html:'<div class="bi">'+BLD[b.type].em+'</div>'}),interactive:false}).addTo(MP))});
}

function uvmk(){
  if(!MP)return;
  Object.values(vMk).forEach(m=>MP.removeLayer(m));Object.values(rLn).forEach(l=>MP.removeLayer(l));
  for(const k in vMk)delete vMk[k];for(const k in rLn)delete rLn[k];if(!G)return;
  G.vehs.forEach(v=>{const vt=VT[v.type];
    if(v.st==='idle'){const c=C(v.loc);if(!c)return;
      vMk[v.id]=L.marker([c.lat-.003,c.lng+.005],{icon:L.divIcon({className:'',iconSize:[22,22],iconAnchor:[11,11],html:'<div class="vi">'+vt.em+'</div>'}),interactive:true}).addTo(MP);
      vMk[v.id].bindTooltip(vt.name+' · '+c.name,{direction:'top',offset:[0,-10]});
    } else if(v.rt){
      const f=C(v.rt.from)||Cx(v.rt.from),t=C(v.rt.to)||Cx(v.rt.to)||(v.rt.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);if(!f||!t)return;
      const tn=tripT(f,t,vt.spd),pct=Math.min(v.prog/tn,1);
      const cargo=v.cargo?(GOODS[v.cargo.good]?.em||'')+' '+v.cargo.amt+'×':'leer';
      const tip=vt.em+' '+vt.name+'<br>'+f.name+' → '+t.name+'<br>'+cargo+' · '+Math.floor(pct*100)+'%';
      const rk=f.lat.toFixed(3)+','+f.lng.toFixed(3)+'>'+t.lat.toFixed(3)+','+t.lng.toFixed(3);
      const cached=routeCache[rk];
      if(cached&&cached.length>2){
        rLn[v.id]=L.polyline(cached,{color:'#3dd68c',weight:3,opacity:.5}).addTo(MP);
        const pos=interpRoute(cached,pct);
        if(pos){vMk[v.id]=L.marker(pos,{icon:L.divIcon({className:'',iconSize:[24,24],iconAnchor:[12,12],html:'<div class="vi" style="font-size:20px">'+vt.em+'</div>'}),interactive:true}).addTo(MP);
        vMk[v.id].bindTooltip(tip,{direction:'top',offset:[0,-10]});}
      } else {
        rLn[v.id]=L.polyline([[f.lat,f.lng],[t.lat,t.lng]],{color:'#3dd68c',weight:2.5,opacity:.35,dashArray:'8,6'}).addTo(MP);
        const lat=f.lat+(t.lat-f.lat)*pct,lng=f.lng+(t.lng-f.lng)*pct;
        vMk[v.id]=L.marker([lat,lng],{icon:L.divIcon({className:'',iconSize:[24,24],iconAnchor:[12,12],html:'<div class="vi" style="font-size:20px">'+vt.em+'</div>'}),interactive:true}).addTo(MP);
        vMk[v.id].bindTooltip(tip,{direction:'top',offset:[0,-10]});
        ensureRoute(v);
      }
    }
  });
}
