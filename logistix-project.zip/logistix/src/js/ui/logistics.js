function compLogistics(el){
  if(!G.logSub)G.logSub='orders';
  if(G.logSub==='standing'){compStanding(el);return}
  if(G.logSub==='transfer'){compTransfer(el);return}
  if(G.logSub==='routes'){compRoutes(el);return}
  if(G.logSub==='vehicles'){compVehiclesOverview(el);return}
  if(G.logSub==='stats'||G.logSub==='history'){G.orderSub=G.logSub;compOrders(el);return}
  G.orderSub='overview';compOrders(el);
}
function compOrders(el){
  if(!G.orderSub)G.orderSub='overview';
  const filterCity=G.sel&&compTab==='logistics'&&G.logSub==='orders'?G.sel:null;
  const allAcc=G.orders.filter(o=>o.acc);const allOpen=G.orders.filter(o=>!o.acc);
  const acc=filterCity?allAcc.filter(o=>o.from===filterCity||o.to===filterCity):allAcc;
  const open=filterCity?allOpen.filter(o=>o.from===filterCity||o.to===filterCity):allOpen;
  const hist=G.history||[];let h='';
  if(filterCity){const cn=C(filterCity);h+='<div class="sub" style="margin-bottom:6px;padding:5px 8px;background:rgba(61,214,140,.04);border:1px solid rgba(61,214,140,.12);border-radius:8px">📍 <b>'+(cn?.name||'?')+'</b> <button class="btn sm" onclick="G.sel=null;renComp()" style="margin-left:6px">✕ Alle</button></div>';}

  if(G.orderSub==='overview'){
    // Summary
    const running=acc.filter(o=>G.vehs.find(x=>x.cargo?.oid===o.id&&x.st==='moving'));
    const waiting=acc.filter(o=>!G.vehs.find(x=>x.cargo?.oid===o.id&&x.st==='moving')&&(o.amt-(o.shipped||0))>0);
    h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">';
    h+='<span class="tg y">🔶 '+running.length+' laufend</span><span class="tg">📋 '+waiting.length+' wartend</span><span class="tg g">📬 '+open.length+' verfügbar</span></div>';

    // Active
    if(acc.length){h+='<div class="sec-label">📋 Aktive Aufträge · '+acc.length+'</div>';
    acc.forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
      const vehs=G.vehs.filter(x=>x.cargo?.oid===o.id&&x.st==='moving');
      const shipped=o.shipped||0;const delivered=o.delivered||0;const remaining=o.amt-shipped;
      const pctDel=delivered/o.amt;const transitAmt=vehs.reduce((s,v)=>s+(v.cargo?.amt||0),0);
      h+='<div class="crd"><div class="rw"><span style="font-weight:600">'+(GOODS[o.good]?.em||'')+' '+o.amt+'× '+(GOODS[o.good]?.name||'')+'</span>';
      h+='<span style="color:var(--a);font-family:var(--mono);font-weight:700">'+fmt(o.rew)+'</span></div>';
      h+='<div class="sub">'+f.name+' → '+t.name+' · '+fdist(f,t)+' km</div>';
      h+='<div class="pb" style="margin:4px 0"><div class="pf" style="width:'+Math.min(pctDel*100,100)+'%"></div></div>';
      h+='<div style="display:flex;gap:8px;font-size:10px;color:var(--td)"><span>✅ '+delivered+'/'+o.amt+'</span>';
      if(transitAmt>0)h+='<span>🚛 '+transitAmt+' unterwegs</span>';
      if(remaining>0&&!vehs.length)h+='<span style="color:var(--go)">📦 '+remaining+' verbleibend</span>';
      h+='</div>';
      vehs.forEach(v=>{const vt=VT[v.type],tn=tripT(f,t,vt.spd),pct=Math.min(v.prog/tn,1);
        h+='<div style="display:flex;align-items:center;gap:6px;margin-top:3px;font-size:10px;color:var(--td)">'+vt.em+' '+vehName(v)+' · '+v.cargo.amt+'× · <b style="color:var(--a)">'+Math.floor(pct*100)+'%</b> · '+ftime(Math.max(0,tn-v.prog))+'</div>'});
      // Approaching vehicles
      const approaching=G.vehs.filter(v=>v.st==='moving'&&v.followUpOrder===o.id&&!v.cargo?.oid);
      approaching.forEach(v=>{const vt=VT[v.type];h+='<div style="font-size:10px;color:#a855f7;margin-top:2px">'+vt.em+' '+vehName(v)+' auf Anfahrt...</div>'});
      // Actions
      if(remaining>0){
        h+='<div style="display:flex;gap:4px;margin-top:5px;flex-wrap:wrap">';
        const avlL=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from&&canVehTravel(v,o.to));
        const avlR=G.vehs.filter(v=>v.st==='idle'&&v.loc!==o.from&&canVehTravel(v,o.from));
        if(avlL.length)h+='<button class="btn sm" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.3)" onclick="autoAssign(\''+o.id+'\')">⚡ Senden (🚛'+avlL.length+')</button>';
        if(avlR.length)h+='<button class="btn sm" style="color:var(--a2);border-color:rgba(56,189,248,.3)" onclick="G._remoteOid=\''+o.id+'\';renComp()">📍 Anderer Standort ('+avlR.length+')</button>';
        if(!avlL.length&&!avlR.length)h+='<span class="sub" style="color:var(--r);padding:3px 0">❌ Kein Fahrzeug</span>';
        h+='<button class="btn red sm" onclick="cancelO(\''+o.id+'\')">Stornieren</button></div>';}
      // Remote picker
      if(G._remoteOid===o.id){
        const remV=G.vehs.filter(v=>v.st==='idle'&&v.loc!==o.from&&canVehTravel(v,o.from)).sort((a2,b)=>{
          const da=hav(C(a2.loc)?.lat||0,C(a2.loc)?.lng||0,f.lat,f.lng);const db=hav(C(b.loc)?.lat||0,C(b.loc)?.lng||0,f.lat,f.lng);return da-db});
        h+='<div style="margin-top:6px;padding:8px;border:1px solid rgba(56,189,248,.2);border-radius:8px;background:rgba(56,189,248,.03)">';
        h+='<div style="font-size:11px;font-weight:600;color:var(--a2);margin-bottom:3px">📍 Fahrzeug von anderem Standort</div>';
        h+='<div class="sub" style="margin-bottom:4px">Fährt erst zum Abholort, dann startet der Auftrag automatisch.</div>';
        remV.slice(0,6).forEach(v=>{const vt=VT[v.type];const loc=C(v.loc);if(!loc)return;
          const dist=Math.round(hav(loc.lat,loc.lng,f.lat,f.lng));const tt=tripT(loc,f,vt.spd);
          h+='<div class="crd" style="padding:3px 8px;cursor:pointer" onclick="remoteAssign(\''+v.id+'\',\''+o.id+'\');G._remoteOid=null">';
          h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> · Kap: '+vehCap(v)+'</span>';
          h+='<span class="sub">📍 '+loc.name+' · '+dist+' km · '+ftime(tt)+'</span></div></div>'});
        h+='<button class="btn sm" style="margin-top:4px" onclick="G._remoteOid=null;renComp()">✕ Schließen</button></div>';}
      h+='</div>'});}

    // Available
    h+='<div class="sec-label">📬 Verfügbar · '+open.length+'</div>';
    if(!open.length)h+='<div class="sub" style="padding:12px;text-align:center;color:var(--td)">Keine Aufträge — produziere Waren!</div>';
    open.forEach(o=>{const f=Cx(o.from),t=Cx(o.to);if(!f||!t)return;
      const inS=(G.stor[o.from]?.[o.good]||0);
      const avlL=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from&&canVehTravel(v,o.to));
      const avlR=G.vehs.filter(v=>v.st==='idle'&&v.loc!==o.from&&canVehTravel(v,o.from));
      const canAcc=inS>=1;
      const isE=o.type==='express';const tl=Math.max(0,o.tl-(G.tick-o.born));
      const ppu=o.pricePerUnit||Math.round(o.rew/o.amt);
      const mktP=o.mktRef||BASE_PRICES[o.good]||100;
      const prem=Math.round((ppu/mktP-1)*100);
      h+='<div class="crd" style="'+(isE?'border-left:3px solid var(--go);background:rgba(251,191,36,.02)':'')+'">';
      h+='<div class="rw"><span style="font-weight:600">'+(isE?'⚡ ':'')+(GOODS[o.good]?.em||'')+' '+o.amt+'× '+(GOODS[o.good]?.name||'')+'</span>';
      h+='<span style="color:var(--a);font-family:var(--mono);font-weight:700">'+fmt(o.rew)+'</span></div>';
      h+='<div class="rw"><span class="sub">'+f.name+' → '+t.name+(o.toUnlocked===false?' 🔓':'')+' · '+fdist(f,t)+' km</span>';
      h+='<span class="sub" style="font-family:var(--mono);'+(tl<120?'color:var(--r)':'')+'">⏱ '+ftime(tl)+'</span></div>';
      h+='<div style="display:flex;gap:8px;margin-top:3px;font-size:10px;color:var(--td)">';
      h+='<span>'+fmt(ppu)+'/St.</span><span style="color:var(--a)">+'+prem+'%</span><span>📦 '+inS+'/'+o.amt+'</span>';
      if(avlL.length)h+='<span>🚛 '+avlL.length+'</span>';
      else if(avlR.length)h+='<span style="color:var(--a2)">📍 '+avlR.length+' andernorts</span>';
      h+='</div>';
      h+='<div style="display:flex;gap:4px;margin-top:5px">';
      h+='<button class="btn sm'+(canAcc?'':' off')+'" onclick="accO(\''+o.id+'\')">Annehmen</button>';
      if(canAcc&&avlL.length)h+='<button class="btn sm" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.3)" onclick="accO(\''+o.id+'\');setTimeout(()=>autoAssign(\''+o.id+'\'),50)">⚡ Auto</button>';
      if(canAcc&&avlR.length)h+='<button class="btn sm" style="color:var(--a2);border-color:rgba(56,189,248,.3)" onclick="accO(\''+o.id+'\');setTimeout(()=>{G._remoteOid=\''+o.id+'\';renComp()},50)">📍 Fernfahrzeug</button>';
      h+='<button class="btn red sm" onclick="declineO(\''+o.id+'\')">✕</button></div></div>'});
  }

  if(G.orderSub==='stats'){
    const totalDels=G.dels||0;const totalRev=G.earned||0;const totalKm=G.vehs.reduce((s,v)=>s+(v.km||0),0);
    h+='<div class="sec-label">Übersicht</div>';
    h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:10px">';
    [['📦',totalDels,'Lieferungen'],['💰',fmt(totalRev),'Umsatz'],['🛣️',totalKm.toLocaleString('de-DE')+' km','Gefahren']].forEach(([em,val,lbl])=>{
      h+='<div class="crd" style="text-align:center"><div style="font-size:20px">'+em+'</div><div style="font-family:var(--mono);color:var(--a);font-weight:700">'+val+'</div><div class="sub">'+lbl+'</div></div>'});
    h+='</div>';
    const gS={};(G.history||[]).forEach(x=>{if(!gS[x.good])gS[x.good]={cnt:0,amt:0,rev:0};gS[x.good].cnt++;gS[x.good].amt+=x.amt;gS[x.good].rev+=x.rew});
    const sorted=Object.entries(gS).sort((a,b)=>b[1].rev-a[1].rev);
    if(sorted.length){h+='<div class="sec-label">Waren-Ranking</div>';
      sorted.forEach(([g,s],i)=>{const gd=GOODS[g];
        h+='<div class="crd" style="padding:6px 10px"><div class="rw"><span>'+(i+1)+'. '+(gd?.em||'')+' '+(gd?.name||g)+'</span><span style="font-family:var(--mono);color:var(--a)">'+fmt(s.rev)+'</span></div>';
        h+='<div class="sub">'+s.cnt+' Lief. · '+s.amt+' Stk.</div></div>'})}
  }
  if(G.orderSub==='history'){
    h+='<div class="sub" style="margin-bottom:8px">'+hist.length+' Lieferungen · '+fmt(hist.reduce((s,x)=>s+x.rew,0))+' Umsatz</div>';
    if(!hist.length)h+='<div class="sub" style="padding:12px;text-align:center">Noch keine</div>';
    hist.slice().reverse().slice(0,30).forEach(x=>{
      const isE=x.express;const isM=x.to&&x.to.startsWith('market');
      h+='<div class="crd" style="padding:5px 10px;'+(isE?'border-left:3px solid var(--go)':isM?'border-left:3px solid var(--bl)':'')+'"><div class="rw"><span>'+(isE?'⚡ ':isM?'💰 ':'')+(GOODS[x.good]?.em||'')+' '+x.amt+'×</span><span style="color:var(--a);font-family:var(--mono)">+'+fmt(x.rew)+'</span></div>';
      h+='<div class="sub">'+(C(x.from)?.name||Cx(x.from)?.name||'?')+' → '+(isM?'Markt':(C(x.to)?.name||Cx(x.to)?.name||'?'))+'</div></div>'});
  }
  el.innerHTML=h}
