async function showProfile(){
  if(!G)return;
  let existing=document.getElementById('profilePopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='profilePopup';popup.className='unlock-bg';
  const lvl=playerLvl();const li=LEVELS[lvl-1];
  const totalBld=Object.values(G.blds).flat().length;
  const totalKm=G.vehs.reduce((s,v)=>s+(v.km||0),0);
  const cv=companyValue();
  const regCount={};cities.forEach(c=>{const r=getRegion((c.co||'').toUpperCase());const ri=REGIONS[r];regCount[ri?ri.name:'?']=(regCount[ri?ri.name:'?']||0)+1});

  // Save score for leaderboard
  try{await window.storage.set('lb:'+currentUser,JSON.stringify({name:currentUser,lvl,dels:G.dels||0,value:cv,cities:cities.length}),true)}catch(e){}

  let h='<div class="unlock-popup" style="width:500px;max-height:85vh;overflow-y:auto"><div class="unlock-body">';
  h+='<div class="unlock-name" style="font-size:24px">👤 '+currentUser+'</div>';
  h+='<div style="text-align:center;margin:14px 0"><span style="font-size:36px">'+li.em+'</span><div style="font-family:var(--mono);font-size:14px;font-weight:700;color:var(--a);margin-top:6px">Level '+lvl+' – '+li.name+'</div></div>';
  h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0">';
  [['💰','Unternehmenswert',fmt(cv)],['🏦','Kontostand',fmt(G.money)],['📦','Lieferungen',(G.dels||0).toString()],['💵','Umsatz',fmt(G.earned||0)],
   ['🏙️','Standorte',cities.length.toString()],['🏭','Gebäude',totalBld.toString()],['🚛','Fahrzeuge',G.vehs.length.toString()],['🛣️','km',totalKm.toLocaleString('de-DE')],
   ['⏱️','Spielzeit',ftime(G.tick||0)],['🌍','Regionen',Object.keys(regCount).length.toString()]].forEach(([em,label,val])=>{
    h+='<div style="padding:12px;background:rgba(255,255,255,.02);border:1px solid var(--bd);border-radius:10px;text-align:center">';
    h+='<div style="font-size:22px">'+em+'</div><div style="font-family:var(--mono);font-size:18px;font-weight:700;color:var(--a)">'+val+'</div>';
    h+='<div style="font-size:13px;color:var(--td)">'+label+'</div></div>'});
  h+='</div>';
  const vTypes={};G.vehs.forEach(v=>{const vt=VT[v.type];if(vt){vTypes[v.type]=(vTypes[v.type]||0)+1}});
  if(Object.keys(vTypes).length){h+='<div class="sec-label">Fahrzeugflotte</div>';
    Object.entries(vTypes).forEach(([t,n])=>{const vt=VT[t];h+='<div class="sub">'+vt.em+' '+vt.name+' ×'+n+'</div>'});}
  h+='<button class="btn full" style="margin-top:16px" onclick="document.getElementById(\'profilePopup\').remove()">Schließen</button>';
  h+='</div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}

async function showLeaderboard(){
  let existing=document.getElementById('lbPopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='lbPopup';popup.className='unlock-bg';
  // Save own score
  const cv=G?companyValue():0;const plvl=G?playerLvl():1;
  if(G){try{await window.storage.set('lb:'+currentUser,JSON.stringify({name:currentUser,lvl:plvl,dels:G.dels||0,value:cv,cities:cities.length,ally:G.alliance||''}),true)}catch(e){}}
  // Load all scores with robust fallback
  let entries=[];
  try{const keys=await window.storage.list('lb:',true);
    if(keys&&keys.keys&&keys.keys.length){for(const k of keys.keys){try{const r=await window.storage.get(k,true);if(r&&r.value)entries.push(JSON.parse(r.value))}catch(e){}}}}catch(e){}
  // Fallback: at least show own entry
  if(!entries.length&&G)entries=[{name:currentUser,lvl:plvl,dels:G.dels||0,value:cv,cities:cities.length}];
  entries.sort((a,b)=>(b.value||0)-(a.value||0));
  // Alliance leaderboard
  let allyEntries=[];
  try{const allAlliances=await getAlliances();allyEntries=Object.values(allAlliances).sort((a,b)=>allianceValue(b)-allianceValue(a))}catch(e){}

  let h='<div class="unlock-popup" style="width:560px;max-height:85vh;overflow-y:auto"><div class="unlock-body">';
  h+='<div style="text-align:center;margin-bottom:12px"><span style="font-size:28px">🏆</span><div style="font-family:var(--mono);font-size:14px;font-weight:700;color:var(--a);margin-top:4px">Leaderboard</div></div>';
  // Tabs
  if(!window._lbTab)window._lbTab='players';
  h+='<div style="display:flex;gap:4px;margin-bottom:10px">';
  h+='<button class="btn sm'+(window._lbTab==='players'?' on':'')+'" style="'+(window._lbTab==='players'?'background:var(--a);color:var(--bg);border-color:var(--a)':'')+'" onclick="window._lbTab=\'players\';showLeaderboard()">👤 Spieler</button>';
  h+='<button class="btn sm'+(window._lbTab==='alliances'?' on':'')+'" style="'+(window._lbTab==='alliances'?'background:#a855f7;color:#fff;border-color:#a855f7':'')+'" onclick="window._lbTab=\'alliances\';showLeaderboard()">🤝 Allianzen</button>';
  h+='</div>';

  if(window._lbTab==='players'){
    const myRank=entries.findIndex(x=>x.name===currentUser)+1;
    if(myRank)h+='<div class="sub" style="text-align:center;margin-bottom:8px">Platz <b style="color:var(--a)">#'+myRank+'</b> von '+entries.length+'</div>';
    if(!entries.length)h+='<div class="sub" style="text-align:center;padding:16px">Noch keine Einträge</div>';
    const medals=['🥇','🥈','🥉'];
    entries.slice(0,20).forEach((e,i)=>{
      const isMe=e.name===currentUser;const li=LEVELS[Math.min((e.lvl||1)-1,LEVELS.length-1)];
      h+='<div class="crd" style="padding:5px 8px;'+(isMe?'border-color:var(--a);background:rgba(61,214,140,.04)':'')+'">';
      h+='<div class="rw"><span style="'+(isMe?'font-weight:700;color:var(--a)':'')+'"><span style="min-width:28px;display:inline-block">'+(medals[i]||(i+1)+'.')+'</span>'+(li?.em||'')+' '+e.name+'</span>';
      h+='<span style="font-family:var(--mono);color:var(--a);font-weight:700">'+fmt(e.value||0)+'</span></div>';
      h+='<div class="sub">Lvl '+(e.lvl||1)+' · '+(e.dels||0)+' Lief. · '+(e.cities||1)+' Städte</div></div>'});
  } else {
    if(!allyEntries.length)h+='<div class="sub" style="text-align:center;padding:16px">Noch keine Allianzen</div>';
    const medals=['🥇','🥈','🥉'];
    allyEntries.slice(0,20).forEach((a,i)=>{const lv=ALLIANCE_LEVELS[a.level-1];const isMine=G&&G.alliance===a.id;
      h+='<div class="crd" style="padding:5px 8px;'+(isMine?'border-color:#a855f7;background:rgba(168,85,247,.04)':'')+'">';
      h+='<div class="rw"><span style="'+(isMine?'font-weight:700;color:#a855f7':'')+'"><span style="min-width:28px;display:inline-block">'+(medals[i]||(i+1)+'.')+'</span>['+a.tag+'] '+a.name+'</span>';
      h+='<span style="font-family:var(--mono);color:#a855f7;font-weight:700">'+fmt(allianceValue(a))+'</span></div>';
      h+='<div class="sub">Lvl '+a.level+' '+(lv?.name||'')+' · 👥'+a.members.length+' · 🏴'+a.territories.length+' · 🏭'+a.buildings.length+'</div></div>'});
  }
  h+='<button class="btn full" style="margin-top:12px" onclick="document.getElementById(\'lbPopup\').remove()">Schließen</button>';
  h+='</div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}
// ══════════════════════════════════════════

