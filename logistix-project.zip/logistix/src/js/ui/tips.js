// ═══ TAB TUTORIALS & TIPS ═══
const TAB_TIPS={
  missions:{title:'🎯 Missionen',tutorial:'Missionen geben dir Ziele und Belohnungen. Tutorial-Missionen führen dich durch die Grundlagen. Tägliche und wöchentliche Aufgaben erneuern sich automatisch und zeigen Fortschrittsbalken.',
    tips:['Klicke "Einlösen" sobald eine Mission grün leuchtet','Tägliche Aufgaben: 3 neue alle 24h · Wöchentliche: 3 neue pro Woche','Level-Missionen schalten sich mit steigendem Level frei','📖 Mehr im LogistiX-Wiki (Hamburger-Menü)']},
  dealer:{title:'🛒 Händler',tutorial:'Kaufe und verkaufe Fahrzeuge. Jedes Fahrzeug wird einem Depot zugewiesen. Unter "Verkaufen" im Explorer kannst du Fahrzeuge verwalten und rückrufen.',
    tips:['Fahrzeuge bleiben fest an ihr Depot gebunden','Depot-Kapazität begrenzt die Anzahl — Depot ausbauen unter Fuhrpark','Züge brauchen Bahnhof, Schiffe Hafen, Flugzeuge Flughafen an BEIDEN Enden','Verkauf nur möglich wenn das Fahrzeug im Heimat-Depot steht','📖 Alle Fahrzeugtypen im Wiki']},
  fleet:{title:'🚛 Fuhrpark',tutorial:'Übersicht aller Fahrzeuge pro Standort. Unter "Wartung" im Explorer siehst du den Zustand aller Fahrzeuge und kannst Wartungen durchführen oder Rückrufe planen.',
    tips:['Wartung ist km-basiert: LKW alle 10.000 km, Züge 25.000, Schiffe 50.000, Flugzeuge 15.000','Depot ausbauen: +2 Stellplätze pro Upgrade (max 5×)','🔙 "An Depot" schickt idle Fahrzeuge zurück','Zustandsbalken: 🟢>60% 🟡>30% 🔴<30%','📖 Details im Wiki']},
  logistics:{title:'📋 Logistik',tutorial:'Aufträge, Routen, Transfers und Daueraufträge — alles an einem Ort. Aufträge gehen an Städte im Umkreis (auch nicht freigeschaltete). Preis pro Stück, Transportkosten und Nettogewinn werden angezeigt.',
    tips:['Aufträge zahlen 1,3-3× Marktpreis — immer mehr als Marktverkauf','⚡ Express-Aufträge zahlen 2× aber mit Zeitlimit','Fahrzeuge kehren nach Lieferung an nicht-freigeschaltete Orte automatisch zurück','🤖 Auto-Manager ab Level 5: akzeptiert und verschickt automatisch','📖 Wirtschaftssystem im Wiki']},
  inventory:{title:'📦 Lager',tutorial:'Warenbestand pro Standort. Verkaufe am Markt (💰) oder versende Waren (📦) an andere Standorte. Marktverkauf erfordert ein Fahrzeug das die Ware zum Marktplatz fährt.',
    tips:['Preis/St. zeigt den aktuellen regionalen Marktpreis','💰 Verkaufen öffnet ein Popup mit Mengenauswahl und Preiskalkulation','Das Fahrzeug fährt sichtbar zum Markt und kehrt automatisch zurück','Jede Stadt hat 100 Basis-Lagerplätze, erweiterbar per Infrastruktur','📖 Lagersystem im Wiki']},
  market:{title:'📊 Markt',tutorial:'Regionale Marktpreise für alle Waren. Preise schwanken basierend auf Region und Events. Unter "Verkaufen" siehst du Zielstädte und Transportkosten.',
    tips:['▲▼ Trend-Pfeile zeigen Preisentwicklung der letzten 10 Minuten','Klicke auf eine Ware für Detail-Ansicht mit Preisverlauf-Chart','Events beeinflussen Preise: Boom +30%, Rezession -15%','Logistikzentrum-Infrastruktur gibt +15% auf Marktpreise','📖 Preissystem im Wiki']},
  build:{title:'🏗️ Bauen',tutorial:'Baue Produktionsgebäude, Lagerhallen und regionale Farmen. Verfügbarkeit hängt von Level, Region und Stadtgröße ab.',
    tips:['Rohstoff-Gebäude (Farmen, Minen) produzieren ohne Input','Fabriken brauchen Rohstoffe als Input — Rezept wählen!','Regionale Gebäude nur in passenden Regionen baubar','Stadtgröße bestimmt maximale Gebäudeanzahl','📖 Gebäudeliste im Wiki']},
  buildings:{title:'🏭 Gebäude verwalten',tutorial:'Upgrades, Rezeptauswahl und Überlauf-Steuerung. Gebäudekapazität speichert Produktion direkt. Überlauf ins Stadtlager oder Produktion stoppen.',
    tips:['5 Upgrade-Tracks: Output, Speed, Effizienz, Lager, Rezepte','Überlauf: "Stadt" = ins Stadtlager, "Stop" = Produktion pausiert','Alle 25-35 Sekunden wird produziert','📖 Upgrade-System im Wiki']},
  infra:{title:'🏢 Infrastruktur',tutorial:'Depot, Bahnhof, Hafen, Flughafen, Logistikzentrum, Tankstelle und Lager. Verkehrsinfrastruktur wird an BEIDEN Endpunkten benötigt!',
    tips:['Depot: Basis 3 Stellplätze, 5× upgradbar (+2 pro Level)','Bahnhof/Hafen/Flughafen an BEIDEN Städten nötig','Logistikzentrum: +15% Marktpreise','Tankstelle: +10% Fahrzeuggeschwindigkeit','📖 Infrastruktur im Wiki']},
  alliance:{title:'🤝 Allianz',tutorial:'Gründe oder tritt einer Allianz bei. Gemeinsam könnt ihr Spezialwaren produzieren, Gebiete beanspruchen und auf der Börse handeln.',
    tips:['Gründungskosten: 25.000€ · Allianzkasse ist getrennt vom Spielerkonto','Rohstoffe müssen von Spielern geliefert werden — keine Eigenproduktion','Gebiete kosten 10× ihre Grundgebühr und bringen passive Einnahmen','Gebietsbörse: Gebiete zwischen Allianzen handeln','Level-Ups schalten mehr Mitglieder und Gebäudeslots frei','📖 Details im Wiki']},
  standing:{title:'🔄 Daueraufträge',tutorial:'Automatische Warentransporte zwischen deinen Standorten. Alle 60 Sekunden wird geprüft ob Ware + Fahrzeug bereit sind.',
    tips:['Festes Fahrzeug zuweisen → kehrt nach Lieferung automatisch zurück','Pausiert automatisch wenn Ware oder Fahrzeug fehlt','📖 Automatisierung im Wiki']},
};

function tipBtn(tab){
  const t=TAB_TIPS[tab];if(!t)return'';
  return' <button class="tip-btn" onclick="showTabTip(\''+tab+'\')">💡</button>';
}

function showTabTip(tab){
  const t=TAB_TIPS[tab];if(!t)return;
  let existing=document.getElementById('tipPopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='tipPopup';popup.className='tip-popup-bg';
  let h='<div class="tip-popup"><div class="tip-title">'+t.title+'</div>';
  h+='<div class="tip-tutorial">'+t.tutorial+'</div>';
  if(t.tips&&t.tips.length){h+='<div class="tip-section">Tipps</div>';
    t.tips.forEach(tip=>{h+='<div class="tip-item">💡 '+tip+'</div>'});}
  h+='<button class="btn full" style="margin-top:10px" onclick="document.getElementById(\'tipPopup\').remove()">Verstanden</button></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}

function tabHead(tab,title,sub){
  return'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><div style="font-family:var(--mono);font-size:20px;font-weight:700;color:var(--a)">'+title+'</div><button class="tip-btn" onclick="showTabTip(\''+tab+'\')">💡 Hilfe</button></div>'+(sub?'<div class="sub" style="margin-bottom:8px">'+sub+'</div>':'');
}

