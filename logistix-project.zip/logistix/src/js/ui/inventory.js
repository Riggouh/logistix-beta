function compInventory(el){if(!G.sel&&cities.length)G.sel=cities[0].id;let h=tabHead('inventory','📦 Lager','Warenbestand · Markt · Versand');let ti=0,tc2=0;const gs={};
  cities.forEach(c=>{const s=G.stor[c.id]||{},bs=G.blds[c.id]||[];const cap=cityCap(c.id);
    tc2+=cap;const tot=Object.values(s).reduce((a,v)=>a+v,0);ti+=tot;Object.entries(s).forEach(([g,a])=>{if(a>0)gs[g]=(gs[g]||0)+a})});
  h+='<div class="crd"><div class="rw"><span>Gesamtbestand</span><span style="font-family:var(--mono);color:var(--a)">'+ti+'/'+tc2+'</span></div><div class="pb"><div class="pf" style="width:'+Math.min(100,tc2?ti/tc2*100:0)+'%"></div></div></div>';

  // Per-city: stock + market sell + send
  cities.forEach(c=>{const s=G.stor[c.id]||{},items=Object.entries(s).filter(([,a])=>a>0);
    const tot=items.reduce((a,[,v])=>a+v,0);
    const cap=cityCap(c.id);
    const reg=getRegion((c.co||'').toUpperCase());
    h+='<div class="crd"><div class="rw"><span style="font-weight:600">'+cSzIcon(c.pop)+' '+c.name+'</span><span style="font-family:var(--mono);font-size:10px">'+tot+'/'+cap+'</span></div>';
    if(items.length){
      items.forEach(([g,amt])=>{
        const price=marketPrice(g,reg);
        const vHere=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id);
        const bestV=vHere.length?vHere.sort((a,b)=>vehCap(b)-vehCap(a))[0]:null;
        const maxSell=bestV?Math.min(amt,vehCap(bestV)):0;
        const transportCost=bestV?Math.round(VT[bestV.type].mt*0.5*Math.min(amt,10)):0;
        const revenue10=price*Math.min(amt,10);
        h+='<div style="display:flex;align-items:center;gap:4px;padding:3px 0;font-size:11px;border-top:1px solid var(--bd)">';
        h+='<span style="min-width:60px">'+(GOODS[g]?.em||'')+' '+(GOODS[g]?.name||'')+' <b>'+amt+'</b></span>';
        h+='<span class="sub" style="min-width:45px;text-align:right">'+price.toLocaleString('de-DE')+'/St.</span>';
        if(maxSell>0){
          h+='<button class="btn sm" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.25)" onclick="showMarketSellPopup(\''+c.id+'\',\''+g+'\')">💰 Verkaufen</button>';
        } else h+='<span class="sub" style="color:var(--r)">🚛 fehlt</span>';
        if(cities.length>1)h+='<button class="btn sm" onclick="showSendGoodsPopup(\''+c.id+'\',\''+g+'\','+amt+')">📦</button>';
        h+='</div>'});
    } else h+='<div class="sub" style="opacity:.5">Leer</div>';
    h+='</div>'});
  el.innerHTML=h}

// ═══ MARKET ═══
function compMarket(el){
  if(!G.marketSub)G.marketSub='prices';
  let h=tabHead('market','<i class="ri-line-chart-line"></i> Markt','Regionale Preise · Verkauf · Trends');
  const myRegs=new Set();cities.forEach(c=>myRegs.add(getRegion((c.co||'').toUpperCase())));
  const regs=[...myRegs];

  if(G.marketSub==='prices'){
    // Active events affecting prices
    const gm=eventEffect('globalMult')||1;const rb=eventEffect('regionBonus')||{};const gb=eventEffect('goodBonus')||{};
    if(gm!==1||Object.keys(rb).length||Object.keys(gb).length){
      h+='<div style="padding:6px 10px;border-radius:8px;border:1px solid rgba(251,191,36,.3);background:rgba(251,191,36,.05);margin-bottom:8px;font-size:11px;color:var(--go)">';
      if(gm>1)h+='📈 Globaler Bonus: +'+Math.round((gm-1)*100)+'% ';
      if(gm<1)h+='📉 Globaler Malus: '+Math.round((gm-1)*100)+'% ';
      Object.entries(rb).forEach(([r,m])=>{h+=(REGIONS[r]?.em||'')+' '+r+': +'+(Math.round((m-1)*100))+'% '});
      Object.entries(gb).forEach(([g,m])=>{h+=(GOODS[g]?.em||'')+' '+(GOODS[g]?.name||'')+': +'+(Math.round((m-1)*100))+'% '});
      h+='</div>';}

    // Filter by category
    if(!G.marketFilter)G.marketFilter='all';
    h+='<div style="display:flex;gap:4px;margin-bottom:8px;flex-wrap:wrap">';
    [['all','Alle'],['roh','Rohstoffe'],['ver','Verarbeitet'],['lux','Luxus']].forEach(([k,l])=>{
      h+='<button class="btn sm'+(G.marketFilter===k?' on':'')+'" style="'+(G.marketFilter===k?'background:var(--a);color:var(--bg);border-color:var(--a)':'')+'" onclick="G.marketFilter=\''+k+'\';renComp()">'+l+'</button>'});
    h+='</div>';

    // Price table
    const goodKeys=Object.keys(BASE_PRICES).filter(g=>{
      if(G.marketFilter==='all')return true;
      const cat=GOODS[g]?.cat;
      if(G.marketFilter==='roh')return cat==='roh';
      if(G.marketFilter==='ver')return cat==='ver';
      if(G.marketFilter==='lux')return(GOODS[g]?.tier||0)>=3;
      return true;
    }).sort((a,b)=>(BASE_PRICES[b]||0)-(BASE_PRICES[a]||0));

    h+='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
    h+='<tr style="border-bottom:1px solid var(--bd)"><th style="text-align:left;padding:6px;color:var(--td)">Ware</th><th style="padding:6px;color:var(--td)">Basis</th>';
    regs.forEach(r=>{const ri=REGIONS[r];h+='<th style="padding:6px;color:'+(ri?.color||'var(--td)')+'">'+((ri?.em||'')+' '+(ri?.name||r)).substring(0,12)+'</th>'});
    h+='<th style="padding:6px;color:var(--td)">Bestand</th></tr>';

    goodKeys.forEach(g=>{const gd=GOODS[g];if(!gd)return;
      const stock=Object.values(G.stor).reduce((s,st)=>s+(st[g]||0),0);
      // Trend: compare current with 5 snapshots ago
      let trend='';
      if(G.priceHist&&G.priceHist.length>=2){
        const old=G.priceHist[0].prices[g];const now2={};
        regs.forEach(r=>{now2[r]=marketPrice(g,r)});
        const oldAvg=old?Object.values(old).reduce((a,v)=>a+v,0)/Math.max(1,Object.keys(old).length):0;
        const nowAvg=Object.values(now2).reduce((a,v)=>a+v,0)/Math.max(1,regs.length);
        if(nowAvg>oldAvg*1.05)trend='<span style="color:var(--a)">▲</span>';
        else if(nowAvg<oldAvg*0.95)trend='<span style="color:var(--r)">▼</span>';
        else trend='<span style="color:var(--td)">─</span>';
      }
      h+='<tr style="border-bottom:1px solid var(--bd);cursor:pointer" onclick="G.marketDetail=\''+g+'\';G.marketSub=\'detail\';renComp()">';
      h+='<td style="padding:4px 6px;white-space:nowrap">'+(gd.em||'')+' '+(gd.name||g)+' '+trend+'</td>';
      h+='<td style="padding:4px 6px;text-align:center;font-family:var(--mono);color:var(--td)">'+fmt(BASE_PRICES[g]||0)+'</td>';
      regs.forEach(r=>{
        const p=marketPrice(g,r);const base=BASE_PRICES[g]||100;const diff=p-base;
        const clr=diff>0?'var(--a)':diff<0?'var(--r)':'var(--td)';
        h+='<td style="padding:4px 6px;text-align:center;font-family:var(--mono);color:'+clr+'">'+fmt(p)+'</td>'});
      h+='<td style="padding:4px 6px;text-align:center;font-family:var(--mono);color:'+(stock>0?'var(--a)':'var(--td)')+'">'+stock+'</td>';
      h+='</tr>'});
    h+='</table></div>';

    // Legend
    h+='<div class="sub" style="margin-top:8px"><i class="ri-information-line"></i> Grün = über Basispreis · Rot = unter Basispreis · Preise ändern sich alle ~10 Min</div>';
  }

  if(G.marketSub==='sell'){
    h+='<div class="sub" style="margin-bottom:8px">Fahrzeug transportiert Ware zum regionalen Marktplatz und kehrt zurück</div>';
    cities.forEach(c=>{const s=G.stor[c.id]||{};const items=Object.entries(s).filter(([,a])=>a>0);
      if(!items.length)return;
      const reg=getRegion((c.co||'').toUpperCase());const ri=REGIONS[reg];
      // Pick a preview destination for display
      const allDB2=typeof DB!=='undefined'?DB:[];
      const regCities2=allDB2.filter(x=>getRegion(x[1])===reg&&x[0]!==c.name);
      const previewDest=regCities2.length?regCities2[Math.floor((G.tick||0)/60%regCities2.length)]:null;
      const vHere3=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id);
      h+='<div class="crd"><div class="rw"><span style="font-weight:600">📍 '+c.name+'</span><span class="sub">'+(ri?.em||'')+' '+(ri?.name||'')+'</span></div>';
      if(previewDest)h+='<div class="sub" style="margin-bottom:3px">🚛 Nächster Markt: <b>'+previewDest[0]+'</b> ('+Math.round(hav(c.lat,c.lng,previewDest[3],previewDest[4]))+' km)'+(vHere3.length?' · 🚛'+vHere3.length+' verfügbar':'')+'</div>';
      if(!vHere3.length)h+='<div class="sub" style="color:var(--r);margin-bottom:3px">❌ Kein Fahrzeug am Standort</div>';
      items.sort((a,b)=>marketPrice(b[0],reg)*b[1]-marketPrice(a[0],reg)*a[1]).forEach(([g,amt])=>{
        const price=marketPrice(g,reg);const total=price*amt;
        const bestV2=vHere3.length?vHere3.sort((a2,b2)=>vehCap(b2)-vehCap(a2))[0]:null;
        const maxSend=bestV2?Math.min(amt,vehCap(bestV2)):0;
        const dist3=previewDest?Math.round(hav(c.lat,c.lng,previewDest[3],previewDest[4])):100;
        const transCost=bestV2?Math.round(dist3*0.8+VT[bestV2.type].mt*0.3*Math.min(amt,maxSend)):0;
        h+='<div style="display:flex;align-items:center;gap:4px;padding:3px 0;font-size:11px;border-top:1px solid var(--bd)">';
        h+='<span style="flex:1;min-width:0">'+(GOODS[g]?.em||'')+' '+(GOODS[g]?.name||'')+' <b>'+amt+'</b> × '+fmt(price)+'</span>';
        h+='<span style="font-family:var(--mono);color:var(--a);min-width:50px;text-align:right">'+fmt(total)+'</span>';
        if(maxSend>0)h+='<button class="btn sm" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.25)" onclick="showMarketSellPopup(\''+c.id+'\',\''+g+'\')">💰 Verkaufen</button>';
        else h+='<span class="sub" style="color:var(--r)">🚛 fehlt</span>';
        h+='</div>'});
      h+='</div>'});
    const totalStock={};
    cities.forEach(c=>{Object.entries(G.stor[c.id]||{}).forEach(([g,a])=>{if(a>0)totalStock[g]=(totalStock[g]||0)+a})});
    if(!Object.keys(totalStock).length)h+='<div class="sub" style="text-align:center;padding:16px">Kein Warenbestand zum Verkaufen</div>';
  }

  if(G.marketSub==='detail'&&G.marketDetail){
    const g=G.marketDetail;const gd=GOODS[g];
    h+='<button class="btn sm" style="margin-bottom:8px" onclick="G.marketSub=\'prices\';renComp()"><i class="ri-arrow-left-line"></i> Zurück</button>';
    h+='<div class="crd"><div class="rw"><span style="font-size:16px">'+(gd?.em||'')+' <b>'+(gd?.name||g)+'</b></span>';
    h+='<span style="font-family:var(--mono);color:var(--td)">Basis: '+fmt(BASE_PRICES[g]||0)+'</span></div>';
    const stock=Object.values(G.stor).reduce((s,st)=>s+(st[g]||0),0);
    h+='<div class="sub" style="margin-top:4px">Bestand: '+stock+'× · Kategorie: '+(gd?.cat==='roh'?'Rohstoff':gd?.cat==='ver'?'Verarbeitet':'Sonstige')+'</div></div>';
    // Price per region
    h+='<div class="sec-label"><i class="ri-money-dollar-circle-line"></i> Aktuelle Marktpreise</div>';
    regs.forEach(r=>{const ri=REGIONS[r];const price=marketPrice(g,r);const base=BASE_PRICES[g]||100;
      const pct=Math.round((price/base-1)*100);const clr=pct>0?'var(--a)':pct<0?'var(--r)':'var(--td)';
      h+='<div class="crd" style="padding:6px 10px"><div class="rw"><span>'+(ri?.em||'')+' '+(ri?.name||r)+'</span>';
      h+='<span style="font-family:var(--mono);color:'+clr+'">'+fmt(price)+' ('+(pct>0?'+':'')+pct+'%)</span></div></div>'});
    // Price history mini chart (ASCII bar chart)
    if(G.priceHist&&G.priceHist.length>=2){
      h+='<div class="sec-label"><i class="ri-line-chart-line"></i> Preisverlauf (letzte '+G.priceHist.length+' Zyklen)</div>';
      regs.forEach(r=>{const ri=REGIONS[r];
        const vals=G.priceHist.map(s=>s.prices[g]?.[r]||0).filter(v=>v>0);
        if(!vals.length)return;
        const mx=Math.max(...vals);const mn=Math.min(...vals);
        h+='<div class="crd" style="padding:6px 10px"><div class="sub" style="margin-bottom:4px">'+(ri?.em||'')+' '+(ri?.name||'')+' · '+fmt(mn)+' – '+fmt(mx)+'</div>';
        h+='<div style="display:flex;align-items:flex-end;gap:2px;height:32px">';
        vals.forEach((v,i)=>{const pct2=mx>mn?((v-mn)/(mx-mn))*100:50;
          const isLast=i===vals.length-1;
          h+='<div style="flex:1;background:'+(isLast?'var(--a)':'rgba(61,214,140,.3)')+';border-radius:2px 2px 0 0;height:'+Math.max(4,pct2)+'%;transition:height .3s"></div>'});
        h+='</div>';
        h+='<div class="sub" style="text-align:right;margin-top:2px">Aktuell: <b style="color:var(--a)">'+fmt(vals[vals.length-1])+'</b></div></div>'});
    }
    // Quick sell
    const stockLocs=cities.filter(c=>(G.stor[c.id]?.[g]||0)>0);
    if(stockLocs.length){
      h+='<div class="sec-label"><i class="ri-shopping-cart-line"></i> Verkaufen</div>';
      stockLocs.forEach(c=>{const amt2=G.stor[c.id][g];const reg2=getRegion((c.co||'').toUpperCase());const p2=marketPrice(g,reg2);
        h+='<div class="crd" style="padding:6px 10px"><div class="rw"><span>📍 '+c.name+' · '+amt2+'×</span>';
        h+='<button class="btn sm" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.25)" onclick="showMarketSellPopup(\''+c.id+'\',\''+g+'\')">💰 Verkaufen</button></div></div>'});
    }
  }

  if(G.marketSub==='trends'){
    h+='<div class="sub" style="margin-bottom:8px"><i class="ri-information-line"></i> Regionale Nachfrage-Multiplikatoren — wo lohnt sich der Verkauf?</div>';
    // Show best opportunities
    const opps=[];
    Object.keys(BASE_PRICES).forEach(g=>{
      regs.forEach(r=>{
        const mult=REGION_DEMAND[r]?.[g]||1;
        if(mult>1.1)opps.push({good:g,region:r,mult,price:marketPrice(g,r)});
      });
    });
    opps.sort((a,b)=>b.mult-a.mult);

    if(opps.length){
      h+='<div class="sec-label"><i class="ri-arrow-up-circle-line"></i> Hohe Nachfrage</div>';
      opps.slice(0,15).forEach(o=>{const gd=GOODS[o.good];const ri=REGIONS[o.region];
        h+='<div class="crd" style="padding:6px 10px"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||'')+' → '+(ri?.em||'')+' '+(ri?.name||'')+'</span>';
        h+='<span style="font-family:var(--mono);color:var(--a)">+'+Math.round((o.mult-1)*100)+'% ('+fmt(o.price)+'/St.)</span></div></div>'});}

    // Low demand
    const lows=[];
    Object.keys(BASE_PRICES).forEach(g=>{
      regs.forEach(r=>{
        const mult=REGION_DEMAND[r]?.[g]||1;
        if(mult<0.8)lows.push({good:g,region:r,mult,price:marketPrice(g,r)});
      });
    });
    lows.sort((a,b)=>a.mult-b.mult);
    if(lows.length){
      h+='<div class="sec-label"><i class="ri-arrow-down-circle-line"></i> Niedrige Nachfrage (günstig einkaufen)</div>';
      lows.slice(0,10).forEach(o=>{const gd=GOODS[o.good];const ri=REGIONS[o.region];
        h+='<div class="crd" style="padding:6px 10px"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||'')+' in '+(ri?.em||'')+' '+(ri?.name||'')+'</span>';
        h+='<span style="font-family:var(--mono);color:var(--r)">'+Math.round((o.mult-1)*100)+'% ('+fmt(o.price)+'/St.)</span></div></div>'});}
  }

  // ── SUPPLY/DEMAND STATISTICS ──
  if(G.marketSub==='supply'){
    h+='<div class="sec-label"><i class="ri-scales-3-line"></i> Angebot & Nachfrage</div>';
    h+='<div class="sub" style="margin-bottom:8px">Preise passen sich an: Viel geliefert = niedrigerer Preis. Wenig geliefert = höherer Preis. Epoch-Wechsel alle ~8h.</div>';
    const epoch=Math.floor((G.tick||0)/28800);
    const nextReset=28800-(G.tick%28800);
    h+='<div class="crd" style="padding:6px 8px;margin-bottom:8px"><div class="rw"><span>📊 Aktuelle Epoche: <b>'+epoch+'</b></span><span class="sub">Nächster Wechsel: '+ftime(nextReset)+'</span></div></div>';
    // Current supply data
    const supply=G.supplyTrack||{};
    const vals=Object.values(supply);
    const avg=vals.length?Math.round(vals.reduce((s,v)=>s+v,0)/vals.length):0;
    h+='<div class="sub" style="margin-bottom:4px">Durchschnittliches Angebot: <b>'+avg+'</b> Einheiten/Epoch</div>';
    // Table of goods sorted by supply impact
    const goods2=Object.keys(BASE_PRICES).map(g=>{
      const del=supply[g]||0;const ratio=avg>0?del/avg:1;
      const impact=avg>0?Math.round((1-ratio)*30):0; // % price adjustment
      return{good:g,delivered:del,ratio,impact};
    }).sort((a,b)=>a.ratio-b.ratio);
    // Oversupplied
    const over=goods2.filter(x=>x.ratio>1.2);
    const under=goods2.filter(x=>x.ratio<0.8&&avg>0);
    const normal=goods2.filter(x=>x.ratio>=0.8&&x.ratio<=1.2);
    if(under.length){
      h+='<div class="sec-label" style="color:var(--a)">📈 Unterversorgt (höhere Preise)</div>';
      under.forEach(x=>{const gd=GOODS[x.good];
        h+='<div class="crd" style="padding:3px 8px"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||x.good)+'</span>';
        h+='<span style="font-family:var(--mono)"><span style="color:var(--a)">+'+Math.abs(x.impact)+'%</span> · '+x.delivered+' geliefert</span></div></div>'});}
    if(over.length){
      h+='<div class="sec-label" style="color:var(--r)">📉 Überversorgt (niedrigere Preise)</div>';
      over.forEach(x=>{const gd=GOODS[x.good];
        h+='<div class="crd" style="padding:3px 8px"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||x.good)+'</span>';
        h+='<span style="font-family:var(--mono)"><span style="color:var(--r)">-'+Math.abs(x.impact)+'%</span> · '+x.delivered+' geliefert</span></div></div>'});}
    if(normal.length){
      h+='<div class="sec-label">⚖️ Ausgeglichen</div>';
      normal.slice(0,15).forEach(x=>{const gd=GOODS[x.good];if(!x.delivered)return;
        h+='<div class="crd" style="padding:3px 8px"><div class="rw"><span>'+(gd?.em||'')+' '+(gd?.name||x.good)+'</span>';
        h+='<span class="sub">'+x.delivered+' geliefert</span></div></div>'});}
    // History
    if(G.supplyHist&&G.supplyHist.length){
      h+='<div class="sec-label" style="margin-top:8px">📜 Vergangene Epochen</div>';
      G.supplyHist.slice().reverse().forEach(sh=>{
        const items=Object.entries(sh.supply).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]);
        const total=items.reduce((s,[,v])=>s+v,0);
        h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>Epoche '+sh.epoch+'</span><span class="sub">'+total+' Lieferungen · '+items.length+' Warentypen</span></div>';
        h+='<div class="sub" style="margin-top:2px">Top: '+items.slice(0,5).map(([g,v])=>(GOODS[g]?.em||'')+v+'×').join(' ')+'</div></div>'});}
  }

  // ── ALLIANCE REQUESTS ──
  if(G.marketSub==='allyreqs'){
    h+='<div class="sec-label" style="color:#a855f7">🛒 Allianz-Kaufanfragen</div>';
    h+='<div class="sub" style="margin-bottom:8px">Allianzen suchen Rohstoffe. Liefere Waren und verdiene Geld!</div>';
    h+='<div id="allyReqList">Lade...</div>';
    // Load async
    el.innerHTML=h;
    (async()=>{
      const mk=await getAllianceMarket();
      const le=document.getElementById('allyReqList');if(!le)return;
      const active=mk.filter(r=>r.filled<r.amt);
      if(!active.length){le.innerHTML='<div class="sub" style="text-align:center;padding:12px">Keine offenen Anfragen</div>';return}
      let rh='';
      active.forEach(r=>{const gd=GOODS[r.good];const remaining=r.amt-r.filled;const isOwn=G.alliance===r.allianceId;
        rh+='<div class="crd" style="border-left:3px solid #a855f7;'+(isOwn?'background:rgba(168,85,247,.03)':'')+'">';
        rh+='<div class="rw"><span style="font-weight:600">'+(gd?.em||'')+' '+remaining+'× '+(gd?.name||r.good)+'</span>';
        rh+='<span style="font-family:var(--mono);color:#a855f7;font-weight:700">'+fmt(r.ppu)+'/St.</span></div>';
        rh+='<div class="rw"><span class="sub">['+r.allianceTag+'] '+r.allianceName+(isOwn?' (deine Allianz)':'')+'</span>';
        rh+='<span class="sub">Gesamt: '+fmt(remaining*r.ppu)+'</span></div>';
        if(r.filled>0)rh+='<div class="pb" style="margin:3px 0;height:3px"><div class="pf" style="width:'+(r.filled/r.amt*100)+'%;background:#a855f7"></div></div>';
        // Show which cities have this good
        if(!isOwn||true){
          const supplyCities=cities.filter(c=>(G.stor[c.id]?.[r.good]||0)>0);
          if(supplyCities.length){
            rh+='<div style="margin-top:4px">';
            supplyCities.forEach(c=>{const stock=G.stor[c.id][r.good];const idle=G.vehs.filter(v=>v.st==="idle"&&v.loc===c.id).length;
              rh+='<div style="display:flex;align-items:center;gap:4px;font-size:11px;padding:2px 0;border-top:1px solid var(--bd)">';
              rh+='<span style="flex:1">📍 '+c.name+' · '+stock+'× · 🚛'+idle+'</span>';
              const canSend=stock>0&&idle>0;
              const sendAmt=Math.min(stock,remaining);
              rh+='<button class="btn sm'+(canSend?'':' off')+'" style="'+(canSend?'color:#a855f7;border-color:rgba(168,85,247,.3)':'')+'" onclick="fulfillAllianceRequest(\''+r.id+'\',\''+c.id+'\','+sendAmt+')">'+sendAmt+'× liefern'+(canSend?' (+'+fmt(sendAmt*r.ppu)+')':'')+'</button></div>'});
            rh+='</div>';
          } else rh+='<div class="sub" style="color:var(--td);margin-top:3px">Keine Ware auf Lager</div>';
        }
        rh+='</div>'});
      le.innerHTML=rh;
    })();
    return; // async render
  }

  el.innerHTML=h}

// ═══ ROUTES ═══
