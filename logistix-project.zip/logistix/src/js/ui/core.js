// ══════════════════════════════════════════
// RENDER v8 – Dashboard-default, toggle to Map
// ══════════════════════════════════════════

let computerOpen=false,compTab='missions',minimap=null,minimapPin=null,minimapOpen=true,buildExpanded={};
let viewMode='dashboard'; // 'dashboard' or 'map'
let explorerCollapsed={};
let routesShowAll=true;
let routesSub='all';
let bldSub='build'; // 'build', 'manage', 'infra'

// ═══ CONTINENT DISPLAY (uses getRegion from constants.js) ═══
function getContinent(co){const r=getRegion(co);return REGIONS[r]?REGIONS[r].name:'Sonstige'}

// ═══ HAMBURGER MENU ═══
function toggleHamburger(){document.getElementById('hbMenu').classList.toggle('open')}
function closeHamburger(){document.getElementById('hbMenu').classList.remove('open')}
document.addEventListener('click',e=>{const w=document.querySelector('.hamburger-wrap');if(w&&!w.contains(e.target))closeHamburger()});

// ═══ VIEW TOGGLE: Dashboard ↔ Map ═══
function toggleView(){
  viewMode=viewMode==='dashboard'?'map':'dashboard';
  markDirty();
  applyView();
}
function mountMapTo(target){
  const mapEl=document.getElementById('map');
  if(!mapEl||!MP||!target)return;
  if(mapEl.parentElement===target)return;
  target.appendChild(mapEl);
  setTimeout(()=>{try{MP.invalidateSize()}catch(e){}},120);
}
function applyView(){
  const dashEl=document.getElementById('dashPanel');
  const mapEl=document.getElementById('map');
  const searchSlot=document.getElementById('mapSearchSlot');
  const zoomEl=document.getElementById('mapZoom');
  const toggleBtn=document.getElementById('viewToggleBtn');
  const swEl=document.getElementById('sw');
  if(viewMode==='dashboard'){
    if(dashEl)dashEl.style.display='block';
    if(mapEl)mapEl.style.display='none';
    if(searchSlot)searchSlot.style.display='none';
    if(zoomEl)zoomEl.style.display='none';
    if(toggleBtn)toggleBtn.textContent='🗺️ Karte';
    try{renDash()}catch(e){console.error('renDash error',e)}
  } else {
    if(dashEl)dashEl.style.display='none';
    if(mapEl){mapEl.style.display='block';setTimeout(()=>{if(MP)MP.invalidateSize()},100)}
    if(searchSlot)searchSlot.style.display='block';
    if(toggleBtn)toggleBtn.textContent='📊 Dashboard';
    if(searchSlot&&swEl&&swEl.parentElement!==searchSlot){swEl.style.cssText='display:block';searchSlot.appendChild(swEl)}
    if(!document.getElementById('mapZoom')){const zd=document.createElement('div');zd.id='mapZoom';zd.className='map-zoom';zd.innerHTML='<button class="zb" onclick="MP&&MP.zoomIn()">+</button><button class="zb" onclick="MP&&MP.zoomOut()">−</button>';document.getElementById('gameScreen').appendChild(zd)}
    else if(zoomEl)zoomEl.style.display='flex';
  }
}

