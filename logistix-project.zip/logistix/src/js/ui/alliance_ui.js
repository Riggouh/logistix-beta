function openAlliancePanel(){
  if(!G){addLog('❌ Erst einloggen');return}
  document.getElementById('alliancePanel').classList.add('open');
  alliancePanelOpen=true;renderAlliance();
}
function closeAlliancePanel(){
  document.getElementById('alliancePanel').classList.remove('open');
  alliancePanelOpen=false;
}
function renderAlliance(){if(alliancePanelOpen)compAlliance()}

async function compAlliance(){
  const el=document.getElementById('allyBody');
  const exp=document.getElementById('allyExplorer');
  if(!el||!exp)return;
  if(!G.allianceSub)G.allianceSub='overview';
  let h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><div style="font-family:var(--mono);font-size:16px;font-weight:700;color:#a855f7">🤝 Allianz</div><button class="tip-btn" onclick="showTabTip(\'alliance\')">💡</button></div>';

  if(!G.alliance){
    h+='<div style="text-align:center;padding:16px"><div style="font-size:32px;margin-bottom:8px">🤝</div>';
    h+='<div style="font-family:var(--mono);font-size:14px;color:#a855f7;margin-bottom:12px">Gründe oder tritt einer Allianz bei</div>';
    h+='<div class="sub" style="margin-bottom:16px">Gemeinsam Spezialwaren herstellen, Gebiete kontrollieren, auf der Börse handeln. Keine Rohstoffproduktion — nur Verarbeitung gelieferter Waren!</div>';
    h+='<div class="crd" style="text-align:left"><div class="sec-label">Gründen (300.000€ · 250.000€ Startkapital)</div>';
    h+='<input id="allyName" class="auth-input" placeholder="Allianzname" style="margin-bottom:6px" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
    h+='<input id="allyTag" class="auth-input" placeholder="Tag (2-4 Zeichen)" style="margin-bottom:6px" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
    h+='<button class="btn full" style="background:rgba(168,85,247,.1);color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="try{createAlliance(document.getElementById(\'allyName\').value,document.getElementById(\'allyTag\').value)}catch(e){addLog(\'❌ \'+e)}">🤝 Gründen</button></div>';
    h+='<div class="sec-label" style="margin-top:12px">📨 Bewerben</div><div id="allyList">Lade...</div></div>';
    el.innerHTML=h;exp.innerHTML='<div style="padding:8px;color:var(--td);font-size:11px">Noch keine Allianz</div>';
    const all=await getAlliances();const list=Object.values(all);
    const le=document.getElementById('allyList');if(!le)return;
    // Show pending applications
    const pendEl=document.getElementById('allyPending');
    if(pendEl){const pend=list.filter(a2=>a2.applications&&a2.applications.find(x=>x.user===currentUser));
      if(pend.length){let ph='<div class="sec-label" style="color:var(--go)">📨 Deine Bewerbungen</div>';
        pend.forEach(a2=>{ph+='<div class="crd" style="border-left:3px solid var(--go);padding:5px 8px"><div class="rw"><span>['+a2.tag+'] '+a2.name+'</span><span class="tg" style="color:var(--go)">⏳ Ausstehend</span></div></div>'});
        pendEl.innerHTML=ph;}}
    // Show invites
    const invites=list.filter(a2=>a2.invites&&a2.invites.includes(currentUser));
    if(invites.length&&pendEl){let ih='<div class="sec-label" style="color:var(--a)">📨 Einladungen</div>';
      invites.forEach(a2=>{ih+='<div class="crd" style="border-left:3px solid var(--a);padding:5px 8px"><div class="rw"><span>['+a2.tag+'] '+a2.name+'</span><button class="btn sm" style="color:var(--a);border-color:rgba(61,214,140,.3)" onclick="acceptInvite(\''+a2.id+'\')">✅ Annehmen</button></div></div>'});
      pendEl.innerHTML=(pendEl.innerHTML||'')+ih;}
    if(!list.length){le.innerHTML='<div class="sub">Keine Allianzen vorhanden</div>';return}
    let lh='';list.forEach(a=>{const lv=ALLIANCE_LEVELS[a.level-1];
      lh+='<div class="crd"><div class="rw"><span style="font-weight:600">['+a.tag+'] '+a.name+'</span>';
      lh+='<button class="btn sm" style="color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="joinAlliance(\''+a.id+'\')">📨 Bewerben</button></div>';
      lh+='<div class="sub">Lvl '+a.level+' '+lv.name+' · 👥'+a.members.length+'/'+lv.maxMembers+' · 💰'+fmt(a.treasury)+'</div></div>'});
    le.innerHTML=lh;return;
  }

  const a=await getAlliance(G.alliance);
  if(!a){G.alliance=null;el.innerHTML=h+'<div class="sub">Nicht gefunden</div>';return}
  const lv=ALLIANCE_LEVELS[a.level-1];const isL=a.leader===currentUser;

  // Explorer
  let eh='<div style="font-family:var(--mono);font-size:12px;font-weight:700;color:#a855f7;padding:8px 10px">🤝 ['+a.tag+']</div>';
  [['overview','<i class="ri-team-line"></i> Übersicht'],['storage','<i class="ri-box-3-line"></i> Lager'],['production','<i class="ri-building-line"></i> Produktion'],['orders','<i class="ri-file-list-3-line"></i> Aufträge'],['resmarket','<i class="ri-shopping-bag-line"></i> Einkauf'],['territory','<i class="ri-map-2-line"></i> Gebiete'],['market','<i class="ri-exchange-funds-line"></i> Börse']].forEach(([k,l])=>{
    eh+='<div class="ex-city'+(G.allianceSub===k?' sel':'')+'" onclick="G.allianceSub=\''+k+'\';renderAlliance()" style="font-weight:'+(G.allianceSub===k?'600':'400')+';color:'+(G.allianceSub===k?'#a855f7':'var(--td)')+'">'+l+'</div>'});
  if(canDo(a,currentUser,'canRoles')||canDo(a,currentUser,'canInvite')){
    eh+='<div class="ex-city'+(G.allianceSub==='manage'?' sel':'')+'" onclick="G.allianceSub=\'manage\';renderAlliance()" style="font-weight:'+(G.allianceSub==='manage'?'600':'400')+';color:'+(G.allianceSub==='manage'?'var(--go)':'var(--td)')+'"><i class="ri-settings-3-line"></i> Management</div>';}
  eh+='<div style="height:1px;background:var(--bd);margin:6px"></div>';
  eh+='<div class="ex-city" style="color:var(--td);font-size:10px">💰 '+fmt(a.treasury)+'</div>';
  eh+='<div class="ex-city" style="color:var(--td);font-size:10px">👥 '+a.members.length+'/'+lv.maxMembers+'</div>';
  eh+='<div class="ex-city" style="color:var(--td);font-size:10px">🏭 '+a.buildings.length+'/'+lv.slots+'</div>';
  eh+='<div class="ex-city" style="color:var(--td);font-size:10px">🏴 '+a.territories.length+'/'+lv.maxTerr+'</div>';
  exp.innerHTML=eh;

  if(G.allianceSub==='overview'){
    h+='<div class="ch"><div class="ci" style="font-size:24px">🤝</div><div><div class="cn">['+a.tag+'] '+a.name+'</div><div class="cm">Level '+a.level+' '+lv.name+'</div></div></div>';
    h+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px;margin:8px 0">';
    [['📊',fmt(allianceValue(a)),'Allianzwert'],['💰',fmt(a.treasury),'Kasse'],['🏭',a.buildings.length+'/'+lv.slots,'Gebäude'],['🏴',a.territories.length+'/'+lv.maxTerr,'Gebiete']].forEach(([em,v,l])=>{
      h+='<div class="crd" style="text-align:center;padding:8px"><div>'+em+'</div><div style="font-family:var(--mono);font-size:13px;font-weight:700;color:var(--a)">'+v+'</div><div class="sub">'+l+'</div></div>'});
    h+='</div>';
    h+='<div class="sub" style="padding:4px;margin-bottom:6px;background:rgba(168,85,247,.04);border:1px solid rgba(168,85,247,.15);border-radius:8px">💡 Kein Geld einzahlen möglich — Allianz verdient durch <b>Aufträge</b> und <b>Gebietsgebühren</b></div>';
    h+='<div class="sec-label">👥 Mitglieder · '+a.members.length+'/'+lv.maxMembers+'</div>';
    a.members.forEach(m=>{const rl=ALLY_ROLES[m.role]||ALLY_ROLES.member;
      h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>'+rl.em+' <b>'+m.user+'</b></span>';
      h+='<span class="tg" style="font-size:10px">'+rl.name+'</span></div></div>'});
    // Pending applications badge
    const pendCount=(a.applications||[]).length;
    if(pendCount&&canDo(a,currentUser,"canInvite"))h+='<div class="sub" style="color:var(--go);margin-top:4px">📨 '+pendCount+' Bewerbung'+(pendCount>1?'en':'')+' offen — <button class="btn sm" style="color:var(--go);border-color:rgba(251,191,36,.3)" onclick="G.allianceSub=\'manage\';renderAlliance()">→ Management</button></div>';
    const next=ALLIANCE_LEVELS[a.level];
    if(next&&canDo(a,currentUser,'canUpgrade'))h+='<button class="btn full" style="margin-top:8px;background:rgba(168,85,247,.1);color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="upgradeAlliance()">⬆️ Level '+(a.level+1)+' · '+next.name+' ('+fmt(next.cost)+' aus Kasse)</button>';
    h+='<button class="btn red sm" style="margin-top:6px" onclick="if(confirm(\'Verlassen?\'))leaveAlliance()">Verlassen</button>';
  }

  if(G.allianceSub==='storage'){
    h+='<div class="sec-label">📦 Allianz-Lager</div>';
    const items=Object.entries(a.storage).filter(([,v])=>v>0);
    if(!items.length)h+='<div class="sub" style="padding:10px;text-align:center">Leer — Spieler müssen Waren liefern</div>';
    items.sort((x,y)=>y[1]-x[1]).forEach(([g,am])=>{h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>'+(GOODS[g]?.em||"")+' '+(GOODS[g]?.name||g)+'</span><span style="font-family:var(--mono);color:var(--a)">'+am+'×</span></div></div>'});
    // Incoming deliveries (vehicles en route)
    const incoming=G.vehs.filter(v=>v.st==='moving'&&v.cargo?.allianceDelivery&&!v.cargo.returning);
    if(incoming.length){h+='<div class="sec-label" style="color:#a855f7">🚛 Eintreffend · '+incoming.length+'</div>';
      incoming.forEach(v=>{const vt=VT[v.type];if(!vt)return;
        const tn=v.rt.tripTime||60;const pct=Math.min(v.prog/(tn||1),1);
        h+='<div class="crd" style="padding:4px 8px;border-left:3px solid #a855f7;background:rgba(168,85,247,.02)">';
        h+='<div class="rw"><span>'+vt.em+' '+(GOODS[v.cargo.good]?.em||'')+' <b>'+v.cargo.amt+'×</b> '+(GOODS[v.cargo.good]?.name||'')+'</span>';
        h+='<span class="eta" style="color:#a855f7">'+Math.floor(pct*100)+'%</span></div>';
        h+='<div class="pb" style="height:3px"><div class="pf" style="width:'+pct*100+'%;background:#a855f7"></div></div></div>'});}
    h+='<div class="sec-label" style="margin-top:8px">📦 Einliefern</div>';
    h+='<div class="sub" style="margin-bottom:4px;color:var(--td)">🚛 Benötigt ein freies Fahrzeug am Standort. Fahrzeug fährt sichtbar zum Allianz-Hub und zurück.</div>';
    cities.forEach(c=>{const s=G.stor[c.id]||{};const gs=Object.entries(s).filter(([,v])=>v>0);if(!gs.length)return;
      const idleHere=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id).length;
      h+='<div class="crd"><div class="rw"><span style="font-weight:600">📍 '+c.name+'</span><span class="sub">🚛 '+idleHere+' frei</span></div>';
      if(!idleHere)h+='<div class="sub" style="color:var(--r)">❌ Kein Fahrzeug vor Ort</div>';
      gs.forEach(([g,am])=>{h+='<div style="display:flex;align-items:center;gap:4px;padding:2px 0;font-size:11px;border-top:1px solid var(--bd)"><span style="flex:1">'+(GOODS[g]?.em||"")+' '+(GOODS[g]?.name||"")+' '+am+'×</span>';
        if(idleHere){h+='<button class="btn sm" onclick="deliverToAlliance(\''+c.id+'\',\''+g+'\','+Math.min(am,10)+')">'+Math.min(am,10)+'×</button>';
          if(am>10)h+='<button class="btn sm" onclick="deliverToAlliance(\''+c.id+'\',\''+g+'\','+am+')">Alle</button>';}
        h+='</div>'});
      h+='</div>'});
  }

  if(G.allianceSub==='production'){
    h+='<div class="sec-label">🏭 Gebäude · '+a.buildings.length+'/'+lv.slots+'</div>';
    if(!a.buildings.length)h+='<div class="sub" style="padding:10px;text-align:center">Noch keine — baue dein erstes Allianzgebäude unten</div>';
    h+='<div class="sub" style="margin-bottom:6px;color:var(--td)">ℹ️ Pro Stadt kann nur ein Allianz-Gebäude gebaut werden. Gebäude können nur in beanspruchten Gebieten errichtet werden.</div>';
    a.buildings.forEach((b,i)=>{const d=ALLIANCE_BUILDINGS[b.type];if(!d)return;
      const r=d.recipes[b.recipe||0];
      h+='<div class="crd"><div class="rw"><span>'+d.em+' <b>'+d.name+'</b></span><span class="sub">📍 '+(b.cityName||'?')+'</span></div>';
      if(r){h+='<div class="sub">'+(GOODS[r.in1]?.em||'')+' '+r.in1N+'× '+(GOODS[r.in1]?.name||'')+(r.in2?' + '+(GOODS[r.in2]?.em||'')+' '+r.in2N+'× '+(GOODS[r.in2]?.name||''):'')+' → '+(GOODS[r.out]?.em||'')+' '+r.outR+'× '+(GOODS[r.out]?.name||'')+'</div>';
        const ok1=(a.storage[r.in1]||0)>=r.in1N;const ok2=!r.in2||(a.storage[r.in2]||0)>=r.in2N;
        h+='<button class="btn sm'+(ok1&&ok2?'':' off')+'" style="margin-top:3px" onclick="allianceProduce('+i+')"><i class="ri-play-line"></i> Produzieren</button>';
        if(!ok1||!ok2)h+='<span class="sub" style="color:var(--r);margin-left:6px">Rohstoffe fehlen</span>'}
      h+='</div>'});
    if(a.buildings.length<lv.slots&&canDo(a,currentUser,'canBuild')){
      h+='<div class="sec-label" style="margin-top:8px">🏗️ Neues Gebäude</div>';
      h+='<div class="sub" style="margin-bottom:4px">Stadt suchen (weltweit):</div>';
      h+='<input id="allyBuildSearch" class="auth-input" placeholder="Stadt suchen..." oninput="updateAllyBuildResults(this.value)" onfocus="renderBlocked=true" onblur="setTimeout(()=>{renderBlocked=false},300)"/>';
      h+='<div id="allyBuildResults"></div>';
      h+='<div id="allyBuildGrid"></div>';
    }
  }

  if(G.allianceSub==='orders'){
    const hasPosten=a.buildings.find(b=>b.type==='handelsposten');
    h+='<div class="sec-label">📋 Allianz-Aufträge</div>';
    if(!hasPosten)h+='<div style="padding:8px 10px;border-radius:8px;border:1px solid rgba(251,191,36,.3);background:rgba(251,191,36,.04);margin-bottom:8px;font-size:11px;color:var(--go)"><i class="ri-information-line"></i> Tipp: Baue einen <b>🏪 Handelsposten</b> um mehr und bessere Aufträge zu erhalten!</div>';
    h+='<div class="sub" style="margin-bottom:6px">Erlös geht direkt in die Allianzkasse.</div>';
    if(!a.orders||!a.orders.length)h+='<div class="sub" style="text-align:center;padding:12px">Keine Aufträge — erst Waren ins Allianz-Lager liefern</div>';
    (a.orders||[]).forEach((o,i)=>{const gd=GOODS[o.good];const hasStock=(a.storage[o.good]||0)>=o.amt;
      h+='<div class="crd" style="border-left:3px solid #a855f7"><div class="rw"><span>'+(gd?.em||"")+' '+o.amt+'× '+(gd?.name||"")+'</span><span style="font-family:var(--mono);color:var(--a);font-weight:700">'+fmt(o.rew)+'</span></div>';
      h+='<div class="sub">Lager: '+(a.storage[o.good]||0)+'/'+o.amt+(hasStock?" ✅":" ❌")+'</div>';
      h+='<button class="btn sm'+(hasStock?"":" off")+'" style="margin-top:3px" onclick="acceptAllianceOrder('+i+')">💰 Auftrag erfüllen</button></div>'});
  }

  if(G.allianceSub==='manage'){
    h+='<div class="sec-label"><i class="ri-settings-3-line"></i> Allianz-Management</div>';
    // Member management with full role controls
    h+='<div class="sub" style="margin-bottom:8px">Mitglieder verwalten, Rollen zuweisen, Bewerbungen bearbeiten</div>';
    a.members.forEach(m=>{const rl=ALLY_ROLES[m.role]||ALLY_ROLES.member;
      h+='<div class="crd" style="padding:6px 8px"><div class="rw"><span>'+rl.em+' <b>'+m.user+'</b></span><span class="tg" style="font-size:10px">'+rl.name+'</span></div>';
      if(m.user!==currentUser&&m.role!=='leader'&&canDo(a,currentUser,'canRoles')){
        h+='<div style="display:flex;gap:3px;margin-top:4px;flex-wrap:wrap">';
        Object.entries(ALLY_ROLES).forEach(([rk,rv])=>{if(rk==='leader')return;
          const active=m.role===rk;
          h+='<button class="btn sm" style="font-size:10px;padding:3px 7px;'+(active?'background:rgba(168,85,247,.15);color:#a855f7;border-color:#a855f7':'')+'" onclick="setMemberRole(\''+m.user+'\',\''+rk+'\')">'+rv.em+' '+rv.name+'</button>'});
        h+='</div>';
      }
      h+='</div>'});
    // Pending applications
    if((a.applications||[]).length){
      h+='<div class="sec-label" style="color:var(--go);margin-top:8px">📨 Bewerbungen · '+a.applications.length+'</div>';
      a.applications.forEach(ap=>{
        h+='<div class="crd" style="padding:5px 8px;border-left:3px solid var(--go)"><div class="rw"><span>👤 <b>'+ap.user+'</b></span>';
        h+='<div style="display:flex;gap:3px"><button class="btn sm" style="color:var(--a);border-color:rgba(61,214,140,.3)" onclick="approveApplication(\''+ap.user+'\')">✅ Aufnehmen</button>';
        h+='<button class="btn sm" style="color:var(--r);border-color:rgba(248,113,113,.3)" onclick="rejectApplication(\''+ap.user+'\')">❌ Ablehnen</button></div>';
        h+='</div></div>'});}
    // Invite
    h+='<div class="sec-label" style="margin-top:8px">📨 Spieler einladen</div>';
    h+='<div style="display:flex;gap:4px"><input id="allyInvUser2" class="auth-input" placeholder="Spielername" style="flex:1" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
    h+='<button class="btn sm" style="color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="inviteToAlliance(document.getElementById(\'allyInvUser2\').value)">📨 Einladen</button></div>';
    // Pending invites
    if(a.invites&&a.invites.length){h+='<div class="sub" style="margin-top:6px">Offene Einladungen: '+a.invites.join(', ')+'</div>';}
    // Roles legend
    h+='<div class="sec-label" style="margin-top:12px">📋 Rollen-Übersicht</div>';
    Object.entries(ALLY_ROLES).forEach(([rk,rv])=>{
      const perms=[];if(rv.canBuild)perms.push('Bauen');if(rv.canClaim)perms.push('Gebiete');if(rv.canUpgrade)perms.push('Upgrade');if(rv.canRoles)perms.push('Personal');if(rv.canInvite)perms.push('Einladen');if(rv.canProduce)perms.push('Produzieren');if(rv.canOrders)perms.push('Aufträge');if(rv.canMarket)perms.push('Börse');if(rv.canDeliver)perms.push('Liefern');
      h+='<div class="crd" style="padding:3px 8px;font-size:11px"><div class="rw"><span>'+rv.em+' <b>'+rv.name+'</b></span><span class="sub">'+perms.join(' · ')+'</span></div></div>'});
  }

  if(G.allianceSub==='resmarket'){
    const mk=await getAllianceMarket();
    const ours=mk.filter(r=>r.allianceId===a.id);
    h+='<div class="sec-label">🛒 Ressourcen-Einkauf</div>';
    h+='<div class="sub" style="margin-bottom:6px">Kaufanfragen erstellen, die alle Spieler im Markt-Tab sehen und erfüllen können. Geld wird aus der <b>Allianzkasse</b> reserviert.</div>';
    // Active requests
    if(ours.length){h+='<div class="sec-label" style="margin-top:4px">📋 Aktive Anfragen · '+ours.length+'</div>';
      ours.forEach(r=>{const gd=GOODS[r.good];const pct=r.filled/r.amt;
        h+='<div class="crd"><div class="rw"><span>'+(gd?.em||'')+' <b>'+(gd?.name||r.good)+'</b> · '+r.filled+'/'+r.amt+'</span>';
        h+='<span style="font-family:var(--mono);color:var(--a)">'+fmt(r.ppu)+'/St.</span></div>';
        h+='<div class="pb" style="margin:3px 0;height:3px"><div class="pf" style="width:'+pct*100+'%;background:#a855f7"></div></div>';
        h+='<div class="rw"><span class="sub">Gesamt: '+fmt(r.amt*r.ppu)+' · Offen: '+fmt((r.amt-r.filled)*r.ppu)+'</span>';
        if(canDo(a,currentUser,'canOrders')||a.leader===currentUser)h+='<button class="btn red sm" onclick="cancelAllianceRequest(\''+r.id+'\')">↩️ Zurückziehen</button>';
        h+='</div></div>'});}
    // Create new request
    if(canDo(a,currentUser,'canOrders')||a.leader===currentUser){
      h+='<div class="sec-label" style="margin-top:8px">➕ Neue Kaufanfrage</div>';
      h+='<div class="crd" style="padding:8px">';
      // Good selector
      h+='<div class="sub" style="margin-bottom:3px;font-weight:600">Ware wählen:</div>';
      h+='<select id="allyReqGood" class="sl" style="margin-bottom:6px" onchange="updAllyReqPrice()" onfocus="renderBlocked=true" onblur="renderBlocked=false">';
      h+='<option value="">— Ware wählen —</option>';
      const allGoods=Object.entries(GOODS).filter(([k])=>!ALLIANCE_GOODS[k]).sort((a2,b)=>(b[1].bp||0)-(a2[1].bp||0));
      allGoods.forEach(([k,g])=>{h+='<option value="'+k+'">'+(g.em||'')+' '+g.name+' (Markt: ~'+fmt(g.bp||BASE_PRICES[k]||100)+')</option>'});
      h+='</select>';
      // Amount + price
      h+='<div style="display:flex;gap:6px;margin-bottom:6px">';
      h+='<div style="flex:1"><div class="sub" style="margin-bottom:2px">Menge</div><input id="allyReqAmt" type="number" min="1" value="10" class="auth-input" oninput="updAllyReqPrice()" onfocus="renderBlocked=true" onblur="renderBlocked=false"/></div>';
      h+='<div style="flex:1"><div class="sub" style="margin-bottom:2px">Preis/Stück</div><input id="allyReqPpu" type="number" min="1" value="100" class="auth-input" oninput="updAllyReqPrice()" onfocus="renderBlocked=true" onblur="renderBlocked=false"/></div>';
      h+='</div>';
      h+='<div id="allyReqCalc" class="sub" style="margin-bottom:6px"></div>';
      h+='<button class="btn full" style="background:rgba(168,85,247,.1);color:#a855f7;border-color:rgba(168,85,247,.3)" onclick="const g=document.getElementById(\'allyReqGood\').value,a2=parseInt(document.getElementById(\'allyReqAmt\').value),p=parseInt(document.getElementById(\'allyReqPpu\').value);postAllianceRequest(g,a2,p)">🛒 Kaufanfrage erstellen</button>';
      h+='</div>';
    }
  }

  if(G.allianceSub==='territory'){
    const tr=await getTerritoryOwners();
    h+='<div class="sec-label">🏴 Eure Gebiete · '+a.territories.length+'/'+lv.maxTerr+'</div>';
    if(!a.territories.length)h+='<div class="sub" style="padding:8px;text-align:center">Keine Gebiete — beanspruche unten</div>';
    a.territories.forEach(tK=>{const t=TERRITORIES[tK];if(!t)return;const ti=tr[tK];
      const bldsInTerr=a.buildings.filter(b=>{const tc=getCitiesInTerritory(tK);return tc.find(c=>c.name===b.cityName)});
      h+='<div class="crd"><div class="rw"><span>'+t.em+' <b>'+t.countryName+'</b> · '+t.name+'</span><span class="sub">'+fmt(t.fee)+'/Tag'+(ti&&ti.missed?' · <span style="color:var(--r)">'+ti.missed+'/7</span>':'')+'</span></div>';
      if(bldsInTerr.length)h+='<div class="sub">🏭 '+bldsInTerr.length+' Gebäude: '+bldsInTerr.map(b=>(ALLIANCE_BUILDINGS[b.type]?.em||'')+' '+(b.cityName||'')).join(', ')+'</div>';
      if(canDo(a,currentUser,'canClaim'))h+='<button class="btn sm" style="margin-top:3px;font-size:10px" onclick="if(confirm(\'Gebiet auf der Börse anbieten?'+(bldsInTerr.length?' ⚠️ ACHTUNG: '+bldsInTerr.length+' Gebäude in diesem Gebiet gehen beim Verkauf verloren!':'')+' Preis eingeben:\')){const p=prompt(\'Verkaufspreis in €:\');if(p&&parseInt(p)>0)listTerritoryForSale(\''+tK+'\',parseInt(p))}">📋 Auf Börse anbieten</button>';
      h+='</div>'});
    // By country (collapsible)
    Object.entries(COUNTRIES).forEach(([cc,co])=>{
      const cTerrs=Object.entries(TERRITORIES).filter(([,t])=>t.country===cc);
      const owned=cTerrs.filter(([tK])=>a.territories.includes(tK)).length;
      const expanded=G._allyTerrExp===cc;
      h+='<div class="crd" style="padding:5px 8px;cursor:pointer" onclick="G._allyTerrExp='+(expanded?'null':"'"+cc+"'")+';renderAlliance()">';
      h+='<div class="rw"><span>'+co.em+' <b>'+co.name+'</b>'+(owned?' <span class="tg g" style="font-size:9px">'+owned+'</span>':'')+'</span>';
      h+='<span style="color:var(--td);font-size:10px">'+(expanded?'▼':'▶')+' '+cTerrs.length+'</span></div></div>';
      if(expanded){cTerrs.forEach(([tK,t])=>{
        const owner=tr[tK];const ours=a.territories.includes(tK);
        h+='<div style="padding:3px 8px 3px 20px;font-size:11px;border-bottom:1px solid var(--bd)"><div class="rw"><span>'+(ours?'🏴 ':'')+t.name+'</span>';
        if(owner&&!ours)h+='<span class="tg" style="font-size:9px">['+owner.tag+']</span>';
        else if(!owner&&canDo(a,currentUser,"canClaim")&&a.territories.length<lv.maxTerr)h+='<button class="btn sm" onclick="event.stopPropagation();claimTerritory(\''+tK+'\')">🏴 '+fmt(co.fee*30)+'</button>';
        else if(!owner)h+='<span style="color:var(--a);font-size:10px">Frei</span>';
        else h+='<span class="tg g" style="font-size:9px">Euer</span>';
        h+='</div></div>'})}
    });
  }

  if(G.allianceSub==='market'){
    const mk=await getTerritoryMarket();
    h+='<div class="sec-label">📈 Gebietsbörse</div>';
    if(!mk.length)h+='<div class="sub" style="text-align:center;padding:10px">Keine Angebote</div>';
    mk.forEach((l,i)=>{const t=TERRITORIES[l.territory];if(!t)return;const isSeller=l.seller===a.id;
      h+='<div class="crd'+(isSeller?" glow":"")+'"><div class="rw"><span>'+t.em+' <b>'+t.name+'</b></span><span style="font-family:var(--mono);color:var(--go);font-weight:700">'+fmt(l.price)+'</span></div>';
      h+='<div class="sub">['+l.sellerTag+'] '+l.sellerName+'</div>';
      if(!isSeller&&isL)h+='<button class="btn sm" style="margin-top:3px" onclick="buyTerritoryFromMarket('+i+')">Kaufen</button>';
      h+='</div>'});
  }

  el.innerHTML=h;
}


// ═══ ALLIANCE BUILD: Dynamic update without re-render ═══
async function updateAllyBuildResults(q){
  const el=document.getElementById('allyBuildResults');if(!el)return;
  if(!q||q.length<1){el.innerHTML='<div class="sub" style="padding:4px;color:var(--td)">Tippe einen Stadtnamen ein (nur Städte in euren Gebieten)</div>';return}
  let a2=null;
  if(G&&G.alliance){a2=await getAlliance(G.alliance)}
  if(!a2||!a2.territories.length){el.innerHTML='<div class="sub" style="padding:4px;color:var(--r)">❌ Erst Gebiete beanspruchen! Gebäude können nur in eigenen Gebieten gebaut werden.</div>';return}
  // Get all cities in owned territories
  const ownedCities=[];
  a2.territories.forEach(tK=>{getCitiesInTerritory(tK).forEach(c=>{
    if(!ownedCities.find(x=>x.name===c.name))ownedCities.push(c)})});
  // Filter by search
  const ql=q.toLowerCase();
  const results=ownedCities.filter(c=>c.name.toLowerCase().includes(ql)).sort((a3,b)=>b.name.length-a3.name.length).slice(0,8);
  let h='';
  results.forEach(c=>{
    const taken=a2.buildings.find(b=>b.cityName===c.name);
    h+='<div class="crd" style="padding:3px 8px;cursor:'+(taken?'default':'pointer')+'" onclick="'+(taken?'':"selectAllyBuildCity('"+c.name.replace(/'/g,"\\'")+"','"+c.co+"')")+'">';
    h+='<div class="rw"><span>📍 '+c.name+' <span class="sub">'+c.co+'</span></span>';
    if(taken)h+='<span class="sub" style="color:var(--r)">Bereits belegt</span>';
    else h+='<span style="color:#a855f7;font-size:10px">Auswählen →</span>';
    h+='</div></div>'});
  if(!results.length)h='<div class="sub" style="padding:4px">Keine Stadt in euren Gebieten gefunden für "'+q+'"</div>';
  el.innerHTML=h;
}
async function selectAllyBuildCity(cityName,co){
  const el=document.getElementById('allyBuildGrid');if(!el)return;
  const resEl=document.getElementById('allyBuildResults');
  if(resEl)resEl.innerHTML='<div class="crd" style="padding:3px 8px;border-color:#a855f7;background:rgba(168,85,247,.04)"><div class="rw"><span>📍 <b>'+cityName+'</b> ('+co+')</span><span style="color:#a855f7">✓ Gewählt</span></div></div>';
  let a2=null;
  if(G&&G.alliance){a2=await getAlliance(G.alliance)}
  if(!a2){el.innerHTML='';return}
  const cont=getRegion(co);
  const avail=Object.entries(ALLIANCE_BUILDINGS).filter(([,d])=>a2.level>=d.lvl&&(d.conts.includes('all')||d.conts.includes(cont)));
  const wrong=Object.entries(ALLIANCE_BUILDINGS).filter(([,d])=>a2.level>=d.lvl&&!d.conts.includes('all')&&!d.conts.includes(cont));
  const locked=Object.entries(ALLIANCE_BUILDINGS).filter(([,d])=>a2.level<d.lvl);
  let h='<div class="sub" style="margin:6px 0 4px;font-weight:600">Gebäude für <b>'+cityName+'</b> ('+cont+'):</div>';
  h+='<div class="bgr">';
  avail.forEach(([k,d])=>{const can=a2.treasury>=d.price;
    h+='<div class="bb'+(can?'':' off')+'" onclick="'+(can?"buildAllianceBuilding('"+k+"','"+cityName.replace(/'/g,"\\'")+"','"+co+"')":'')+'">';
    h+='<div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub">'+d.desc+'</div><div class="p">'+fmt(d.price)+'</div></div>'});
  h+='</div>';
  if(wrong.length)h+='<div class="sub" style="margin-top:4px;color:var(--td)">❌ Nicht in '+cont+': '+wrong.map(([,d])=>d.em+' '+d.name).join(', ')+'</div>';
  if(locked.length){h+='<div class="sec-label" style="margin-top:4px">🔒 Höheres Level</div><div class="bgr">';
    locked.forEach(([,d])=>{h+='<div class="bb off" style="opacity:.3"><div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub">Ab Lvl '+d.lvl+'</div></div>'});
    h+='</div>'}
  el.innerHTML=h;
}

// ═══ VEHICLES OVERVIEW (under Logistics) ═══
function compVehiclesOverview(el){
  let h=tabHead('logistics','🚛 Fahrzeugübersicht','Alle Fahrzeuge nach Status');
  const onOrder=G.vehs.filter(v=>v.st==='moving'&&v.cargo&&(v.cargo.oid||v.cargo.internal));
  const onMarket=G.vehs.filter(v=>v.st==='moving'&&v.cargo&&(v.cargo.market||v.cargo.allianceDelivery));
  const returning=G.vehs.filter(v=>v.st==='moving'&&(!v.cargo||v.cargo.returning));
  const idle=G.vehs.filter(v=>v.st==='idle');
  const selCid=G.sel;

  // Summary
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">';
  h+='<span class="tg">🚛 '+G.vehs.length+' gesamt</span>';
  h+='<span class="tg g">🟢 '+idle.length+' frei</span>';
  h+='<span class="tg y">📋 '+onOrder.length+' im Auftrag</span>';
  h+='<span class="tg" style="color:var(--go)">💰 '+onMarket.length+' Markt/Allianz</span>';
  if(returning.length)h+='<span class="tg">🔙 '+returning.length+' Rückweg</span>';
  h+='</div>';

  // On order
  if(onOrder.length){h+='<div class="sec-label">📋 Im Auftrag · '+onOrder.length+'</div>';
    onOrder.forEach(v=>{const vt=VT[v.type];if(!vt)return;
      const f=Cx(v.rt?.from);const t=Cx(v.rt?.to)||(v.rt?.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f||!t)return;const tn=tripT(f,t,vt.spd);const pct=Math.min(v.prog/(tn||1),1);
      const ord=v.cargo?.oid?G.orders.find(x=>x.id===v.cargo.oid):null;
      h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b>'+(v.cargo?.good?' '+(GOODS[v.cargo.good]?.em||'')+v.cargo.amt+'×':'')+'</span>';
      h+='<span class="eta">'+Math.floor(pct*100)+'% · '+ftime(Math.max(0,tn-v.prog))+'</span></div>';
      h+='<div class="sub">'+f.name+' → '+t.name+(ord?' · '+fmtOrd(ord.num)+' '+fmt(ord.rew):'')+'</div>';
      h+='<div class="pb" style="height:3px"><div class="pf" style="width:'+pct*100+'%"></div></div></div>'});}

  // Market/alliance
  if(onMarket.length){h+='<div class="sec-label" style="color:var(--go)">💰 Markt & Allianz · '+onMarket.length+'</div>';
    onMarket.forEach(v=>{const vt=VT[v.type];if(!vt)return;
      const f=Cx(v.rt?.from);const t=Cx(v.rt?.to)||(v.rt?.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f||!t)return;const tn=v.rt?.tripTime||tripT(f,t,vt.spd);const pct=Math.min(v.prog/(tn||1),1);
      const isAlly=v.cargo?.allianceDelivery;const isReturn=v.cargo?.returning;
      h+='<div class="crd" style="padding:4px 8px;border-left:3px solid '+(isAlly?'#a855f7':'var(--go)')+'"><div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="tg" style="font-size:9px;color:'+(isAlly?'#a855f7':'var(--go)')+'">'+(isReturn?'🔙 Rückfahrt':(isAlly?'🤝 Allianz':'💰 Markt'))+'</span></span>';
      h+='<span class="eta">'+Math.floor(pct*100)+'%</span></div>';
      h+='<div class="sub">'+(f.name||'?')+' → '+(t.name||'?')+'</div>';
      h+='<div class="pb" style="height:3px"><div class="pf" style="width:'+pct*100+'%;background:'+(isAlly?'#a855f7':'var(--go)')+'"></div></div></div>'});}

  // Returning (no cargo)
  if(returning.length){h+='<div class="sec-label">🔙 Auf dem Rückweg · '+returning.length+'</div>';
    returning.forEach(v=>{const vt=VT[v.type];if(!vt)return;
      const f=Cx(v.rt?.from);const t=Cx(v.rt?.to)||(v.rt?.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f||!t)return;const tn=tripT(f,t,vt.spd);const pct=Math.min(v.prog/(tn||1),1);
      h+='<div class="crd" style="padding:4px 8px"><div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="sub">→ '+(t.name||'?')+'</span></span>';
      h+='<span class="eta">'+Math.floor(pct*100)+'% · '+ftime(Math.max(0,tn-v.prog))+'</span></div>';
      h+='<div class="pb" style="height:3px"><div class="pf" style="width:'+pct*100+'%"></div></div></div>'});}

  // Idle - grouped by city
  if(idle.length){h+='<div class="sec-label">🟢 Frei · '+idle.length+'</div>';
    const byCity={};idle.forEach(v=>{const loc=v.loc||'?';if(!byCity[loc])byCity[loc]=[];byCity[loc].push(v)});
    Object.entries(byCity).forEach(([loc,vehs])=>{const c=C(loc);
      h+='<div class="crd" style="padding:4px 8px"><div class="sub" style="font-weight:600;margin-bottom:2px">📍 '+(c?.name||loc)+' · '+vehs.length+' Fahrzeug'+(vehs.length>1?'e':'')+'</div>';
      vehs.forEach(v=>{const vt=VT[v.type];h+='<div class="rw" style="font-size:11px;padding:1px 0"><span>'+vt.em+' '+vehName(v)+' · Kap: '+vehCap(v)+'</span></div>'});
      h+='</div>'});}
  el.innerHTML=h;
}

// ═══ TOAST FEEDBACK ═══
function toast(msg,color){
  let t=document.createElement('div');
  t.style.cssText='position:fixed;top:70px;left:50%;transform:translateX(-50%);padding:8px 18px;border-radius:10px;font-size:12px;font-family:var(--mono);z-index:9999;pointer-events:none;opacity:0;transition:opacity .3s;color:#fff;background:'+(color||'var(--a)')+';border:1px solid rgba(255,255,255,.2);box-shadow:0 4px 20px rgba(0,0,0,.4)';
  t.textContent=msg;document.body.appendChild(t);
  requestAnimationFrame(()=>t.style.opacity='1');
  setTimeout(()=>{t.style.opacity='0';setTimeout(()=>t.remove(),300)},2500);
}

// ═══ Alliance request price calculator ═══
function updAllyReqPrice(){
  const el=document.getElementById('allyReqCalc');if(!el)return;
  const good=document.getElementById('allyReqGood')?.value;
  const amt=parseInt(document.getElementById('allyReqAmt')?.value)||0;
  const ppu=parseInt(document.getElementById('allyReqPpu')?.value)||0;
  if(!good||!amt||!ppu){el.innerHTML='';return}
  const mktP=BASE_PRICES[good]||GOODS[good]?.bp||100;
  const total=amt*ppu;const diff=Math.round((ppu/mktP-1)*100);
  el.innerHTML='Gesamt: <b style="color:#a855f7">'+fmt(total)+'</b> aus Allianzkasse · Marktpreis: '+fmt(mktP)+'/St. · <span style="color:'+(diff>=0?'var(--a)':'var(--r)')+'">'+(diff>=0?'+':'')+diff+'%</span>';
}
