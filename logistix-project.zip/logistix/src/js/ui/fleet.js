function renderMaintVeh(v){
  const vt=VT[v.type];if(!vt)return'';const cond=vehCondition(v);
  const condClr=cond>60?'var(--a)':cond>30?'var(--go)':'var(--r)';
  const loc=C(v.loc);const depot=C(v.depot||v.loc);
  let h='<div class="crd" style="padding:6px 8px;'+(cond<30?'border-color:rgba(248,113,113,.3);background:rgba(248,113,113,.03)':'')+'">';
  h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="sub">'+vt.name+'</span></span>';
  h+='<span style="font-family:var(--mono);color:'+condClr+';font-weight:700">'+cond+'%</span></div>';
  h+='<div class="pb" style="margin:2px 0;height:4px"><div class="pf" style="width:'+cond+'%;background:'+condClr+'"></div></div>';
  h+='<div class="sub">'+(v.km||0).toLocaleString('de-DE')+' km · '+(v.st==='idle'?'📍 '+(loc?.name||'?'):'🔶 unterwegs')+'</div>';
  h+='<div style="display:flex;gap:4px;margin-top:3px">';
  if(v.st==='idle'&&cond<50)h+='<button class="btn sm" style="background:rgba(248,113,113,.1);color:var(--r);border-color:rgba(248,113,113,.3)" onclick="doMaintenance(\''+v.id+'\')">🔧 '+fmt(maintCost(v))+'</button>';
  if(v.st==='moving')h+='<button class="btn sm" onclick="recallVehicle(\''+v.id+'\')">🔙 Rückruf</button>';
  if(v.st==='idle'&&v.loc!==(v.depot||v.loc)){const depN=C(v.depot)?.name||'Depot';h+='<button class="btn sm" onclick="quickRecall(\''+v.id+'\')">🔙 → '+depN+'</button>';}
  h+='</div></div>';return h;
}

function compFleet(el){
  if(!G.sel&&cities.length)G.sel=cities[0].id;
  if(!G.fleetSub)G.fleetSub='overview';
  const sc=G.sel?C(G.sel):null;

  // ── MAINTENANCE SUB-TAB ──
  if(G.fleetSub==='maint'){
    let h=tabHead('fleet','🔧 Wartungsübersicht','Fahrzeugzustand und Wartung');
    // Filter by selected city or show all grouped by depot
    const selVehs=sc?G.vehs.filter(v=>(v.depot||v.loc)===sc.id):[...G.vehs];
    const sorted=selVehs.sort((a,b)=>vehCondition(a)-vehCondition(b));
    if(sc)h+='<div class="sub" style="margin-bottom:6px">📍 '+sc.name+' · '+sorted.length+' Fahrzeuge <button class="btn sm" onclick="G.sel=null;renComp()">Alle Standorte</button></div>';
    // Summary badges
    h+='<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">';
    const critical=sorted.filter(v=>vehCondition(v)<10).length;
    const warn=sorted.filter(v=>vehCondition(v)>=10&&vehCondition(v)<30).length;
    const mid=sorted.filter(v=>vehCondition(v)>=30&&vehCondition(v)<60).length;
    h+='<span class="tg" style="color:var(--r)">🔴 '+critical+' kritisch</span>';
    h+='<span class="tg" style="color:var(--go)">🟡 '+(warn+mid)+' wartbar</span>';
    h+='<span class="tg" style="color:var(--a)">🟢 '+(sorted.length-critical-warn-mid)+' OK</span>';
    h+='</div>';
    // Bulk maintenance
    const canMaintAll=sorted.filter(v=>v.st==='idle'&&vehCondition(v)<50);
    if(canMaintAll.length){const totalCost=canMaintAll.reduce((s,v2)=>s+maintCost(v2),0);
      h+='<button class="btn sm" style="margin-bottom:8px" onclick="'+(sc?"G.vehs.filter(v=>(v.depot||v.loc)===\\'"+sc.id+"\\'&&v.st===\\'idle\\'&&vehCondition(v)<50).forEach(v=>doMaintenance(v.id))":"G.vehs.filter(v=>v.st===\\'idle\\'&&vehCondition(v)<50).forEach(v=>doMaintenance(v.id))")+';renComp()"><i class="ri-tools-line"></i> Alle warten ('+canMaintAll.length+'×, '+fmt(totalCost)+')</button>';}
    // Group by depot if no city selected
    if(!sc){
      const depots={};sorted.forEach(v=>{const d=v.depot||v.loc;if(!depots[d])depots[d]=[];depots[d].push(v)});
      Object.entries(depots).forEach(([did,vehs])=>{const dc=C(did);
        h+='<div class="sec-label">🏢 '+(dc?.name||'?')+' · '+vehs.length+' Fahrzeuge</div>';
        vehs.forEach(v=>h+=renderMaintVeh(v));
      });
    } else {
      sorted.forEach(v=>h+=renderMaintVeh(v));
    }
    el.innerHTML=h;return;
  }

  // ── OVERVIEW ──
  let h=tabHead('fleet','🚛 Fuhrpark','Fahrzeuge verwalten und versenden');
  // Global summary
  const idle=G.vehs.filter(v=>v.st==='idle'),moving=G.vehs.filter(v=>v.st==='moving');
  h+='<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">';
  h+='<span class="tg g">'+idle.length+' bereit</span><span class="tg y">'+moving.length+' unterwegs</span><span class="tg">'+G.vehs.length+' gesamt</span>';
  const tc2={};G.vehs.forEach(v=>{tc2[v.type]=(tc2[v.type]||0)+1});
  Object.entries(tc2).forEach(([t,n])=>{const vt=VT[t];if(vt)h+='<span class="tg">'+vt.em+' ×'+n+'</span>'});
  h+='</div>';

  if(!sc){
    // Global view: show maintenance warnings prominently
    const needsMaint2=G.vehs.filter(v=>v.needsMaint&&v.st==='idle');
    if(needsMaint2.length){
      h+='<div style="padding:8px 10px;border-radius:8px;border:1px solid rgba(248,113,113,.3);background:rgba(248,113,113,.04);margin-bottom:8px">';
      h+='<div style="font-weight:600;color:var(--r);margin-bottom:4px"><i class="ri-alert-line"></i> '+needsMaint2.length+' Fahrzeug'+(needsMaint2.length>1?'e':'')+' brauchen Wartung</div>';
      needsMaint2.forEach(v=>{const vt=VT[v.type];const loc=C(v.loc);
        h+='<div class="crd" style="padding:5px 8px;border-color:rgba(248,113,113,.2)"><div class="rw"><span>'+vt.em+' '+vt.name+' · '+(loc?.name||'?')+'</span>';
        h+='<button class="btn sm" style="color:var(--r);border-color:rgba(248,113,113,.3)" onclick="doMaintenance(\''+v.id+'\')"><i class="ri-tools-line"></i> Warten ('+fmt(Math.round(vt.mt*2))+')</button></div></div>'});
      h+='<button class="btn sm" style="margin-top:4px" onclick="G.vehs.filter(v=>v.needsMaint&&v.st===\'idle\').forEach(v=>doMaintenance(v.id))"><i class="ri-tools-line"></i> Alle warten</button>';
      h+='</div>';}
    el.innerHTML=h+'<div class="sub" style="padding:10px;text-align:center">Standort links wählen für Details</div>';return}

  // Per-city view
  const here=G.vehs.filter(v=>v.st==='idle'&&v.loc===sc.id);
  const outgoing=G.vehs.filter(v=>v.st==='moving'&&(v.rt?.from===sc.id||(v.depot===sc.id&&v.rt?.from)));
  const incoming=G.vehs.filter(v=>v.st==='moving'&&v.rt?.to===sc.id);
  const dCap=depotCap(sc.id);const vAll=G.vehs.filter(v=>(v.depot||v.loc)===sc.id).length;
  h+='<div class="ch"><div class="ci">📍</div><div><div class="cn">'+sc.name+'</div><div class="cm">🏢 Depot '+vAll+'/'+dCap+' · '+here.length+' vor Ort · '+outgoing.length+' aus · '+incoming.length+' ein</div></div></div>';
  // Depot upgrade
  const dCost=depotUpgradeCost(sc.id);
  if(dCost){const canAfford=G.money>=dCost;h+='<button class="btn sm" style="margin-bottom:8px;'+(canAfford?'':'background:rgba(248,113,113,.08);color:var(--r);border-color:rgba(248,113,113,.3);opacity:.7')+'" onclick="'+(canAfford?"upgradeDepot(\'"+sc.id+"\')":'addLog(\'❌ Nicht genug Geld (\'+fmt('+dCost+')+\' benötigt)\')')+'">'+(canAfford?'🏢':'❌')+' Depot ausbauen → '+(dCap+2)+' Plätze · '+fmt(dCost)+'</button> '}
  else if(!(G.infra[sc.id]||[]).find(i=>i.type==='depot')){const canAffordD=G.money>=15000;h+='<button class="btn sm" style="margin-bottom:8px;'+(canAffordD?'':'color:var(--r);border-color:rgba(248,113,113,.3);opacity:.7')+'" onclick="'+(canAffordD?"buildInfra(\'"+sc.id+"\',\'depot\')":"addLog(\'❌ Nicht genug Geld\')")+'">🏢 Depot bauen ('+fmt(15000)+') → 3 Stellplätze</button> '}

  // Idle vehicles with maintenance indicator
  if(here.length){h+='<div class="sec-label">🟢 Vor Ort · '+here.length+'</div>';
    here.forEach(v=>{const vt=VT[v.type];const km=v.km||0;const needsM=v.needsMaint;const cond=vehCondition(v);
      const condClr=cond>60?'var(--a)':cond>30?'var(--go)':'var(--r)';
      h+='<div class="crd" style="padding:6px 8px;'+(needsM?'border-color:rgba(248,113,113,.4);background:rgba(248,113,113,.04)':'')+'">';
      h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="sub">'+vt.name+'</span></span>';
      h+='<span style="font-family:var(--mono);font-size:10px"><span style="color:'+condClr+'">'+cond+'%</span> · Kap: '+vehCap(v)+' · '+km.toLocaleString('de-DE')+' km</span></div>';
      // Condition bar
      h+='<div class="pb" style="margin:3px 0;height:4px"><div class="pf" style="width:'+cond+'%;background:'+condClr+'"></div></div>';
      h+='<div style="display:flex;gap:4px;margin-top:3px">';
      h+='<button class="btn sm" onclick="showSendPopup(\''+v.id+'\')">📤 Versenden</button>';
      if(cond<50||needsM)h+='<button class="btn sm" style="background:rgba(248,113,113,.1);color:var(--r);border-color:rgba(248,113,113,.3)" onclick="doMaintenance(\''+v.id+'\')">🔧 Warten ('+fmt(maintCost(v))+')</button>';
      h+='</div></div>'});
  } else h+='<div class="sub" style="padding:6px;text-align:center;opacity:.5">Keine Fahrzeuge vor Ort</div>';

  // Outgoing
  if(outgoing.length){h+='<div class="sec-label">🔶 Ausfahrend · '+outgoing.length+'</div>';
    outgoing.forEach(v=>{const vt=VT[v.type],t=Cx(v.rt?.to)||(v.rt?.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);if(!t)return;const km=v.km||0;
      const tn=tripT(sc,t,vt.spd),pct=Math.min(v.prog/tn,1);
      const cargo=v.cargo?(GOODS[v.cargo.good]?.em||'')+' '+v.cargo.amt+'×':'leer';
      const isOrd=v.cargo?.oid;const ord=isOrd?G.orders.find(x=>x.id===v.cargo.oid):null;
      h+='<div class="crd fleet-exp" style="padding:5px 8px;cursor:pointer" onclick="this.classList.toggle(\'open\')">';
      h+='<div class="rw"><span style="font-size:10px">'+vt.em+' → '+t.name+'</span><span class="eta">'+Math.floor(pct*100)+'% · '+ftime(tn-v.prog)+'</span></div>';
      h+='<div class="pb" style="margin:2px 0"><div class="pf" style="width:'+pct*100+'%"></div></div>';
      h+='<div class="fleet-details"><div class="sub">'+vt.name+' · Kap: '+vehCap(v)+' · 🛣️ '+km.toLocaleString('de-DE')+' km</div>';
      h+='<div class="sub">Ladung: '+cargo+(ord?' · Auftrag '+fmtOrd(ord.num)+' ('+fmt(ord.rew)+')':'')+'</div>';
      if(v.postDelivery){const pd=C(v.postDelivery);h+='<div class="sub">Danach: → '+(pd?.name||'?')+'</div>'}
      h+='<button class="btn red sm" style="margin-top:3px" onclick="event.stopPropagation();recallVehicle(\''+v.id+'\')"><i class="ri-arrow-go-back-line"></i> Zurückrufen</button>';
      h+='</div></div>'})}

  // Incoming
  if(incoming.length){h+='<div class="sec-label">🔵 Eintreffend · '+incoming.length+'</div>';
    incoming.forEach(v=>{const vt=VT[v.type],f=Cx(v.rt?.from)||(v.rt?.fromLat?{lat:v.rt.fromLat,lng:v.rt.fromLng,name:v.rt.fromName||'?'}:null);if(!f){f=sc};
      const tn=tripT(f,sc,vt.spd),pct=Math.min(v.prog/tn,1);
      const cargo=v.cargo?(GOODS[v.cargo.good]?.em||'')+' '+v.cargo.amt+'×':'';
      h+='<div class="crd fleet-exp" style="padding:5px 8px;cursor:pointer" onclick="this.classList.toggle(\'open\')">';
      h+='<div class="rw"><span style="font-size:10px">'+vt.em+' ← '+f.name+'</span><span class="eta">'+Math.floor(pct*100)+'% · '+ftime(tn-v.prog)+'</span></div>';
      h+='<div class="pb" style="margin:2px 0"><div class="pf" style="width:'+pct*100+'%"></div></div>';
      h+='<div class="fleet-details"><div class="sub">'+vt.name+' · Kap: '+vehCap(v)+(cargo?' · '+cargo:'')+'</div>';
      h+='<button class="btn red sm" style="margin-top:3px" onclick="event.stopPropagation();recallVehicle(\''+v.id+'\')"><i class="ri-arrow-go-back-line"></i> Zurückrufen</button>';
      h+='</div></div>'})}

  el.innerHTML=h}

// Send popup for fleet
function showSendPopup(vid){
  const v=G.vehs.find(x=>x.id===vid);if(!v)return;const vt=VT[v.type];const lc=C(v.loc);if(!lc)return;
  const targets=cities.filter(x=>x.id!==v.loc&&canVehTravel(v,x.id)).sort((a,b)=>hav(lc.lat,lc.lng,a.lat,a.lng)-hav(lc.lat,lc.lng,b.lat,b.lng));
  document.getElementById('mT').textContent='📤 '+vt.em+' '+vt.name+' versenden';
  let h='<div class="sub" style="margin-bottom:8px">📍 '+lc.name+' · Kap: '+vehCap(v)+' · 🛣️ '+(v.km||0).toLocaleString('de-DE')+' km</div>';
  if(!targets.length)h+='<div class="sub" style="color:var(--r)">Keine erreichbaren Ziele</div>';
  targets.forEach(t=>{
    h+='<div class="crd" style="cursor:pointer;padding:6px 8px" onclick="sndV(\''+vid+'\',\''+t.id+'\');closeMdl()"><div class="rw"><span>'+cSzIcon(t.pop)+' '+t.name+'</span>';
    h+='<span class="sub">'+fdist(lc,t)+' km · '+ftime(tripT(lc,t,vt.spd))+'</span></div></div>'});
  document.getElementById('mB').innerHTML=h;document.getElementById('mBg').style.display='flex';
}

// Send goods popup: pick destination, amount, vehicles
function showSendGoodsPopup(fromCid,good,maxAmt){
  const fc=C(fromCid);if(!fc)return;const gd=GOODS[good];if(!gd)return;
  const targets=cities.filter(x=>x.id!==fromCid).sort((a,b)=>hav(fc.lat,fc.lng,a.lat,a.lng)-hav(fc.lat,fc.lng,b.lat,b.lng));
  const idleHere=G.vehs.filter(v=>v.st==='idle'&&v.loc===fromCid);

  let existing=document.getElementById('sendGoodsPopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='sendGoodsPopup';popup.className='unlock-bg';
  let h='<div class="unlock-popup" style="width:440px;max-height:80vh;overflow-y:auto">';
  h+='<div class="unlock-body">';
  h+='<div class="unlock-name">📦 '+gd.em+' '+gd.name+' versenden</div>';
  h+='<div class="unlock-info">📍 '+fc.name+' · Vorrat: <b>'+maxAmt+'</b>×</div>';

  // Step 1: Amount
  h+='<div style="margin:12px 0"><div style="font-family:var(--mono);font-size:15px;color:var(--a);font-weight:700;margin-bottom:4px">① Menge wählen</div>';
  h+='<div style="display:flex;align-items:center;gap:8px">';
  h+='<input type="range" id="sgRange" min="1" max="'+maxAmt+'" value="'+Math.min(maxAmt,5)+'" style="flex:1;accent-color:var(--a)" oninput="document.getElementById(\'sgAmt\').value=this.value;updateSgInfo()" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
  h+='<input type="number" id="sgAmt" class="sl" value="'+Math.min(maxAmt,5)+'" min="1" max="'+maxAmt+'" style="width:60px;font-size:14px;padding:6px;text-align:center" oninput="document.getElementById(\'sgRange\').value=this.value;updateSgInfo()" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
  h+='<span class="sub">/ '+maxAmt+'</span></div></div>';

  // Step 2: Destination
  h+='<div style="margin:12px 0"><div style="font-family:var(--mono);font-size:15px;color:var(--a);font-weight:700;margin-bottom:4px">② Zielort wählen</div>';
  h+='<select id="sgDest" class="sl-action" style="width:100%;padding:8px" onfocus="renderBlocked=true" onblur="renderBlocked=false"><option value="">Ziel auswählen…</option>';
  targets.forEach(t=>{h+='<option value="'+t.id+'">'+cSzIcon(t.pop)+' '+t.name+' · '+fdist(fc,t)+' km</option>'});
  h+='</select></div>';

  // Step 3: Vehicles
  h+='<div style="margin:12px 0"><div style="font-family:var(--mono);font-size:15px;color:var(--a);font-weight:700;margin-bottom:4px">③ Fahrzeuge auswählen ('+idleHere.length+' vor Ort)</div>';
  if(!idleHere.length)h+='<div class="sub" style="color:var(--r);padding:8px;text-align:center">⚠️ Keine Fahrzeuge in '+fc.name+'!<br>Sende erst welche im Fuhrpark-Tab.</div>';
  else{
    idleHere.forEach(v=>{const vt=VT[v.type],km=v.km||0;
      h+='<label class="veh-check"><input type="checkbox" class="sg-vc" data-vid="'+v.id+'" data-cap="'+vehCap(v)+'" onchange="updateSgInfo()" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
      h+='<span>'+vt.em+' '+vt.name+' · Kap: <b>'+vehCap(v)+'</b> · 🛣️ '+km.toLocaleString('de-DE')+' km</span></label>'});
    h+='<div class="sel-info" id="sgSelInfo"><span class="sub">Keine Fahrzeuge ausgewählt</span></div>';
  }
  h+='</div>';

  // Buttons
  h+='<div style="display:flex;gap:8px;margin-top:14px">';
  h+='<button class="btn full" style="padding:10px" onclick="execSendGoods(\''+fromCid+'\',\''+good+'\')">🚀 Absenden</button>';
  h+='<button class="btn red full" style="padding:10px" onclick="document.getElementById(\'sendGoodsPopup\').remove()">Abbrechen</button>';
  h+='</div></div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}

function updateSgInfo(){
  const el=document.getElementById('sgSelInfo');if(!el)return;
  const amt=parseInt(document.getElementById('sgAmt')?.value)||1;
  const checks=document.querySelectorAll('.sg-vc:checked');
  if(!checks.length){el.innerHTML='<span class="sub">Keine Fahrzeuge ausgewählt</span>';return}
  let totalCap=0,count=0;
  checks.forEach(cb=>{totalCap+=parseInt(cb.dataset.cap)||0;count++});
  const enough=totalCap>=amt;
  el.innerHTML='<span style="font-family:var(--mono);font-size:11px;font-weight:700;color:'+(enough?'var(--a)':'var(--go)')+'">'+count+' Fahrzeug'+(count>1?'e':'')+' · Kapazität: '+totalCap+'/'+amt+(enough?' ✅':' ⚠️ reicht nicht')+'</span>';
}

function execSendGoods(fromCid,good){
  const amt=parseInt(document.getElementById('sgAmt')?.value)||0;
  const dest=document.getElementById('sgDest')?.value;
  if(!amt||!dest){addLog('❌ Menge und Ziel wählen');return}
  const s=G.stor[fromCid];if(!s||(s[good]||0)<amt){addLog('❌ Nicht genug Vorrat');return}
  const checks=document.querySelectorAll('.sg-vc:checked');
  if(!checks.length){addLog('❌ Kein Fahrzeug ausgewählt');return}
  const fc=C(fromCid),tc=C(dest);
  let totalSent=0,vehCount=0;
  checks.forEach(cb=>{
    const vid=cb.dataset.vid;const v=G.vehs.find(x=>x.id===vid);
    if(!v||v.st!=='idle')return;
    const remaining=amt-totalSent;if(remaining<=0)return;
    const avail=s[good]||0;
    const canLoad=Math.min(remaining,avail,vehCap(v));
    if(canLoad<=0)return;
    s[good]-=canLoad;if(s[good]<=0)delete s[good];
    totalSent+=canLoad;vehCount++;
    v.st='moving';v.rt={from:fromCid,to:dest};
    v.cargo={internal:true,good,amt:canLoad};v.prog=0;
    if(typeof ensureRoute==='function')ensureRoute(v);
  });
  if(totalSent>0){
    addLog('📦 '+vehCount+' Fahrzeuge · '+totalSent+'× '+(GOODS[good]?.em||'')+' '+fc?.name+' → '+tc?.name);
  } else addLog('❌ Nichts geladen');
  const popup=document.getElementById('sendGoodsPopup');if(popup)popup.remove();
  ua();
}

// ═══ LOGISTICS (merged Aufträge + Routen) ═══
