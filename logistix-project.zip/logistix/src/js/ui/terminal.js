function setCompTab(t){compTab=t;renComp()}

function renComp(){
  document.querySelectorAll('.ctab').forEach(t=>{t.classList.toggle('on',t.dataset.ct===compTab);t.onclick=()=>setCompTab(t.dataset.ct)});
  const locEl=document.getElementById('compLoc');if(locEl){const c=G.sel?C(G.sel):null;locEl.textContent=c?'📍 '+c.name:'📍 —'}

  // Explorer: group by continent
  const exp=document.getElementById('compExplorer');if(!exp)return;
  let eh='<div style="font-size:12px;color:var(--td);padding:4px 6px;font-family:var(--mono)">📍 '+cities.length+' Standorte</div>';
  // Dealer tab: sub-tabs in explorer
  if(compTab==='dealer'){
    if(!G.dealerSub)G.dealerSub='buy';
    eh+='<div class="ex-city'+(G.dealerSub==='buy'?' sel':'')+'" onclick="G.dealerSub=\'buy\';renComp()" style="font-weight:600;color:'+(G.dealerSub==='buy'?'var(--a)':'var(--td)')+'"><i class="ri-store-2-line"></i> Kaufen</div>';
    eh+='<div class="ex-city'+(G.dealerSub==='sell'?' sel':'')+'" onclick="G.dealerSub=\'sell\';renComp()" style="font-weight:600;color:'+(G.dealerSub==='sell'?'var(--r)':'var(--td)')+'"><i class="ri-exchange-line"></i> Verkaufen</div>';
    eh+='<div style="height:1px;background:var(--bd);margin:4px 6px"></div>';
  }
  // Fleet tab: sub-tabs in explorer
  if(compTab==='fleet'){
    if(!G.fleetSub)G.fleetSub='overview';
    const needsM=G.vehs.filter(v=>vehCondition(v)<50).length;
    eh+='<div class="ex-city'+(G.fleetSub==='overview'?' sel':'')+'" onclick="G.fleetSub=\'overview\';renComp()" style="font-weight:600;color:'+(G.fleetSub==='overview'?'var(--a)':'var(--td)')+'"><i class="ri-truck-line"></i> Übersicht</div>';
    eh+='<div class="ex-city'+(G.fleetSub==='maint'?' sel':'')+'" onclick="G.fleetSub=\'maint\';renComp()" style="font-weight:600;color:'+(G.fleetSub==='maint'?'var(--r)':'var(--td)')+'"><i class="ri-tools-line"></i> Wartung'+(needsM?' <span style="background:var(--r);color:#fff;border-radius:8px;padding:0 5px;font-size:9px">'+needsM+'</span>':'')+'</div>';
    eh+='<div style="height:1px;background:var(--bd);margin:4px 6px"></div>';
  }
  // Logistics tab: combined sub-tabs
  if(compTab==='logistics'){
    if(!G.logSub)G.logSub='orders';
    const hist=G.history||[];const soCount=(G.standingOrders||[]).length;
    eh+='<div class="ex-city'+(G.logSub==='orders'?' sel':'')+'" onclick="G.logSub=\'orders\';renComp()" style="font-weight:600;color:'+(G.logSub==='orders'?'var(--a)':'var(--td)')+'"><i class="ri-file-list-3-line"></i> Aufträge</div>';
    eh+='<div class="ex-city'+(G.logSub==='routes'?' sel':'')+'" onclick="G.logSub=\'routes\';renComp()" style="font-weight:600;color:'+(G.logSub==='routes'?'var(--bl)':'var(--td)')+'"><i class="ri-route-line"></i> Routen</div>';
    eh+='<div class="ex-city'+(G.logSub==='transfer'?' sel':'')+'" onclick="G.logSub=\'transfer\';renComp()" style="font-weight:600;color:'+(G.logSub==='transfer'?'var(--go)':'var(--td)')+'"><i class="ri-send-plane-line"></i> Transfer</div>';
    eh+='<div class="ex-city'+(G.logSub==='standing'?' sel':'')+'" onclick="G.logSub=\'standing\';renComp()" style="font-weight:600;color:'+(G.logSub==='standing'?'var(--go)':'var(--td)')+'"><i class="ri-refresh-line"></i> Daueraufträge'+(soCount?' ('+soCount+')':'')+'</div>';
    eh+='<div class="ex-city'+(G.logSub==='stats'?' sel':'')+'" onclick="G.logSub=\'stats\';renComp()" style="font-weight:600;color:'+(G.logSub==='stats'?'var(--bl)':'var(--td)')+'"><i class="ri-bar-chart-line"></i> Statistiken</div>';
    eh+='<div class="ex-city'+(G.logSub==='history'?' sel':'')+'" onclick="G.logSub=\'history\';renComp()" style="font-weight:600;color:'+(G.logSub==='history'?'var(--td)':'var(--td)')+'"><i class="ri-history-line"></i> Historie ('+hist.length+')</div>';
    eh+='<div class="ex-city'+(G.logSub==='vehicles'?' sel':'')+'" onclick="G.logSub=\'vehicles\';renComp()" style="font-weight:600;color:'+(G.logSub==='vehicles'?'var(--a2)':'var(--td)')+'"><i class="ri-truck-line"></i> Fahrzeuge ('+G.vehs.length+')</div>';
    eh+='<div style="height:1px;background:var(--bd);margin:4px 6px"></div>';
  }
  // Market tab: sub-tabs in explorer
  if(compTab==='market'){
    if(!G.marketSub)G.marketSub='prices';
    eh+='<div class="ex-city'+(G.marketSub==='prices'?' sel':'')+'" onclick="G.marketSub=\'prices\';renComp()" style="font-weight:600;color:'+(G.marketSub==='prices'?'var(--a)':'var(--td)')+'"><i class="ri-line-chart-line"></i> Preisübersicht</div>';
    eh+='<div class="ex-city'+(G.marketSub==='sell'?' sel':'')+'" onclick="G.marketSub=\'sell\';renComp()" style="font-weight:600;color:'+(G.marketSub==='sell'?'var(--go)':'var(--td)')+'"><i class="ri-money-dollar-circle-line"></i> Verkaufen</div>';
    eh+='<div class="ex-city'+(G.marketSub==='trends'?' sel':'')+'" onclick="G.marketSub=\'trends\';renComp()" style="font-weight:600;color:'+(G.marketSub==='trends'?'var(--bl)':'var(--td)')+'"><i class="ri-bar-chart-grouped-line"></i> Trends</div>';
    eh+='<div class="ex-city'+(G.marketSub==='supply'?' sel':'')+'" onclick="G.marketSub=\'supply\';renComp()" style="font-weight:600;color:'+(G.marketSub==='supply'?'#a855f7':'var(--td)')+'"><i class="ri-scales-3-line"></i> Angebot/Nachfrage</div>';
    eh+='<div class="ex-city'+(G.marketSub==='allyreqs'?' sel':'')+'" onclick="G.marketSub=\'allyreqs\';renComp()" style="font-weight:600;color:'+(G.marketSub==='allyreqs'?'#a855f7':'var(--td)')+'"><i class="ri-shopping-bag-line"></i> Allianzanfragen</div>';
    if(G.marketDetail)eh+='<div class="ex-city'+(G.marketSub==='detail'?' sel':'')+'" onclick="G.marketSub=\'detail\';renComp()" style="font-weight:600;color:'+(G.marketSub==='detail'?'var(--a2)':'var(--td)')+'"><i class="ri-focus-3-line"></i> '+(GOODS[G.marketDetail]?.name||'Detail')+'</div>';
    eh+='<div style="height:1px;background:var(--bd);margin:4px 6px"></div>';
  }
  const grouped={};
  cities.forEach(ci=>{const co=(ci.co||'').toUpperCase();const cont=getContinent(co);if(!grouped[cont])grouped[cont]=[];grouped[cont].push(ci)});
  const contOrder=Object.values(REGIONS).map(r=>r.name);contOrder.push('Sonstige');
  contOrder.forEach(cont=>{
    const list=grouped[cont];if(!list||!list.length)return;
    const collapsed=explorerCollapsed[cont];
    eh+='<div class="ex-continent" onclick="explorerCollapsed[\''+cont+'\']=!explorerCollapsed[\''+cont+'\'];renComp()"><span class="arrow'+(collapsed?'':' open')+'">▶</span> '+cont+' <span style="font-size:10px;font-weight:400;opacity:.5">'+list.length+'</span></div>';
    if(!collapsed){
      list.sort((a,b)=>a.name.localeCompare(b.name)).forEach(ci=>{
        const isSel=G.sel===ci.id&&!routesShowAll;const hasBld=(G.blds[ci.id]||[]).length>0;
        let badge='';
        if(compTab==='routes'){
          const rc=G.orders.filter(o=>o.acc&&(o.from===ci.id||o.to===ci.id)).length;
          const vc=G.vehs.filter(v=>v.st==='moving'&&(v.rt?.from===ci.id||v.rt?.to===ci.id)).length;
          if(rc||vc)badge=' <span style="font-size:8px;color:var(--go)">'+(rc?'📋'+rc:'')+(vc?' 🚛'+vc:'')+'</span>';
        }
        eh+='<div class="ex-city'+(isSel?' sel':'')+(hasBld?' has-bld':'')+'" onclick="selectLocation(\''+ci.id+'\')"><span class="ex-cc">'+(ci.co||'?')+'</span>'+ci.name+badge+'</div>';
      });
    }
  });
  exp.innerHTML=eh;

  // Tab content
  const el=document.getElementById('compBody');
  const evts=typeof activeEvents==='function'?activeEvents():[];
  const tabs={missions:compMissions,dealer:compDealer,fleet:compFleet,logistics:compLogistics,inventory:compInventory,market:compMarket,buildings:compBuildings};
  if(tabs[compTab]){
    tabs[compTab](el);
    // Prepend events banner + auto-manager
    let pre='';
    if(evts.length){pre+='<div style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap">';
      evts.forEach(e=>{const def=EVENTS.find(x=>x.id===e.id);if(!def)return;const rem=e.endTick-G.tick;
        pre+='<div style="padding:4px 10px;border-radius:8px;font-size:11px;font-family:var(--mono);border:1px solid rgba(251,191,36,.3);background:rgba(251,191,36,.06);color:var(--go)">'+def.icon+' '+def.name+' <span style="opacity:.6">'+ftime(rem)+'</span></div>'});
      pre+='</div>';}
    if(['logistics','inventory'].includes(compTab)){
      const canAuto=playerLvl()>=5;
      if(canAuto)pre+='<div style="display:flex;justify-content:flex-end;margin-bottom:4px"><button class="btn sm" onclick="toggleAutoManager()" style="'+(G.autoManager?'background:rgba(61,214,140,.15);color:var(--a);border-color:var(--a)':'')+'">'+(G.autoManager?'🤖 Manager AN':'🤖 Auto')+'</button></div>';
      else pre+='<div style="display:flex;justify-content:flex-end;margin-bottom:4px"><span class="tg" style="opacity:.4">🤖 Auto-Manager ab Level 5</span></div>';}
    if(pre)el.innerHTML=pre+el.innerHTML;
  }
}

// ═══ MISSIONS ═══
