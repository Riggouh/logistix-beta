function compDealer(el){
  if(!G.sel&&cities.length)G.sel=cities[0].id;
  if(!G.dealerSub)G.dealerSub='buy';
  const c=G.sel?C(G.sel):null;if(!c){el.innerHTML='<div class="sub" style="padding:20px;text-align:center">Noch kein Standort freigeschaltet</div>';return}

  // ── SELL SUB-TAB ──
  if(G.dealerSub==='sell'){
    let h=tabHead('dealer','🔄 Fahrzeuge verkaufen','Fahrzeuge verwalten, rückrufen und verkaufen');
    // Filter toggle
    const showAll=G.dealerShowAll;
    const vehs=showAll?[...G.vehs]:G.vehs.filter(v=>(v.depot||v.loc)===c.id);
    h+='<div style="display:flex;gap:6px;align-items:center;margin-bottom:8px">';
    h+='<span class="sub">'+vehs.length+' Fahrzeuge'+(showAll?'':' · 📍 '+c.name)+'</span>';
    h+='<button class="btn sm'+(showAll?' on':'')+'" onclick="G.dealerShowAll='+(!showAll)+';renComp()">'+(showAll?'📍 Nach Standort':'🌍 Alle anzeigen')+'</button>';
    h+='</div>';
    if(!vehs.length){h+='<div class="sub" style="text-align:center;padding:16px">Keine Fahrzeuge</div>';el.innerHTML=h;return}
    // Group by depot if showing all
    const groups={};
    vehs.forEach(v=>{const d=v.depot||v.loc;if(!groups[d])groups[d]=[];groups[d].push(v)});
    Object.entries(groups).forEach(([did,gVehs])=>{
      const dc=C(did);
      if(showAll)h+='<div class="sec-label">🏢 '+(dc?.name||'?')+' · '+gVehs.length+'</div>';
      gVehs.sort((a,b)=>vehCondition(a)-vehCondition(b)).forEach(v=>{
        const vt=VT[v.type];if(!vt)return;const cond=vehCondition(v);
        const condClr=cond>60?'var(--a)':cond>30?'var(--go)':'var(--r)';
        const atHome=v.st==='idle'&&v.loc===(v.depot||v.loc);
        const isIdle=v.st==='idle';const isMoving=v.st==='moving';
        const sellPrice=Math.floor(vt.price*0.4);
        h+='<div class="crd" style="padding:6px 8px">';
        h+='<div class="rw"><span>'+vt.em+' <b>'+vehName(v)+'</b> <span class="sub">'+vt.name+'</span></span>';
        h+='<span style="font-family:var(--mono);color:'+condClr+'">'+cond+'%</span></div>';
        h+='<div class="pb" style="margin:2px 0;height:3px"><div class="pf" style="width:'+cond+'%;background:'+condClr+'"></div></div>';
        // Status line
        const loc=C(v.loc);const depot=C(v.depot);
        h+='<div class="sub">'+(isIdle?'📍 '+(loc?.name||'?'):'🔶 unterwegs')+' · '+(v.km||0).toLocaleString('de-DE')+' km'+(v.recallToDepot?' · <span style="color:var(--go)">🔙 Rückruf geplant</span>':'')+'</div>';
        // Actions
        h+='<div style="display:flex;gap:4px;margin-top:4px;flex-wrap:wrap">';
        if(atHome)h+='<button class="btn red sm" onclick="sellVehicle(\''+v.id+'\')">Verkaufen +'+fmt(sellPrice)+'</button>';
        else if(isIdle)h+='<button class="btn sm" onclick="quickRecall(\''+v.id+'\')">🔙 An Depot '+(depot?.name||'')+'</button>';
        if(isMoving&&!v.recallToDepot)h+='<button class="btn sm" style="color:var(--go);border-color:rgba(251,191,36,.3)" onclick="G.vehs.find(x=>x.id===\''+v.id+'\').recallToDepot=true;addLog(\'🔙 Rückruf nach Auftragsende geplant\');renComp()">🔙 Nach Auftrag → Depot</button>';
        if(isMoving&&v.recallToDepot)h+='<span class="tg" style="color:var(--go)">🔙 Rückruf geplant</span>';
        if(isMoving)h+='<button class="btn sm" onclick="recallVehicle(\''+v.id+'\')">⚡ Sofort rückrufen</button>';
        if(!atHome&&isIdle)h+='<span class="sub" style="color:var(--td)">Nicht im Depot – erst rückrufen</span>';
        h+='</div></div>'});
    });
    el.innerHTML=h;return;
  }

  // ── BUY SUB-TAB (default) ──
  const lvl=playerLvl();let h=tabHead('dealer','🛒 Händler','Fahrzeuge kaufen und verwalten');
  // Depot capacity info
  const dCap2=depotCap(c.id);const vHere2=G.vehs.filter(v=>(v.depot||v.loc)===c.id).length;
  const depotFull=vHere2>=dCap2;
  h+='<div class="ch"><div class="ci">🛒</div><div><div class="cn">Fahrzeughändler · '+c.name+'</div><div class="cm">Level '+lvl+' · '+LEVELS[lvl-1].em+' '+LEVELS[lvl-1].name+' · 🏢 Depot '+vHere2+'/'+dCap2+'</div></div></div>';
  if(depotFull)h+='<div style="padding:6px 10px;border-radius:8px;border:1px solid rgba(248,113,113,.3);background:rgba(248,113,113,.04);margin-bottom:8px;font-size:11px;color:var(--r)"><i class="ri-alert-line"></i> <b>Depot voll!</b> Kein Platz für neue Fahrzeuge. <button class="btn sm" style="color:var(--r);border-color:rgba(248,113,113,.3)" onclick="openComputer();setCompTab(\'fleet\')">Depot ausbauen</button></div>';
  // Per-region vehicle summary
  const regVeh={};G.vehs.forEach(v=>{const loc=C(v.loc);if(!loc)return;const rk=getRegion((loc.co||'').toUpperCase());const ri=REGIONS[rk];const rn=ri?ri.name:'?';regVeh[rn]=(regVeh[rn]||0)+1});
  if(Object.keys(regVeh).length){h+='<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">';
    h+='<span class="tg">🚛 '+G.vehs.length+' gesamt</span>';
    Object.entries(regVeh).forEach(([rn,cnt])=>{h+='<span class="tg">'+rn+': '+cnt+'</span>'});
    h+='</div>';}
  const here=G.vehs.filter(v=>v.st==='idle'&&v.loc===c.id);
  if(here.length){h+='<div class="sec-label">Vor Ort · '+here.length+'</div>';
    const byType={};here.forEach(v=>{if(!byType[v.type])byType[v.type]={cnt:0,ids:[]};byType[v.type].cnt++;byType[v.type].ids.push(v.id)});
    Object.entries(byType).forEach(([t,d])=>{const vt=VT[t];if(!vt)return;const sellPrice=Math.floor(vt.price*0.4);
      h+='<div class="crd" style="padding:5px 8px"><div class="rw"><span>'+vt.em+' '+vt.name+' ×'+d.cnt+'</span>';
      h+='<button class="btn red sm" onclick="sellVehicle(\''+d.ids[0]+'\')">Verkaufen +'+fmt(sellPrice)+'</button></div></div>'});
  }
  Object.entries(VEH_CATS).forEach(([cat,label])=>{
    const unlocked=Object.entries(VT).filter(([,d])=>d.cat===cat&&d.lvl<=lvl);
    const locked=Object.entries(VT).filter(([,d])=>d.cat===cat&&d.lvl>lvl);
    if(!unlocked.length&&!locked.length)return;
    h+='<div class="sec-label">'+label+'</div>';
    unlocked.forEach(([k,d])=>{const canBuy=canBuyVehAt(k,c.id);const dis=!canBuy||G.money<d.price;
      h+='<div class="crd'+(dis?' off':'')+'" style="cursor:'+(dis?'default':'pointer')+'" onclick="'+(canBuy&&G.money>=d.price?"buyV('"+k+"')":'')+'">';
      h+='<div class="rw"><span>'+d.em+' '+d.name+'</span><span class="p">'+fmt(d.price)+'</span></div>';
      const mKm={land:10000,rail:25000,sea:50000,air:15000}[d.cat]||10000;
      h+='<div class="sub">Kap: '+d.cap+' · '+d.spd+' km/h · Wartung alle '+mKm.toLocaleString('de-DE')+' km ('+fmt(Math.round(d.price*0.08))+')</div>';
      if(!canBuy)h+='<div class="sub" style="color:var(--r)">Benötigt: '+({rail:'Bahnhof',sea:'Hafen',air:'Flughafen'}[d.cat]||'')+'</div>';h+='</div>'});
    locked.forEach(([k,d])=>{
      h+='<div class="crd off" style="opacity:.35"><div class="rw"><span>'+d.em+' '+d.name+'</span><span class="sub">🔒 Level '+d.lvl+'</span></div></div>'});
  });
  el.innerHTML=h}

// ═══ FLEET ═══
// Helper: render single vehicle in maintenance view
