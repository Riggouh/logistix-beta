// ══════════════════════════════════════════
// SEARCH (Hybrid: Local DB + Nominatim)
// Dedup by name+country, prefer local DB
// ══════════════════════════════════════════

function dedupMerge(local,remote){
  const merged=[...local];
  remote.forEach(r=>{
    // Skip if same name+country in local
    const nameKey=r.name.toLowerCase().replace(/[^a-z]/g,'');
    if(merged.find(m=>{
      const mKey=m.name.toLowerCase().replace(/[^a-z]/g,'');
      return mKey===nameKey && m.co===r.co;
    }))return;
    // Skip if very close coords
    if(merged.find(m=>Math.abs(m.lat-r.lat)<.005&&Math.abs(m.lng-r.lng)<.005))return;
    merged.push(r);
  });
  return merged;
}

function infraText(c){
  const parts=[];
  if(c.airport)parts.push('✈️ Flughafen');
  if(c.harbor)parts.push('⚓ Hafen');
  return parts.length?parts.join(' · '):'';
}

// ── Start Screen ──
const startIn=document.getElementById('startInput'),startRes=document.getElementById('startResults');
let startNomTimer=null;

startIn.addEventListener('input',()=>{
  const q=startIn.value.trim();
  if(q.length<1){startRes.innerHTML='<div class="start-hint">z.B. "Alzey", "Wendelsheim", "Tokyo"...</div>';return}
  const local=searchCities(q);
  renderStartResults(local,[]);
  startRes._d=local;
  clearTimeout(startNomTimer);
  if(q.length>=2)startNomTimer=setTimeout(()=>nomSearch(q,'start'),400);
});

function renderStartResults(local,remote){
  const merged=dedupMerge(local,remote);
  if(!merged.length){startRes.innerHTML='<div class="start-hint">Suche läuft...</div>';return}
  startRes.innerHTML=merged.map((c,i)=>{
    const src=c._nom?'<span style="font-size:9px;color:var(--a2);margin-left:4px">🌐</span>':'';
    const inf=infraText(c);
    const reg=REGIONS[getRegion(c.co)];
    return'<div class="start-item" onclick="pickStart('+i+')"><div style="flex:1"><div class="si-name">'+cSzIcon(c.pop)+' '+c.name+src+'</div>'
      +'<div class="si-meta">'+c.co+' · '+cSz(c.pop)+' · '+c.pop.toLocaleString('de-DE')+' Einw.'+(inf?' · '+inf:'')+'</div>'
      +(reg?'<div class="si-region" style="color:'+reg.color+'">'+reg.em+' '+reg.name+'</div>':'')
      +'</div></div>'
  }).join('');
  startRes._d=merged;
}

function pickStart(idx){
  const data=startRes._d;if(!data||!data[idx])return;
  const c={...data[idx]};
  c.id=(c.id||c.name.toLowerCase().replace(/[^a-z0-9]/g,''))+'_'+uid().substr(1,4);
  delete c._nom;delete c._s;
  newGame(c);launchGame(c);
}

// ── In-Game Search (initialized after map) ──
let si=null,sr=null,gameNomTimer=null;

function initGameSearch(){
  si=document.getElementById('si');sr=document.getElementById('sr');
  if(!si||!sr)return;

  si.addEventListener('input',()=>{
    const q=si.value.trim();
    if(q.length<1){sr.classList.remove('open');return}
    const local=searchCities(q);
    renderGameResults(local,[]);
    sr._local=local;sr._remote=[];sr._merged=local;
    sr.classList.add('open');
    clearTimeout(gameNomTimer);
    if(q.length>=2)gameNomTimer=setTimeout(()=>nomSearch(q,'game'),400);
  });
  si.addEventListener('focus',()=>{if(si.value.length>=1)si.dispatchEvent(new Event('input'))});
  document.addEventListener('click',e=>{const sw=document.getElementById('sw');if(sw&&!sw.contains(e.target))sr.classList.remove('open')});
}

function renderGameResults(local,remote){
  const merged=dedupMerge(local,remote);
  if(!merged.length){sr.innerHTML='<div class="srl">Suche läuft...</div>';return}
  sr.innerHTML=merged.map((c,i)=>{
    const ex=cities.find(x=>Math.abs(x.lat-c.lat)<.02&&Math.abs(x.lng-c.lng)<.02);
    const src=c._nom?'<span style="font-size:9px;color:var(--a2);margin-left:3px">🌐</span>':'';
    const inf=infraText(c);
    if(ex)return'<div class="sri" onclick="goCity(\''+ex.id+'\')"><div class="sr-row"><div><div class="sn">'+cSzIcon(c.pop)+' '+c.name+src+'</div><div class="sm">'+c.co+' · '+c.pop.toLocaleString('de-DE')+' Einw.'+(inf?' · '+inf:'')+'</div></div><div class="sr-cost owned">✓</div></div></div>';
    const cost=unlockCost(c.lat,c.lng,c.pop);
    return'<div class="sri" onclick="unlockCityM('+i+')"><div class="sr-row"><div><div class="sn">'+cSzIcon(c.pop)+' '+c.name+src+'</div><div class="sm">'+c.co+' · '+c.pop.toLocaleString('de-DE')+' Einw.'+(inf?' · '+inf:'')+'</div></div><div class="sr-cost '+(G.money>=cost?'can':'cant')+'">🔓 '+fmt(cost)+'</div></div></div>';
  }).join('');
  sr._merged=merged;
}

function unlockCityM(idx){
  const data=sr._merged;if(!data||!data[idx])return;
  const c=data[idx];const cost=unlockCost(c.lat,c.lng,c.pop);
  if(G.money<cost){addLog('❌ '+fmt(cost)+' nötig');sr.classList.remove('open');si.value='';return}
  sr.classList.remove('open');si.value='';
  // Show custom confirm popup with map
  showUnlockPopup(c,cost,idx);
}

function showUnlockPopup(c,cost,idx){
  // Remove existing popup
  let existing=document.getElementById('unlockPopup');if(existing)existing.remove();
  const inf=infraText(c);
  const popup=document.createElement('div');popup.id='unlockPopup';popup.className='unlock-bg';
  popup.innerHTML='<div class="unlock-popup">'
    +'<div class="unlock-map" id="unlockMapSlot"></div>'
    +'<div class="unlock-body">'
    +'<div class="unlock-name">'+cSzIcon(c.pop)+' '+c.name+'</div>'
    +'<div class="unlock-info">'+cSz(c.pop)+' · '+c.pop.toLocaleString('de-DE')+' Einwohner</div>'
    +(inf?'<div class="unlock-info">'+inf+'</div>':'')
    +'<div class="unlock-info" style="margin-top:2px">'+c.co+' · '+c.lat.toFixed(2)+'°, '+c.lng.toFixed(2)+'°</div>'
    +'<div class="unlock-cost">🔓 '+fmt(cost)+'</div>'
    +'<div class="unlock-btns">'
    +'<button class="btn full" id="unlockConfirmBtn">Freischalten</button>'
    +'<button class="btn red full" id="unlockCancelBtn">Abbrechen</button>'
    +'</div></div></div>';
  document.body.appendChild(popup);

  // Create mini map in popup
  let uMap=null;
  setTimeout(()=>{
    try{
      uMap=L.map('unlockMapSlot',{zoomControl:false,attributionControl:false,dragging:false,scrollWheelZoom:false,doubleClickZoom:false,touchZoom:false}).setView([c.lat,c.lng],8);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',{maxZoom:19,subdomains:'abcd'}).addTo(uMap);
      L.marker([c.lat,c.lng],{icon:L.divIcon({className:'',iconSize:[24,32],iconAnchor:[12,32],html:'<div style="font-size:28px;filter:drop-shadow(0 2px 6px rgba(0,0,0,.7))">📍</div>'})}).addTo(uMap);
      setTimeout(()=>uMap.invalidateSize(),100);
    }catch(e){}
  },50);

  // Confirm
  document.getElementById('unlockConfirmBtn').onclick=()=>{
    G.money-=cost;
    const city={...c};
    city.id=(c.id||c.name.toLowerCase().replace(/[^a-z0-9]/g,''))+'_'+uid().substr(1,4);
    delete city._nom;delete city._s;
    cities.push(city);G.unlockedCities.push(city);addCityMap(city);
    addLog('🔓 '+city.name+' – '+fmt(cost));
    if(uMap){try{uMap.remove()}catch(e){}}
    popup.remove();
    sel(city.id);updCnt();ua();
  };
  // Cancel
  document.getElementById('unlockCancelBtn').onclick=()=>{
    if(uMap){try{uMap.remove()}catch(e){}}
    popup.remove();
  };
  // Click outside closes
  popup.addEventListener('click',e=>{if(e.target===popup){if(uMap){try{uMap.remove()}catch(e2){}}popup.remove()}});
}

// ── Nominatim ──
async function nomSearch(q,target){
  try{
    // Check cache first
    const cached=typeof getCachedSearch==='function'?getCachedSearch(q):null;
    let results;
    if(cached){
      results=cached;
    } else {
      const url='https://nominatim.openstreetmap.org/search?format=json&limit=10&addressdetails=1&accept-language=de&q='+encodeURIComponent(q);
      const r=await fetch(url);if(!r.ok)return;
      const data=await r.json();if(!data||!data.length)return;
      results=data.filter(d=>{
        const n=(d.display_name||'').split(',')[0].toLowerCase();
        if(d.class==='boundary'&&d.type==='administrative'&&!d.address?.village&&!d.address?.town&&!d.address?.hamlet&&!d.address?.city)return false;
        if(/^landkreis |^kreis |^regierungsbezirk /i.test(n))return false;
        return true;
      }).map(d=>{
        const name=d.address?.village||d.address?.hamlet||d.address?.town||d.address?.city||d.address?.municipality||d.name||d.display_name.split(',')[0];
        const co=(d.address?.country_code||'').toUpperCase();
        let pop=0;
        if(d.population)pop=parseInt(d.population);
        else{
          const seed=Math.abs(Math.sin(parseFloat(d.lat)*1234.5+parseFloat(d.lon)*6789.1));
          const s=seed-Math.floor(seed);
          if(d.address?.hamlet||d.type==='hamlet'||d.type==='isolated_dwelling')pop=Math.floor(50+s*500);
          else if(d.address?.village||d.type==='village'||d.type==='suburb')pop=Math.floor(300+s*3500);
          else if(d.address?.town||d.type==='town')pop=Math.floor(5000+s*35000);
          else if(d.address?.city||d.type==='city')pop=Math.floor(80000+s*400000);
          else pop=Math.floor(150+s*2000);
        }
        return{name,co,pop,lat:parseFloat(d.lat),lng:parseFloat(d.lon),harbor:0,airport:0,rail:pop>50000?1:0,id:name.toLowerCase().replace(/[^a-z0-9]/g,''),_nom:true};
      });
      // Save to cache
      if(typeof setCachedSearch==='function')setCachedSearch(q,results);
    }
    if(target==='start'){
      const local=(startRes._d||[]).filter(x=>!x._nom);
      renderStartResults(local,results);
      startRes._d=dedupMerge(local,results);
    } else {
      renderGameResults(sr._local||[],results);
      sr._merged=dedupMerge(sr._local||[],results);
    }
  }catch(e){/* silent */}
}
