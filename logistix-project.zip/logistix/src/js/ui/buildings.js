function compBuildings(el){if(!G.sel&&cities.length)G.sel=cities[0].id;const c=G.sel?C(G.sel):null;if(!c){el.innerHTML=tabHead('buildings','🏭 Gebäude','')+'<div class="sub" style="padding:20px;text-align:center">Standort wählen</div>';return}
  const bs=G.blds[c.id]||[],maxB=mxB(c.pop),lvl=playerLvl(),reg=getRegion(c.co),regInfo=REGIONS[reg];
  const cCap2=cityCap(c.id);const stor2=G.stor[c.id]||{},storTot2=Object.values(stor2).reduce((s2,v)=>s2+v,0);
  if(!G.infra)G.infra={};
  let h='';
  // Header
  h+='<div class="ch"><div class="ci">🏭</div><div><div class="cn">'+c.name+'</div>';
  h+='<div class="cm">'+bs.length+'/'+maxB+' · 📦 '+storTot2+'/'+cCap2+(regInfo?' · <span style="color:'+regInfo.color+'">'+regInfo.em+' '+regInfo.name+'</span>':'')+'</div></div></div>';
  h+='<div class="pb" style="margin-bottom:6px"><div class="pf" style="width:'+Math.min(100,cCap2?storTot2/cCap2*100:0)+'%"></div></div>';
  // Sub-tab bar (styled like main tabs)
  h+='<div class="bld-tabs">';
  [['build','<i class="ri-hammer-line"></i> Bauen'],['manage','<i class="ri-settings-3-line"></i> Verwalten'+(bs.length?' ('+bs.length+')':'')],['infra','<i class="ri-building-line"></i> Infrastruktur']].forEach(([st,label])=>{
    h+='<button class="bld-tab'+(bldSub===st?' on':'')+'" onclick="bldSub=\''+st+'\';renComp()">'+label+'</button>'});
  h+='</div>';

  // ── SUB: MANAGE ──
  if(bldSub==='manage'){
    if(bs.length){bs.forEach(b=>{h+='<div class="crd" style="margin-bottom:6px">'+renderBldDetail(b,c.id,true)+'</div>'});}
    else h+='<div class="sub" style="padding:12px;text-align:center">Noch keine Gebäude. Wechsel zu 🏗️ Bauen!</div>';
  }

  // ── SUB: BUILD ──
  if(bldSub==='build'){
    if(bs.length<maxB){
      const available=Object.entries(BLD).filter(([k])=>canBuildInCity(k,c.id));
      if(available.length){h+='<div class="sec-label">Verfügbar (Level '+lvl+')</div><div class="bgr">';
        available.forEach(([k,d])=>{h+='<div class="bb '+(G.money<d.price?'off':'')+'" onclick="bld(\''+c.id+'\',\''+k+'\')"><div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub">'+d.desc+'</div><div class="p">'+fmt(d.price)+'</div></div>'});
        h+='</div>'}
      // Locked groups
      const lockedLvlHere=Object.entries(BLD).filter(([k,d])=>d.lvl>lvl&&(!d.region||d.region.includes(reg)));
      const lockedLvlOther=Object.entries(BLD).filter(([k,d])=>d.lvl>lvl&&d.region&&!d.region.includes(reg));
      const lockedRegionOnly=Object.entries(BLD).filter(([k,d])=>d.lvl<=lvl&&d.region&&!d.region.includes(reg));
      if(lockedLvlHere.length){const byLvl={};lockedLvlHere.forEach(([k,d])=>{const l=d.lvl;if(!byLvl[l])byLvl[l]=[];byLvl[l].push([k,d])});
        Object.entries(byLvl).sort((a,b)=>a[0]-b[0]).forEach(([l,items])=>{const li=LEVELS[l-1];
          h+='<div class="sec-label" style="opacity:.6">🔒 Ab Level '+l+' – '+li.em+' '+li.name+'</div><div class="bgr">';
          items.forEach(([k,d])=>{h+='<div class="bb off" style="opacity:.4"><div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub" style="color:var(--td)">'+d.desc+'</div><div class="p" style="opacity:.5">'+fmt(d.price)+'</div></div>'});
          h+='</div>'});}
      if(lockedLvlOther.length){const byLvl2={};lockedLvlOther.forEach(([k,d])=>{const l=d.lvl;if(!byLvl2[l])byLvl2[l]=[];byLvl2[l].push([k,d])});
        Object.entries(byLvl2).sort((a,b)=>a[0]-b[0]).forEach(([l,items])=>{const li=LEVELS[l-1];
          h+='<div class="sec-label" style="opacity:.4">🔒 Level '+l+' · andere Region</div><div class="bgr">';
          items.forEach(([k,d])=>{h+='<div class="bb off" style="opacity:.25"><div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub" style="color:var(--td)">'+d.desc+'<br>📍 '+d.region.map(r=>(REGIONS[r]?.em||'')+' '+REGIONS[r]?.name).join(', ')+' · Ab Lvl '+d.lvl+'</div></div>'});
          h+='</div>'});}
      if(lockedRegionOnly.length){h+='<div class="sec-label" style="opacity:.5">🌍 In dieser Region nicht verfügbar</div><div class="bgr">';
        lockedRegionOnly.forEach(([k,d])=>{h+='<div class="bb off" style="opacity:.3"><div class="e">'+d.em+'</div><div>'+d.name+'</div><div class="sub" style="color:var(--td)">'+d.desc+'<br>✅ Level '+d.lvl+' · 📍 Nur in: '+d.region.map(r=>(REGIONS[r]?.em||'')+' '+REGIONS[r]?.name).join(', ')+'</div><div class="p" style="opacity:.5">'+fmt(d.price)+'</div></div>'});
        h+='</div>'}
    } else h+='<div class="sub" style="text-align:center;padding:12px">🏗️ Maximum erreicht ('+maxB+'/'+maxB+')</div>';
  }

  // ── SUB: INFRA ──
  if(bldSub==='infra'){
    const existing=G.infra[c.id]||[];const inf=infraText(c);
    // Storage section
    const hasLagerUpg=existing.find(x=>x.type==='lager_upgrade');
    const bldLager=bs.filter(b=>b.type==='lagerhalle');
    const bldLagerCap=bldLager.reduce((s,b)=>{const d2=BLD[b.type];return s+(d2?d2.storCap*(1+(bUp(b,'lager_cap')||0)):0)},0);
    h+='<div class="crd"><div class="rw"><span>📦 Lagerkapazität</span><span style="font-family:var(--mono);font-weight:700;color:var(--a)">'+cCap2+'</span></div>';
    h+='<div class="sub" style="margin:4px 0">Basis: 100'+(hasLagerUpg?' + Lagererweiterung (+200)':'')+(bldLagerCap?' + Lagerhallen (+'+bldLagerCap+')':'')+'</div>';
    if(!hasLagerUpg){h+='<button class="btn sm'+(G.money<8000?' off':'')+'" onclick="buildInfra(\''+c.id+'\',\'lager_upgrade\')">📦 Lagererweiterung +200 · '+fmt(8000)+' (einmalig)</button>'}
    else{h+='<div class="sub" style="color:var(--a)">✅ Lagererweiterung aktiv</div>'}
    h+='<div class="sub" style="margin-top:4px;color:var(--td)">Mehr Kapazität? Lagerhalle unter 🏗️ Bauen (belegt Bauplatz, upgradbar bis +2.500)</div>';
    h+='</div>';
    // Anbindung
    h+='<div class="sub" style="margin:6px 0">'+(inf||'Keine natürliche Anbindung (Hafen/Flughafen)')+'</div>';
    // Built infra
    const builtOther=existing.filter(x=>{const d2=INFRA[x.type];return d2&&!d2.storCap});
    if(builtOther.length){h+='<div class="sec-label">Aktive Infrastruktur</div>';builtOther.forEach(i2=>{const d2=INFRA[i2.type];if(!d2)return;
      h+='<div class="crd"><div class="rw"><span>'+d2.em+' '+d2.name+'</span><span class="tg g">✅ Aktiv</span></div><div class="sub">'+d2.effect+'</div></div>'})}
    // Available
    const availOther=Object.entries(INFRA).filter(([k,d2])=>!d2.storCap&&!existing.find(x=>x.type===k));
    if(availOther.length){h+='<div class="sec-label">Verfügbar</div>';
      availOther.forEach(([k,d2])=>{
        const blocked=(d2.req==='airport'&&!c.airport)||(d2.req==='harbor'&&!c.harbor);const dis=blocked||G.money<d2.price;
        h+='<div class="crd'+(dis?' off':'')+'" onclick="'+(blocked?'':'buildInfra(\''+c.id+'\',\''+k+'\')')+'" style="cursor:'+(blocked?'default':'pointer')+'">';
        h+='<div class="rw"><span>'+d2.em+' '+d2.name+'</span><span class="p">'+fmt(d2.price)+'</span></div>';
        if(blocked)h+='<div class="sub" style="color:var(--r)">Benötigt '+(d2.req==='airport'?'Flughafen':'Hafen')+'-Standort</div>';
        else h+='<div class="sub">'+d2.desc+'</div>';h+='</div>'});}
  }

  // Close city (always visible at bottom)
  if(cities.length>1){h+='<div style="margin-top:16px;padding-top:10px;border-top:1px solid var(--bd)"><button class="btn red full" onclick="sellCity(\''+c.id+'\')">🏙️ Standort schließen (30% Erstattung)</button></div>'}
  el.innerHTML=h}

// ═══ BUILDING DETAIL ═══
function renderBldDetail(b,cid,showUpgrades){const d=BLD[b.type];if(!d)return'';if(!b.ups)b.ups={};if(!b.localStor)b.localStor={};
  const tracks=BLD_UPGRADES[b.type]||[];const lCap=bldLocalCap(b),lTot=Object.values(b.localStor).reduce((a,v)=>a+v,0);
  let h='<div style="padding:4px 0">';
  h+='<div class="rw"><span>'+d.em+' '+d.name+'</span><div style="display:flex;gap:3px">';
  if(d.tp!=='s'){const isStop=b.overflow==='stop';h+='<button class="btn sm" onclick="toggleOverflow(\''+cid+'\',\''+b.id+'\')" style="'+(isStop?'color:var(--r)':'')+'">'+( isStop?'⛔ Stop':'📦 Überlauf')+'</button>'}
  h+='<button class="btn red sm" onclick="if(confirm(\'Abreißen?\'))demolishBld(\''+cid+'\',\''+b.id+'\')">🔨</button>';
  h+='</div></div>';
  // Storage building info
  if(d.tp==='s'&&d.storCap){
    const lvlU=bUp(b,'lager_cap')||0;const totalS=d.storCap*(1+lvlU);
    h+='<div class="sub">📦 Stadtlager +'+totalS+(lvlU?' (Stufe '+(lvlU+1)+'/5)':' (upgradbar)')+'</div>';
    // Show upgrades for storage
    if(showUpgrades&&tracks.length){h+='<div style="margin-top:4px;padding-top:4px;border-top:1px solid var(--bd)">';
      tracks.forEach(track=>{const ud=UPGRADES[track],ulvl=bUp(b,track),mx=ud.max,cost=ulvl<mx?upCost(track,ulvl):0;
        h+='<div class="up-row"><span class="up-icon">'+ud.em+'</span><span class="up-name">'+ud.name+'</span><span class="up-pips">';
        for(let i=0;i<mx;i++)h+='<span class="pip'+(i<ulvl?' on':'')+'"></span>';
        h+='</span>';if(ulvl<mx)h+='<button class="btn sm'+(G.money<cost?' off':'')+'" onclick="upgBld(\''+cid+'\',\''+b.id+'\',\''+track+'\')">'+fmt(cost)+'</button>';
        else h+='<span class="tg g">MAX</span>';h+='</div>'});
      h+='</div>';}
    h+='</div>';return h}
  // Production info with speed
  if(d.tp==='p'){const interval=bldTickInterval(b);h+='<div class="sub">'+bldOutput(b)+'× '+(GOODS[d.prod]?.name||'')+' alle '+ftime(interval)+(d.inp?' (braucht '+bldInput(b)+'× '+(GOODS[d.inp]?.name||'')+')'  :'')+'</div>'}
  else if(d.tp==='farm'){const interval=bldTickInterval(b);h+='<div class="sub">'+bldOutput(b)+'× '+(GOODS[d.prod]?.name||'Getreide')+' alle '+ftime(interval)+'</div>'}
  
  // Recipe
  if(d.tp==='recipe'&&d.recipes&&RECIPES[d.recipes]){const pool=RECIPES[d.recipes];const interval=bldTickInterval(b);
    const active=(b.activeRecipes||[b.recipe].filter(Boolean)).filter(rid=>pool.find(r=>r.id===rid));
    const split=Math.max(1,active.length);
    const pct=Math.round(100/split);
    h+='<div style="margin:4px 0;padding-top:4px;border-top:1px solid var(--bd)">';
    h+='<div class="rw"><span class="sub" style="font-weight:600">Rezepte (Zyklus: '+ftime(interval)+')</span><span class="sub">'+active.length+'/'+pool.length+' aktiv'+(split>1?' · je '+pct+'%':'')+'</span></div>';
    pool.forEach(r=>{const isOn=active.includes(r.id);
      const effM=[1,.8,.65,.5];const eff=effM[bUp(b,'fac_eff')]||1;
      const outMult=bUp(b,'fac_out')+1;
      const realOut=isOn?Math.max(1,Math.round(r.outR*outMult/split)):r.outR*outMult;
      const realIn1=isOn?Math.max(1,Math.ceil(r.in1N*eff/split)):Math.max(1,Math.ceil(r.in1N*eff));
      const realIn2=r.in2?(isOn?Math.max(1,Math.ceil(r.in2N*eff/split)):Math.max(1,Math.ceil(r.in2N*eff))):0;
      h+='<label class="veh-check" style="border-color:'+(isOn?'var(--a)':'var(--bd)')+'"><input type="checkbox" '+(isOn?'checked':'')+' onchange="toggleRecipe(\''+cid+'\',\''+b.id+'\',\''+r.id+'\')"/>';
      h+='<span style="flex:1">'+(GOODS[r.out]?.em||'')+' <b>'+r.name+'</b>'+(isOn&&split>1?' <span style="color:var(--go);font-size:9px">'+pct+'%</span>':'');
      h+='<span class="sub" style="display:block;margin-top:1px">→ '+realOut+'× '+(GOODS[r.out]?.name||'')+' ← '+realIn1+'× '+(GOODS[r.in1]?.name||'')+(r.in2?' + '+realIn2+'× '+(GOODS[r.in2]?.name||''):'')+'</span></span></label>'});
    h+='</div>'}
  // Gebäudekapazität
  if(d.localCap){h+='<div style="display:flex;align-items:center;gap:4px;margin:3px 0;font-size:14px;color:var(--td)">';
    h+='<span>Gebäudekapazität: '+lTot+'/'+lCap+'</span><div class="pb" style="width:40px;margin:0"><div class="pf" style="width:'+Math.min(100,lCap?lTot/lCap*100:0)+'%"></div></div>';
    if(lTot>0)h+='<button class="btn sm" onclick="collectLocalStor(\''+cid+'\',\''+b.id+'\')">→ Stadtlager</button>';h+='</div>';
    const lItems=Object.entries(b.localStor).filter(([,a])=>a>0);
    if(lItems.length)h+='<div style="font-size:10px;color:var(--td)">'+lItems.map(([g,a])=>(GOODS[g]?.em||'')+' '+(GOODS[g]?.name||'')+': '+a).join(', ')+'</div>'}
  // Animals
  if(d.tp==='farm'){const animals=b.animals||{};const interval=bldTickInterval(b);const totalA=Object.values(animals).reduce((s2,v)=>s2+v,0);
    h+='<div style="margin-top:4px;padding-top:4px;border-top:1px solid var(--bd)">';
    h+='<div class="rw"><span class="sub" style="font-weight:600">Tierhaltung'+(totalA?' · '+totalA+' Tiere':'')+'</span><span class="sub">Zyklus: '+ftime(interval)+'</span></div>';
    if(totalA){Object.entries(animals).filter(([,c2])=>c2>0).forEach(([aKey,cnt])=>{const a=ANIMALS[aKey];if(!a)return;
      h+='<div class="crd" style="padding:4px 8px;margin:3px 0"><div class="rw"><span style="font-size:11px">'+a.em+' '+a.name+' ×'+cnt+'</span>';
      h+='<button class="btn red sm" onclick="sellAnimal(\''+cid+'\',\''+b.id+'\',\''+aKey+'\')">−1 ('+fmt(Math.floor(a.price*0.4))+')</button></div>';
      h+='<div class="sub">Produziert alle '+ftime(interval)+': '+a.produces.map(p=>{const amt=p.rate*cnt*(bUp(b,'prod_out')+1);return(GOODS[p.good]?.em||'')+' '+(GOODS[p.good]?.name||'')+' ×'+amt}).join(', ')+'</div></div>'})}
    h+='<div style="display:flex;gap:3px;margin-top:4px;flex-wrap:wrap">';
    Object.entries(ANIMALS).forEach(([aKey,a])=>{
      const locked=a.lvl&&a.lvl>playerLvl();
      if(locked){h+='<button class="btn sm off" style="opacity:.3" title="Level '+a.lvl+' benötigt">'+a.em+' 🔒 Lvl '+a.lvl+'</button>';return}
      h+='<button class="btn sm'+(G.money<a.price?' off':'')+'" onclick="buyAnimal(\''+cid+'\',\''+b.id+'\',\''+aKey+'\')" title="Produziert: '+a.produces.map(p=>(GOODS[p.good]?.name||'')).join(', ')+'">'+a.em+' '+a.name+' · '+fmt(a.price)+'</button>'});
    h+='</div></div>'}

  if(d.tp==='orchard'){const fruits=b.fruits||{};const interval=bldTickInterval(b);const totalF=Object.values(fruits).reduce((s2,v)=>s2+v,0);
    h+='<div style="margin-top:4px;padding-top:4px;border-top:1px solid var(--bd)">';
    h+='<div class="rw"><span class="sub" style="font-weight:600">Obstanbau'+(totalF?' · '+totalF+' Sorten':'')+'</span><span class="sub">Zyklus: '+ftime(interval)+'</span></div>';
    if(totalF){Object.entries(fruits).filter(([,c2])=>c2>0).forEach(([fKey,cnt])=>{const fr=FRUITS[fKey];if(!fr)return;
      const amt=d.rate*cnt*(bUp(b,'prod_out')+1);
      h+='<div class="crd" style="padding:4px 8px;margin:3px 0"><div class="rw"><span style="font-size:11px">'+fr.em+' '+fr.name+' ×'+cnt+'</span>';
      h+='<button class="btn red sm" onclick="sellFruit(\''+cid+'\',\''+b.id+'\',\''+fKey+'\')">−1 ('+fmt(Math.floor(fr.price*0.4))+')</button></div>';
      h+='<div class="sub">→ '+(GOODS[fr.good]?.em||'')+' '+(GOODS[fr.good]?.name||'')+' ×'+amt+' alle '+ftime(interval)+'</div></div>'})}
    h+='<div style="display:flex;gap:3px;margin-top:4px;flex-wrap:wrap">';
    Object.entries(FRUITS).forEach(([fKey,fr])=>{
      const locked=fr.lvl&&fr.lvl>playerLvl();
      if(locked){h+='<button class="btn sm off" style="opacity:.3" title="Level '+fr.lvl+' benötigt">'+fr.em+' 🔒 Lvl '+fr.lvl+'</button>';return}
      h+='<button class="btn sm'+(G.money<fr.price?' off':'')+'" onclick="buyFruit(\''+cid+'\',\''+b.id+'\',\''+fKey+'\')" title="Produziert: '+(GOODS[fr.good]?.name||'')+'">'+fr.em+' '+fr.name+' · '+fmt(fr.price)+'</button>'});
    h+='</div></div>'}
  // Upgrades
  if(showUpgrades&&tracks.length){h+='<div style="margin-top:4px;padding-top:4px;border-top:1px solid var(--bd)">';
    tracks.forEach(track=>{const ud=UPGRADES[track],lvl=bUp(b,track),mx=ud.max,cost=lvl<mx?upCost(track,lvl):0;
      h+='<div class="up-row"><span class="up-icon">'+ud.em+'</span><span class="up-name">'+ud.name+'</span><span class="up-pips">';
      for(let i=0;i<mx;i++)h+='<span class="up-pip'+(i<lvl?' on':'')+'"></span>';h+='</span>';
      if(lvl<mx)h+='<button class="btn sm'+(G.money>=cost?'':' off')+'" onclick="upgBld(\''+cid+'\',\''+b.id+'\',\''+track+'\')">'+fmt(cost)+'</button>';
      else h+='<span class="tg g">MAX</span>';h+='</div>'});h+='</div>'}
  h+='</div>';return h}

// ═══ INFRA ═══
function compInfra(el){if(!G.infra)G.infra={};const c=G.sel?C(G.sel):null;if(!c){el.innerHTML=tabHead('infra','🏢 Infrastruktur','')+'<div class="sub" style="padding:20px;text-align:center">Standort wählen</div>';return}
  const existing=G.infra[c.id]||[],inf=infraText(c);let h=tabHead('infra','🏢 Infrastruktur','Lager · Anbindung · Logistik');
  h+='<div class="ch"><div class="ci">🏢</div><div><div class="cn">'+c.name+'</div><div class="cm">'+(inf||'Keine natürliche Anbindung')+'</div></div></div>';

  // Storage section at top
  const cCap2=cityCap(c.id);const stor2=G.stor[c.id]||{};const storTot2=Object.values(stor2).reduce((a,v)=>a+v,0);
  const smallCount=existing.filter(x=>x.type==='kleines_lager').length;
  const bigCount=existing.filter(x=>x.type==='grosses_lager').length;
  h+='<div class="crd"><div class="rw"><span>📦 Stadtlager</span><span style="font-family:var(--mono);font-weight:700;color:var(--a)">'+storTot2+' / '+cCap2+'</span></div>';
  h+='<div class="pb" style="margin:4px 0"><div class="pf" style="width:'+Math.min(100,cCap2?storTot2/cCap2*100:0)+'%"></div></div>';
  h+='<div class="sub">Basis: 100'+(smallCount?' + '+smallCount+'× Kleines Lager (+'+smallCount*200+')':'')+(bigCount?' + '+bigCount+'× Großes Lager (+'+bigCount*800+')':'')+'</div>';
  h+='<div style="display:flex;gap:4px;margin-top:6px">';
  h+='<button class="btn sm'+(G.money<6000?' off':'')+'" onclick="buildInfra(\''+c.id+'\',\'kleines_lager\')">📦 +200 Lager · '+fmt(6000)+'</button>';
  h+='<button class="btn sm'+(G.money<25000?' off':'')+'" onclick="buildInfra(\''+c.id+'\',\'grosses_lager\')">🏭 +800 Lager · '+fmt(25000)+'</button>';
  h+='</div></div>';

  // Depot section
  const hasDepot=existing.find(x=>x.type==='depot');
  const dCap=depotCap(c.id);const vHere=G.vehs.filter(v=>(v.depot||v.loc)===c.id).length;
  const dCost=depotUpgradeCost(c.id);
  const depotLvl=hasDepot?(hasDepot.depotLvl||0):0;
  h+='<div class="crd"><div class="rw"><span>🏢 Fahrzeug-Depot</span>';
  if(hasDepot)h+='<span style="font-family:var(--mono);font-weight:700;color:var(--a)">'+vHere+' / '+dCap+'</span>';
  else h+='<span class="sub">Nicht gebaut</span>';
  h+='</div>';
  if(hasDepot){
    h+='<div class="pb" style="margin:4px 0"><div class="pf" style="width:'+Math.min(100,dCap?vHere/dCap*100:0)+'%;background:'+(vHere>=dCap?'var(--r)':'var(--a)')+'"></div></div>';
    h+='<div class="sub">Basis: 3 Plätze'+(depotLvl?' + '+depotLvl+'× Ausbau (+'+depotLvl*2+')':'')+' = '+dCap+' Stellplätze</div>';
    if(dCost){const canAff=G.money>=dCost;
      h+='<button class="btn sm" style="margin-top:4px;'+(canAff?'':'color:var(--r);border-color:rgba(248,113,113,.3);opacity:.7')+'" onclick="'+(canAff?"upgradeDepot('"+c.id+"')":"addLog('❌ Nicht genug Geld');if(typeof toast==='function')toast('❌ '+fmt("+dCost+")+'€ benötigt','var(--r)')")+'">🏢 Depot ausbauen → '+(dCap+2)+' Plätze · '+fmt(dCost)+'</button>';
    } else h+='<div class="sub" style="color:var(--a);margin-top:3px">✅ Maximal ausgebaut (5/5 Upgrades)</div>';
  } else {
    const canAffD=G.money>=15000;
    h+='<div class="sub" style="margin-top:3px">Ohne Depot: max. 2 Fahrzeuge. Mit Depot: 3 + ausbaubar bis 13.</div>';
    h+='<button class="btn sm" style="margin-top:4px;'+(canAffD?'':'color:var(--r);border-color:rgba(248,113,113,.3);opacity:.7')+'" onclick="'+(canAffD?"buildInfra('"+c.id+"','depot')":"addLog('❌ Nicht genug Geld')")+'">🏢 Depot bauen · '+fmt(15000)+' → 3 Stellplätze</button>';
  }
  h+='</div>';

  // Built infra (non-storage, non-depot)
  const builtOther=existing.filter(x=>{const d2=INFRA[x.type];return d2&&!d2.storCap&&x.type!=='depot'});
  if(builtOther.length){h+='<div class="sec-label">Gebaut</div>';builtOther.forEach(i2=>{const d2=INFRA[i2.type];if(!d2)return;
    h+='<div class="crd"><div class="rw"><span>'+d2.em+' '+d2.name+'</span><span class="tg g">✅ Aktiv</span></div><div class="sub">'+d2.effect+'</div></div>'})}

  // Available infra (non-storage, non-stacking, non-depot)
  const availOther=Object.entries(INFRA).filter(([k,d2])=>!d2.storCap&&k!=='depot'&&!existing.find(x=>x.type===k));
  if(availOther.length){h+='<div class="sec-label">Verfügbar</div>';
    availOther.forEach(([k,d2])=>{
      const blocked=(d2.req==='airport'&&!c.airport)||(d2.req==='harbor'&&!c.harbor);const dis=blocked||G.money<d2.price;
      h+='<div class="crd'+(dis?' off':'')+'" onclick="'+(blocked?'':'buildInfra(\''+c.id+'\',\''+k+'\')')+'" style="cursor:'+(blocked?'default':'pointer')+'">';
      h+='<div class="rw"><span>'+d2.em+' '+d2.name+'</span><span class="p">'+fmt(d2.price)+'</span></div>';
      if(blocked)h+='<div class="sub" style="color:var(--r)">Benötigt '+(d2.req==='airport'?'Flughafen':'Hafen')+'-Standort</div>';
      else h+='<div class="sub">'+d2.desc+'</div>';h+='</div>'});}
  el.innerHTML=h}

function utabs(){}

