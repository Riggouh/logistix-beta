// ══════════════════════════════════════════
// INIT
// ══════════════════════════════════════════

function launchGame(sc){
  document.getElementById('startScreen').style.display='none';
  document.getElementById('gameScreen').style.display='block';
  try{initMap()}catch(e){console.error('initMap error:',e)}
  try{cities.forEach(c=>addCityMap(c))}catch(e){console.error('addCityMap error:',e)}
  gameStarted=true;
  try{initQuests();refreshDailies();refreshWeeklies()}catch(e){console.error('quest init error:',e)}
  try{uhud()}catch(e){}
  try{applyView()}catch(e){console.error('applyView error:',e)}
  setTimeout(()=>{if(MP){MP.invalidateSize();MP.setView([sc.lat,sc.lng],10,{animate:false})}},300);
  try{uvmk()}catch(e){}try{udots()}catch(e){}
  if(G)try{Object.keys(G.blds).forEach(ubmk)}catch(e){}
  updCnt();
  if(!tickIv)tickIv=setInterval(tick,1000);
  setInterval(save,30000);
  setInterval(saveCache,120000); // Save cache every 2min
}

(async()=>{
  await loadCache();
  await loadAdminLog();
  await ensureTestAccount();
  document.getElementById('loginUser').disabled=false;
  window.addEventListener('beforeunload',()=>{save();saveCache()});
  setTimeout(()=>{const el=document.getElementById('loginUser');if(el)el.focus()},300);
  // Populate region info cards on start screen
  const rc=document.getElementById('regionCards');
  if(rc){
    const regionRes={
      europa:'🐟 Fisch · ⚫ Kohle · 🏭 Verarbeitung',
      asien:'🍚 Reis · 🍵 Tee · 🌶️ Gewürze · 🌿 Baumwolle · 🌳 Kautschuk',
      afrika:'🌿 Baumwolle · ☕ Kaffee · 🍫 Kakao · 🍵 Tee',
      suedamerika:'☕ Kaffee · 🍫 Kakao · 🎋 Zuckerrohr · 🌽 Mais · 🌳 Kautschuk',
      nordamerika:'🌽 Mais · 🐟 Fisch · ⚫ Kohle · 🛢️ Energie',
      ozeanien:'🐟 Fisch · ⚫ Kohle · 🚢 Seehandel',
    };
    let h='';Object.entries(REGIONS).forEach(([k,r])=>{
      h+='<div class="region-card" style="border-color:'+r.color+'30">';
      h+='<div class="rc-head" style="color:'+r.color+'">'+r.em+' '+r.name+'</div>';
      h+='<div class="rc-tip">'+(regionRes[k]||'')+'</div></div>';
    });rc.innerHTML=h;
  }
})();
