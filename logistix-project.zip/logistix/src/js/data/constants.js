// ══════════════════════════════════════════
// GAME CONSTANTS v5 – Levels + Regional goods
// ══════════════════════════════════════════

// ═══ ICON SYSTEM: Remix Icon mapping for all game elements ═══
const RI={
  // Vehicles
  kleintransporter:'ri-truck-line',lieferwagen:'ri-caravan-line',lkw75:'ri-truck-fill',kuehlwagen:'ri-fridge-line',
  sattelzug:'ri-bus-2-line',tankwagen:'ri-gas-station-line',gueterzug:'ri-train-line',schnellzug:'ri-train-fill',
  kuestenfrachter:'ri-ship-line',containerschiff:'ri-ship-fill',propeller:'ri-flight-takeoff-line',frachtjet:'ri-plane-fill',
  cargojet:'ri-plane-line',doppelstock:'ri-truck-fill',schwertransporter:'ri-truck-fill',superfrachter:'ri-ship-fill',megatransporter:'ri-rocket-line',
  // Buildings
  lagerhalle:'ri-box-3-line',grosse_lagerhalle:'ri-box-3-fill',
  bauernhof:'ri-plant-line',forstwirtschaft:'ri-leaf-line',obstplantage:'ri-seedling-line',
  muehle:'ri-settings-3-line',saftpresse:'ri-cup-line',molkerei:'ri-drop-line',
  baeckerei:'ri-cake-line',schreinerei:'ri-hammer-line',mine:'ri-hammer-fill',
  metzgerei:'ri-knife-line',pastafabrik:'ri-restaurant-line',schneiderei:'ri-scissors-line',
  weinkellerei:'ri-goblet-line',zuckerfabrik:'ri-sugar-line',roesterei:'ri-cup-fill',
  gummifabrik:'ri-circle-line',oelquelle:'ri-drop-fill',stahlwerk:'ri-hammer-fill',
  konservenfabrik:'ri-archive-line',seifenfabrik:'ri-bubble-chart-line',parfuemerie:'ri-flask-line',
  pizzeria:'ri-restaurant-fill',elektronikfabrik:'ri-cpu-line',schokoladenfabrik:'ri-cake-fill',
  pharmafabrik:'ri-capsule-line',destillerie:'ri-goblet-fill',
  brauerei:'ri-goblet-line',glasfabrik:'ri-wineglass-line',keramikwerk:'ri-artboard-line',
  konditorei:'ri-cake-2-line',juwelier:'ri-vip-diamond-line',uhrmacher:'ri-time-line',
  textilfaerberei:'ri-palette-line',automobilwerk:'ri-roadster-line',chipfabrik:'ri-cpu-fill',
  biotech:'ri-microscope-line',raumfahrt:'ri-rocket-fill',
  // Regional farms
  baumwollfarm:'ri-leaf-fill',kaffeeplantage:'ri-cup-fill',kakaoplantage:'ri-seedling-fill',
  zuckerrohrfarm:'ri-plant-fill',teeplantage:'ri-cup-line',kautschukplantage:'ri-circle-fill',
  reisfarm:'ri-plant-line',maisfarm:'ri-seedling-line',fischerei:'ri-anchor-line',kohlegrube:'ri-fire-line',
  // Goods categories
  getreide:'ri-leaf-line',holz:'ri-leaf-fill',eier:'ri-circle-line',honig:'ri-drop-line',
  milch:'ri-drop-fill',wolle:'ri-shirt-line',mehl:'ri-stack-line',
  obst_apfel:'ri-apple-line',obst_traube:'ri-seedling-line',obst_orange:'ri-circle-line',
  moebel:'ri-home-line',stahl:'ri-shield-line',oel:'ri-drop-fill',elektronik:'ri-cpu-line',
  textilien:'ri-shirt-fill',bier:'ri-goblet-line',glas:'ri-wineglass-line',schmuck:'ri-vip-diamond-line',
  autos:'ri-roadster-line',chips:'ri-cpu-fill',
  // Infra
  lager_upgrade:'ri-box-3-line',depot:'ri-building-line',bahnhof:'ri-train-line',
  flughafen:'ri-plane-line',hafen:'ri-anchor-line',logistikzentrum:'ri-box-3-fill',tankstelle:'ri-gas-station-line',
};
const RI_CLR={land:'green',rail:'blue',sea:'purple',air:'gold',
  p:'green',farm:'green',orchard:'green',recipe:'blue',s:'purple'};
function gIco(key,fallback,size){
  const ic=RI[key];const sz=size||'';
  if(ic)return'<div class="ico '+(sz?sz+' ':'')+(RI_CLR[fallback]||'slate')+'"><i class="'+ic+'"></i></div>';
  return'<div class="ico '+(sz?sz+' ':'')+'slate">'+(fallback||'?')+'</div>';
}

const VT={
  kleintransporter:{name:"3,5t Transporter",em:"🚐",cat:"land",spd:90,cap:4,price:6000,mt:30,lvl:1},
  lieferwagen:{name:"Lieferwagen 5t",em:"🚙",cat:"land",spd:85,cap:8,price:12000,mt:50,lvl:2},
  lkw75:{name:"7,5t LKW",em:"🚛",cat:"land",spd:80,cap:12,price:18000,mt:70,lvl:3},
  kuehlwagen:{name:"Kühltransporter",em:"🧊",cat:"land",spd:78,cap:15,price:28000,mt:100,lvl:4},
  sattelzug:{name:"Sattelzug 40t",em:"🚚",cat:"land",spd:75,cap:35,price:45000,mt:150,lvl:5},
  tankwagen:{name:"Tankwagen",em:"🛢️",cat:"land",spd:70,cap:45,price:60000,mt:180,lvl:6},
  gueterzug:{name:"Güterzug",em:"🚆",cat:"rail",spd:120,cap:60,price:120000,mt:400,lvl:7},
  kuestenfrachter:{name:"Küstenfrachter",em:"🚢",cat:"sea",spd:25,cap:150,price:200000,mt:800,lvl:8},
  propeller:{name:"Propellermaschine",em:"🛩️",cat:"air",spd:450,cap:8,price:300000,mt:1200,lvl:8},
  frachtjet:{name:"Frachtjet",em:"✈️",cat:"air",spd:850,cap:25,price:1500000,mt:4000,lvl:9},
  containerschiff:{name:"Containerschiff",em:"🛳️",cat:"sea",spd:18,cap:800,price:800000,mt:2500,lvl:10},
  schnellzug:{name:"ICE-Güterzug",em:"🚄",cat:"rail",spd:200,cap:40,price:350000,mt:600,lvl:11},
  doppelstock:{name:"Doppelstock-LKW",em:"🚛",cat:"land",spd:72,cap:55,price:180000,mt:300,lvl:12},
  schwertransporter:{name:"Schwertransporter",em:"🚛",cat:"land",spd:60,cap:80,price:250000,mt:500,lvl:13},
  superfrachter:{name:"Superfrachter",em:"🛳️",cat:"sea",spd:22,cap:2000,price:3000000,mt:6000,lvl:14},
  cargojet:{name:"Cargo-Großraumjet",em:"🛫",cat:"air",spd:900,cap:60,price:5000000,mt:8000,lvl:14},
  megatransporter:{name:"Megatransporter",em:"🚀",cat:"land",spd:65,cap:120,price:8000000,mt:10000,lvl:15},
};
const VEH_CATS={land:"🚛 Landfahrzeuge",rail:"🚆 Schienenverkehr",sea:"🚢 Seefahrt",air:"✈️ Luftfracht"};
const WAGON_UPGRADE={name:"Güterwagon",em:"🚃",max:5,baseCost:25000,capPerLevel:30};

// ═══ PLAYER LEVELS (15 Stufen) ═══
const LEVELS=[
  {lvl:1,name:'Gründer',em:'🌱',dels:0,value:0,cities:1,cost:0,
   desc:'Bauernhof, Forstwirtschaft, Hühner, Bienen, Transporter'},
  {lvl:2,name:'Landwirt',em:'🌾',dels:3,value:30000,cities:2,cost:3000,
   desc:'Obstplantage, Schweine, Schafe, Mühle, Lieferwagen'},
  {lvl:3,name:'Unternehmer',em:'📈',dels:8,value:80000,cities:3,cost:8000,
   desc:'Saftpresse, Marmelade, 7,5t LKW'},
  {lvl:4,name:'Geschäftsführer',em:'🏢',dels:18,value:200000,cities:4,cost:20000,
   desc:'Kühe, Molkerei, Bäckerei, Schreinerei, Kühltransporter'},
  {lvl:5,name:'Industrieller',em:'🏗️',dels:30,value:400000,cities:5,cost:40000,
   desc:'Erzmine, Metzgerei, Pastafabrik, Sattelzug'},
  {lvl:6,name:'Direktor',em:'🎩',dels:50,value:750000,cities:6,cost:75000,
   desc:'Regionale Rohstoffe, Schneiderei, Weinkellerei, Tankwagen'},
  {lvl:7,name:'Manager',em:'💼',dels:80,value:1500000,cities:8,cost:150000,
   desc:'Zuckerfabrik, Rösterei, Gummifabrik, Konservenfabrik, Güterzug'},
  {lvl:8,name:'Mogul',em:'💎',dels:120,value:3000000,cities:10,cost:300000,
   desc:'Ölförderung, Stahlwerk, Seifenfabrik, Küstenfrachter, Propeller'},
  {lvl:9,name:'Magnat',em:'🏆',dels:180,value:6000000,cities:13,cost:600000,
   desc:'Elektronik, Pizzeria, Schokoladenfabrik, Parfümerie, Frachtjet'},
  {lvl:10,name:'Tycoon',em:'👑',dels:300,value:15000000,cities:16,cost:1500000,
   desc:'Pharma, Destillerie, Containerschiff'},
  {lvl:11,name:'Großindustrieller',em:'🌟',dels:450,value:25000000,cities:18,cost:2500000,
   desc:'Brauerei, Glasfabrik, Keramikwerk, Konditerei'},
  {lvl:12,name:'Baron',em:'🏰',dels:600,value:50000000,cities:22,cost:5000000,
   desc:'Juwelier, Uhrmacher, Textilfärberei'},
  {lvl:13,name:'Imperator',em:'⭐',dels:800,value:100000000,cities:28,cost:10000000,
   desc:'Automobilwerk, Chipfabrik, Schwertransporter'},
  {lvl:14,name:'Visionär',em:'🔱',dels:1100,value:200000000,cities:35,cost:25000000,
   desc:'Raumfahrtzulieferer, Biotech-Labor, Superfrachter'},
  {lvl:15,name:'Legende',em:'🌌',dels:1500,value:500000000,cities:50,cost:50000000,
   desc:'Globale Dominanz, alle Industrien freigeschaltet'},
];
function playerLvl(){return G?G.level||1:1}
function canLevelUp(){
  if(!G)return null;
  const cur=playerLvl();if(cur>=LEVELS.length)return null;
  const next=LEVELS[cur]; // 0-indexed: cur=1 → LEVELS[1] is lvl 2
  if(G.dels<next.dels)return{blocked:true,reason:'Lieferungen: '+G.dels+'/'+next.dels};
  if(companyValue()<next.value)return{blocked:true,reason:'Unternehmenswert: '+fmt(companyValue())+'/'+fmt(next.value)};
  if(cities.length<next.cities)return{blocked:true,reason:'Standorte: '+cities.length+'/'+next.cities};
  if(G.money<next.cost)return{blocked:true,reason:'Geld: '+fmt(G.money)+'/'+fmt(next.cost)};
  return{blocked:false,next};
}
function doLevelUp(){
  const r=canLevelUp();if(!r||r.blocked)return;
  G.money-=r.next.cost;G.level=r.next.lvl;
  addLog('⭐ Level '+r.next.lvl+': '+r.next.em+' '+r.next.name+'!');
  markDirty();ua();
}

// ═══ REGION SYSTEM ═══
function getRegion(co){
  const map={
    europa:['DE','AT','CH','FR','IT','ES','PT','GB','IE','NL','BE','LU','PL','CZ','SK','HU','RO','BG','HR','SI','BA','RS','ME','MK','AL','GR','TR','NO','SE','FI','DK','IS','EE','LV','LT','BY','UA','MD','RU','MT','CY','XK','LI','MC','AD','SM','VA'],
    asien:['CN','JP','KR','IN','ID','TH','VN','PH','MY','SG','MM','KH','LA','BD','PK','LK','NP','BT','MN','KZ','UZ','TM','TJ','KG','AF','IR','IQ','SY','JO','LB','IL','PS','SA','AE','QA','BH','KW','OM','YE','TW','HK','MO','BN'],
    nordamerika:['US','CA','MX','GT','BZ','HN','SV','NI','CR','PA','CU','JM','HT','DO','TT','BS','BB','PR'],
    suedamerika:['BR','AR','CL','CO','PE','VE','EC','BO','PY','UY','GY','SR','GF'],
    afrika:['ZA','EG','NG','KE','ET','GH','TZ','MA','TN','DZ','LY','SD','UG','CM','SN','CI','MZ','MG','AO','ZW','ZM','CD','ML','BF','NE','TD','SS','RW','BI','BW','NA','MW','LS','SZ','MU','SC','DJ','ER','SO','GA','CG','CF','GQ','GM','GN','GW','LR','SL','TG','BJ','CV','ST','KM','MR'],
    ozeanien:['AU','NZ','PG','FJ','WS','TO','VU','SB','KI','MH','FM','PW','NR','TV','NC','PF','GU']
  };
  for(const[r,codes]of Object.entries(map)){if(codes.includes(co))return r}
  return'europa';
}
const REGIONS={
  europa:{name:'Europa',em:'🇪🇺',color:'#4da6ff'},
  asien:{name:'Asien',em:'🌏',color:'#ff6b9d'},
  afrika:{name:'Afrika',em:'🌍',color:'#ffb942'},
  suedamerika:{name:'Südamerika',em:'🌎',color:'#00e5a0'},
  nordamerika:{name:'Nordamerika',em:'🇺🇸',color:'#c084fc'},
  ozeanien:{name:'Ozeanien',em:'🏝️',color:'#06b6d4'},
};

// ═══ GOODS – with tier for ordering ═══
const GOODS={
  // ─── GLOBAL RAW (Tier 0) ───
  getreide:{name:"Getreide",em:"🌾",bp:60,cat:"roh",tier:0},
  holz:{name:"Holz",em:"🪵",bp:70,cat:"roh",tier:0},
  // ─── GLOBAL ANIMAL (Tier 0) ───
  eier:{name:"Eier",em:"🥚",bp:65,cat:"tier",tier:0},
  honig:{name:"Honig",em:"🍯",bp:100,cat:"tier",tier:0},
  huehnchen:{name:"Hähnchen",em:"🍗",bp:120,cat:"tier",tier:0},
  // ─── LVL 2: Fruits + more animals ───
  obst_apfel:{name:"Äpfel",em:"🍎",bp:80,cat:"roh",tier:0},obst_traube:{name:"Trauben",em:"🍇",bp:100,cat:"roh",tier:0},
  obst_orange:{name:"Orangen",em:"🍊",bp:90,cat:"roh",tier:0},obst_kirsche:{name:"Kirschen",em:"🍒",bp:110,cat:"roh",tier:0},
  milch:{name:"Milch",em:"🥛",bp:80,cat:"tier",tier:0},wolle:{name:"Wolle",em:"🧶",bp:95,cat:"tier",tier:0},
  schweinefleisch:{name:"Schweinefleisch",em:"🥩",bp:150,cat:"tier",tier:0},
  // ─── LVL 3: Advanced animals ───
  rindfleisch:{name:"Rindfleisch",em:"🥩",bp:200,cat:"tier",tier:0},
  // ─── BASIC PROCESSED (Tier 1) ───
  mehl:{name:"Mehl",em:"🌾",bp:110,cat:"ver",tier:1},
  butter:{name:"Butter",em:"🧈",bp:160,cat:"ver",tier:1},
  saft:{name:"Fruchtsaft",em:"🧃",bp:150,cat:"ver",tier:1},
  marmelade:{name:"Marmelade",em:"🍯",bp:170,cat:"ver",tier:1},
  // ─── ADVANCED PROCESSED (Tier 2) ───
  kaese:{name:"Käse",em:"🧀",bp:250,cat:"ver",tier:2},
  backwaren:{name:"Backwaren",em:"🥐",bp:230,cat:"ver",tier:2},
  moebel:{name:"Möbel",em:"🪑",bp:320,cat:"ver",tier:2},
  // ─── LVL 4: Industrial + regional ───
  erz:{name:"Erz",em:"⛏️",bp:170,cat:"roh",tier:0},
  nudeln:{name:"Nudeln",em:"🍝",bp:270,cat:"ver",tier:2},
  wurstwaren:{name:"Wurstwaren",em:"🌭",bp:310,cat:"ver",tier:2},
  textilien:{name:"Textilien",em:"👕",bp:350,cat:"ver",tier:2},
  // ─── REGIONAL RAW (Tier 0, region-locked) ───
  baumwolle:{name:"Baumwolle",em:"🌿",bp:130,cat:"roh",tier:0,region:['afrika','asien']},
  kaffee:{name:"Kaffee",em:"☕",bp:200,cat:"roh",tier:0,region:['suedamerika','afrika']},
  kakao:{name:"Kakao",em:"🍫",bp:220,cat:"roh",tier:0,region:['suedamerika','afrika']},
  zuckerrohr:{name:"Zuckerrohr",em:"🎋",bp:100,cat:"roh",tier:0,region:['suedamerika','asien']},
  reis:{name:"Reis",em:"🍚",bp:75,cat:"roh",tier:0,region:['asien','afrika']},
  tee:{name:"Tee",em:"🍵",bp:160,cat:"roh",tier:0,region:['asien','afrika']},
  gewuerze:{name:"Gewürze",em:"🌶️",bp:180,cat:"roh",tier:0,region:['asien','suedamerika']},
  mais:{name:"Mais",em:"🌽",bp:65,cat:"roh",tier:0,region:['nordamerika','suedamerika']},
  kautschuk:{name:"Kautschuk",em:"🌳",bp:190,cat:"roh",tier:0,region:['suedamerika','asien']},
  fisch:{name:"Fisch",em:"🐟",bp:110,cat:"roh",tier:0,region:['ozeanien','nordamerika','europa']},
  kohle:{name:"Kohle",em:"⚫",bp:140,cat:"roh",tier:0,region:['ozeanien','europa','nordamerika']},
  // ─── LVL 5: Heavy industry ───
  oel:{name:"Öl",em:"🛢️",bp:280,cat:"roh",tier:0},
  stahl:{name:"Stahl",em:"🔩",bp:370,cat:"ver",tier:2},
  wein:{name:"Wein",em:"🍷",bp:380,cat:"ver",tier:2},
  // ─── REGIONAL PROCESSED ───
  schokolade:{name:"Schokolade",em:"🍫",bp:400,cat:"ver",tier:2,region:['europa','suedamerika']},
  roestkaffee:{name:"Röstkaffee",em:"☕",bp:420,cat:"ver",tier:2},
  zucker:{name:"Zucker",em:"🍬",bp:180,cat:"ver",tier:1},
  gummi:{name:"Gummi",em:"🔴",bp:350,cat:"ver",tier:2},
  // ─── LVL 6: High-tech & Luxury ───
  pizza:{name:"Pizza",em:"🍕",bp:400,cat:"ver",tier:3},
  elektronik:{name:"Elektronik",em:"💻",bp:900,cat:"ver",tier:3},
  // ─── LVL 9-10: Advanced & Luxury ───
  seife:{name:"Seife",em:"🧴",bp:300,cat:"ver",tier:2},
  kosmetik:{name:"Kosmetik",em:"💄",bp:600,cat:"ver",tier:3},
  medikamente:{name:"Medikamente",em:"💊",bp:1200,cat:"ver",tier:3},
  parfuem:{name:"Parfüm",em:"🌸",bp:800,cat:"ver",tier:3},
  tiefkuehlkost:{name:"Tiefkühlkost",em:"🧊",bp:350,cat:"ver",tier:2},
  konserven:{name:"Konserven",em:"🥫",bp:280,cat:"ver",tier:2},
  spirituosen:{name:"Spirituosen",em:"🥃",bp:500,cat:"ver",tier:3},
  // ─── LVL 11: Brauerei, Glas, Keramik ───
  bier:{name:"Bier",em:"🍺",bp:350,cat:"ver",tier:2},
  glas:{name:"Glas",em:"🪟",bp:300,cat:"ver",tier:2},
  keramik:{name:"Keramik",em:"🏺",bp:320,cat:"ver",tier:2},
  torte:{name:"Torte",em:"🎂",bp:450,cat:"ver",tier:3},
  // ─── LVL 12: Luxus ───
  schmuck:{name:"Schmuck",em:"💍",bp:1500,cat:"lux",tier:3},
  uhren:{name:"Uhren",em:"⌚",bp:1800,cat:"lux",tier:3},
  edelsteine:{name:"Edelsteine",em:"💎",bp:900,cat:"roh",tier:0},
  seide:{name:"Seide",em:"🧣",bp:600,cat:"ver",tier:2,region:['asien']},
  // ─── LVL 13: Industrie 4.0 ───
  autos:{name:"Automobile",em:"🚗",bp:3500,cat:"ind",tier:4},
  chips:{name:"Mikrochips",em:"🔬",bp:2800,cat:"ind",tier:4},
  kunststoff:{name:"Kunststoff",em:"🧪",bp:400,cat:"ver",tier:2},
  reifen:{name:"Reifen",em:"⚫",bp:500,cat:"ver",tier:2},
  // ─── LVL 14: Hightech ───
  satelliten:{name:"Satellitenteile",em:"🛰️",bp:5000,cat:"ind",tier:4},
  biotech:{name:"Biotech-Produkte",em:"🧬",bp:4000,cat:"ind",tier:4},
  // ─── LVL 15: Endgame ───
  luxusautos:{name:"Luxusautos",em:"🏎️",bp:8000,cat:"lux",tier:4},
  supercomputer:{name:"Supercomputer",em:"🖥️",bp:7000,cat:"ind",tier:4},
};

const ANIMALS={
  huehner:{name:"Hühner",em:"🐔",price:1200,produces:[{good:"eier",rate:2},{good:"huehnchen",rate:1}],lvl:1},
  bienen:{name:"Bienen",em:"🐝",price:1000,produces:[{good:"honig",rate:2}],lvl:1},
  schweine:{name:"Schweine",em:"🐷",price:2500,produces:[{good:"schweinefleisch",rate:1}],lvl:2},
  schafe:{name:"Schafe",em:"🐑",price:2000,produces:[{good:"wolle",rate:2}],lvl:2},
  kuehe:{name:"Kühe",em:"🐄",price:4000,produces:[{good:"milch",rate:2},{good:"rindfleisch",rate:1}],lvl:4},
};

const FRUITS={
  apfel:{name:"Äpfel",em:"🍎",good:"obst_apfel",price:700,lvl:2},
  traube:{name:"Trauben",em:"🍇",good:"obst_traube",price:1000,lvl:2},
  orange:{name:"Orangen",em:"🍊",good:"obst_orange",price:900,lvl:3},
  kirsche:{name:"Kirschen",em:"🍒",good:"obst_kirsche",price:1300,lvl:3},
};

const RECIPES={
  muehle:[
    {id:'mehl',name:'Mehl',out:'mehl',outR:3,in1:'getreide',in1N:4,in2:null,in2N:0},
  ],
  saftpresse:[
    {id:'saft',name:'Fruchtsaft',out:'saft',outR:2,in1:'obst_apfel',in1N:4,in2:null,in2N:0},
    {id:'marmelade',name:'Marmelade',out:'marmelade',outR:1,in1:'obst_kirsche',in1N:4,in2:null,in2N:0},
  ],
  molkerei:[
    {id:'kaese',name:'Käse',out:'kaese',outR:1,in1:'milch',in1N:6,in2:null,in2N:0},
    {id:'butter',name:'Butter',out:'butter',outR:1,in1:'milch',in1N:4,in2:null,in2N:0},
  ],
  baeckerei:[
    {id:'brot',name:'Backwaren',out:'backwaren',outR:1,in1:'mehl',in1N:4,in2:'eier',in2N:2},
  ],
  pastafabrik:[
    {id:'nudeln',name:'Nudeln',out:'nudeln',outR:1,in1:'mehl',in1N:5,in2:'eier',in2N:3},
  ],
  metzgerei:[
    {id:'wurst',name:'Wurstwaren',out:'wurstwaren',outR:1,in1:'schweinefleisch',in1N:3,in2:'rindfleisch',in2N:2},
  ],
  weinkellerei:[
    {id:'wein',name:'Wein',out:'wein',outR:1,in1:'obst_traube',in1N:6,in2:null,in2N:0},
  ],
  pizzeria:[
    {id:'pizza',name:'Pizza',out:'pizza',outR:1,in1:'mehl',in1N:4,in2:'kaese',in2N:3},
  ],
  zuckerfabrik:[
    {id:'zucker',name:'Zucker',out:'zucker',outR:2,in1:'zuckerrohr',in1N:5,in2:null,in2N:0},
  ],
  roesterei:[
    {id:'roestkaffee',name:'Röstkaffee',out:'roestkaffee',outR:2,in1:'kaffee',in1N:2,in2:null,in2N:0},
  ],
  schokoladenfabrik:[
    {id:'schokolade',name:'Schokolade',out:'schokolade',outR:1,in1:'kakao',in1N:5,in2:'zucker',in2N:3},
  ],
  gummifabrik:[
    {id:'gummi',name:'Gummi',out:'gummi',outR:2,in1:'kautschuk',in1N:3,in2:null,in2N:0},
  ],
  konservenfabrik:[
    {id:'konserven',name:'Konserven',out:'konserven',outR:2,in1:'fisch',in1N:3,in2:null,in2N:0},
    {id:'tiefkuehl',name:'Tiefkühlkost',out:'tiefkuehlkost',outR:1,in1:'schweinefleisch',in1N:2,in2:'obst_apfel',in2N:2},
  ],
  seifenfabrik:[
    {id:'seife',name:'Seife',out:'seife',outR:2,in1:'oel',in1N:2,in2:'honig',in2N:1},
  ],
  parfuemerie:[
    {id:'parfuem',name:'Parfüm',out:'parfuem',outR:1,in1:'obst_orange',in1N:4,in2:'honig',in2N:2},
    {id:'kosmetik',name:'Kosmetik',out:'kosmetik',outR:1,in1:'seife',in1N:2,in2:'obst_kirsche',in2N:3},
  ],
  pharmafabrik:[
    {id:'medikamente',name:'Medikamente',out:'medikamente',outR:1,in1:'kohle',in1N:3,in2:'honig',in2N:4},
  ],
  destillerie:[
    {id:'spirituosen',name:'Spirituosen',out:'spirituosen',outR:1,in1:'obst_traube',in1N:5,in2:'zucker',in2N:3},
  ],
  brauerei:[
    {id:'bier',name:'Bier',out:'bier',outR:2,in1:'getreide',in1N:5,in2:'honig',in2N:1},
  ],
  glasfabrik:[
    {id:'glas',name:'Glas',out:'glas',outR:2,in1:'kohle',in1N:3,in2:'erz',in2N:2},
  ],
  keramikwerk:[
    {id:'keramik',name:'Keramik',out:'keramik',outR:2,in1:'kohle',in1N:2,in2:null,in2N:0},
  ],
  konditerei:[
    {id:'torte',name:'Torte',out:'torte',outR:1,in1:'mehl',in1N:4,in2:'zucker',in2N:3},
  ],
  juwelier:[
    {id:'schmuck',name:'Schmuck',out:'schmuck',outR:1,in1:'edelsteine',in1N:3,in2:'stahl',in2N:2},
  ],
  uhrmacher:[
    {id:'uhren',name:'Uhren',out:'uhren',outR:1,in1:'stahl',in1N:4,in2:'glas',in2N:2},
  ],
  kunststofffabrik:[
    {id:'kunststoff',name:'Kunststoff',out:'kunststoff',outR:2,in1:'oel',in1N:3,in2:null,in2N:0},
  ],
  reifenwerk:[
    {id:'reifen',name:'Reifen',out:'reifen',outR:2,in1:'gummi',in1N:3,in2:'stahl',in2N:1},
  ],
  automobilwerk:[
    {id:'autos',name:'Automobile',out:'autos',outR:1,in1:'stahl',in1N:6,in2:'reifen',in2N:4},
  ],
  chipfabrik:[
    {id:'chips',name:'Mikrochips',out:'chips',outR:1,in1:'elektronik',in1N:3,in2:'glas',in2N:2},
  ],
  raumfahrt:[
    {id:'satelliten',name:'Satellitenteile',out:'satelliten',outR:1,in1:'chips',in1N:4,in2:'stahl',in2N:5},
  ],
  biotechlabor:[
    {id:'biotech',name:'Biotech-Produkte',out:'biotech',outR:1,in1:'medikamente',in1N:3,in2:'elektronik',in2N:2},
  ],
  luxusautofabrik:[
    {id:'luxusautos',name:'Luxusautos',out:'luxusautos',outR:1,in1:'autos',in1N:2,in2:'elektronik',in2N:3},
  ],
  supercomputerfabrik:[
    {id:'supercomputer',name:'Supercomputer',out:'supercomputer',outR:1,in1:'chips',in1N:5,in2:'stahl',in2N:3},
  ],
};

// ═══ BUILDINGS with level requirements and optional region lock ═══
const BLD={
  // Storage buildings
  lagerhalle:{name:"Lagerhalle",em:"📦",price:10000,tp:"s",desc:"Stadtlager +300, upgradbar",localCap:0,lvl:1,storCap:300},
  grosse_lagerhalle:{name:"Große Lagerhalle",em:"🏭",price:35000,tp:"s",desc:"Stadtlager +800, upgradbar bis +4000",localCap:0,lvl:4,storCap:800},
  // LVL 1 – Basics
  bauernhof:{name:"Bauernhof",em:"🌾",price:8000,tp:"farm",prod:"getreide",rate:2,inp:null,inpN:0,desc:"Getreide + Tiere",localCap:60,baseTick:50,lvl:1},
  forstwirtschaft:{name:"Forstwirtschaft",em:"🌲",price:6000,tp:"p",prod:"holz",rate:2,inp:null,inpN:0,desc:"Holz",localCap:60,baseTick:45,lvl:1},
  // LVL 2 – Fruits, basic processing
  obstplantage:{name:"Obstplantage",em:"🍎",price:10000,tp:"orchard",prod:null,rate:2,inp:null,inpN:0,desc:"Obst (wählbar)",localCap:50,baseTick:30,lvl:2},
  muehle:{name:"Mühle",em:"🌾",price:14000,tp:"recipe",recipes:'muehle',desc:"Getreide → Mehl",localCap:60,baseTick:65,lvl:2},
  saftpresse:{name:"Saftpresse",em:"🧃",price:13000,tp:"recipe",recipes:'saftpresse',desc:"Obst → Saft/Marmelade",localCap:50,baseTick:60,lvl:3},
  // LVL 3 – Advanced processing
  molkerei:{name:"Molkerei",em:"🧀",price:22000,tp:"recipe",recipes:'molkerei',desc:"Milch → Käse/Butter",localCap:50,baseTick:80,lvl:4},
  baeckerei:{name:"Bäckerei",em:"🥖",price:24000,tp:"recipe",recipes:'baeckerei',desc:"Mehl+Eier → Backwaren",localCap:50,baseTick:90,lvl:4},
  schreinerei:{name:"Schreinerei",em:"🪑",price:18000,tp:"p",prod:"moebel",rate:1,inp:"holz",inpN:6,desc:"Holz → Möbel",localCap:50,baseTick:90,lvl:4},
  // LVL 4 – Industry, regional, meat
  mine:{name:"Erzmine",em:"⛏️",price:22000,tp:"p",prod:"erz",rate:1,inp:null,inpN:0,desc:"Erz",localCap:50,baseTick:60,lvl:5},
  metzgerei:{name:"Metzgerei",em:"🥩",price:28000,tp:"recipe",recipes:'metzgerei',desc:"Fleisch → Wurstwaren",localCap:50,baseTick:100,lvl:5},
  pastafabrik:{name:"Pastafabrik",em:"🍝",price:30000,tp:"recipe",recipes:'pastafabrik',desc:"Mehl+Eier → Nudeln",localCap:50,baseTick:95,lvl:5},
  schneiderei:{name:"Schneiderei",em:"🧵",price:30000,tp:"p",prod:"textilien",rate:1,inp:"baumwolle",inpN:5,desc:"Baumwolle → Textilien",localCap:50,baseTick:100,lvl:6},
  // Regional LVL 4
  baumwollfarm:{name:"Baumwollfarm",em:"🌿",price:16000,tp:"p",prod:"baumwolle",rate:2,inp:null,inpN:0,desc:"Baumwolle",localCap:60,baseTick:50,lvl:6,region:['afrika','asien']},
  kaffeeplantage:{name:"Kaffeeplantage",em:"☕",price:20000,tp:"p",prod:"kaffee",rate:2,inp:null,inpN:0,desc:"Kaffee",localCap:50,baseTick:55,lvl:6,region:['suedamerika','afrika']},
  kakaoplantage:{name:"Kakaoplantage",em:"🍫",price:22000,tp:"p",prod:"kakao",rate:2,inp:null,inpN:0,desc:"Kakao",localCap:50,baseTick:55,lvl:6,region:['suedamerika','afrika']},
  zuckerrohrfarm:{name:"Zuckerrohrfarm",em:"🎋",price:14000,tp:"p",prod:"zuckerrohr",rate:2,inp:null,inpN:0,desc:"Zuckerrohr",localCap:60,baseTick:50,lvl:6,region:['suedamerika','asien']},
  reisfarm:{name:"Reisfarm",em:"🍚",price:10000,tp:"p",prod:"reis",rate:2,inp:null,inpN:0,desc:"Reis",localCap:60,baseTick:50,lvl:6,region:['asien','afrika']},
  teeplantage:{name:"Teeplantage",em:"🍵",price:18000,tp:"p",prod:"tee",rate:2,inp:null,inpN:0,desc:"Tee",localCap:40,baseTick:35,lvl:6,region:['asien','afrika']},
  kautschukplantage:{name:"Kautschukplantage",em:"🌳",price:24000,tp:"p",prod:"kautschuk",rate:2,inp:null,inpN:0,desc:"Kautschuk",localCap:40,baseTick:45,lvl:6,region:['suedamerika','asien']},
  maisfarm:{name:"Maisfarm",em:"🌽",price:9000,tp:"p",prod:"mais",rate:2,inp:null,inpN:0,desc:"Mais",localCap:60,baseTick:50,lvl:6,region:['nordamerika','suedamerika']},
  fischerei:{name:"Fischerei",em:"🐟",price:15000,tp:"p",prod:"fisch",rate:3,inp:null,inpN:0,desc:"Fisch",localCap:40,baseTick:30,lvl:6,region:['ozeanien','nordamerika','europa']},
  kohlegrube:{name:"Kohlegrube",em:"⚫",price:20000,tp:"p",prod:"kohle",rate:2,inp:null,inpN:0,desc:"Kohle",localCap:40,baseTick:40,lvl:6,region:['ozeanien','europa','nordamerika']},
  // LVL 5 – Heavy industry
  oelquelle:{name:"Ölförderanlage",em:"🛢️",price:40000,tp:"p",prod:"oel",rate:1,inp:null,inpN:0,desc:"Öl",localCap:40,baseTick:75,lvl:8},
  stahlwerk:{name:"Stahlwerk",em:"🔨",price:48000,tp:"p",prod:"stahl",rate:1,inp:"erz",inpN:5,desc:"Erz → Stahl",localCap:40,baseTick:110,lvl:8},
  weinkellerei:{name:"Weinkellerei",em:"🍷",price:42000,tp:"recipe",recipes:'weinkellerei',desc:"Trauben → Wein",localCap:40,baseTick:90,lvl:6},
  zuckerfabrik:{name:"Zuckerfabrik",em:"🍬",price:20000,tp:"recipe",recipes:'zuckerfabrik',desc:"Zuckerrohr → Zucker",localCap:40,baseTick:45,lvl:7},
  roesterei:{name:"Rösterei",em:"☕",price:35000,tp:"recipe",recipes:'roesterei',desc:"Kaffee → Röstkaffee",localCap:40,baseTick:60,lvl:7},
  gummifabrik:{name:"Gummifabrik",em:"🔴",price:38000,tp:"recipe",recipes:'gummifabrik',desc:"Kautschuk → Gummi",localCap:40,baseTick:70,lvl:7},
  // LVL 6 – Luxury & High-tech
  pizzeria:{name:"Pizzeria",em:"🍕",price:45000,tp:"recipe",recipes:'pizzeria',desc:"Mehl+Käse → Pizza",localCap:40,baseTick:100,lvl:9},
  elektronikfabrik:{name:"Elektronikfabrik",em:"💻",price:90000,tp:"p",prod:"elektronik",rate:1,inp:"stahl",inpN:4,desc:"Stahl → Elektronik",localCap:40,baseTick:150,lvl:9},
  schokoladenfabrik:{name:"Schokoladenfabrik",em:"🍫",price:55000,tp:"recipe",recipes:'schokoladenfabrik',desc:"Kakao+Zucker → Schokolade",localCap:40,baseTick:85,lvl:9},
  // LVL 7 – Konservierung
  konservenfabrik:{name:"Konservenfabrik",em:"🥫",price:32000,tp:"recipe",recipes:'konservenfabrik',desc:"Fisch/Fleisch → Konserven/TK",localCap:40,baseTick:80,lvl:7},
  // LVL 8 – Chemie
  seifenfabrik:{name:"Seifenfabrik",em:"🧴",price:45000,tp:"recipe",recipes:'seifenfabrik',desc:"Öl+Honig → Seife",localCap:40,baseTick:90,lvl:8},
  // LVL 9 – Luxus
  parfuemerie:{name:"Parfümerie",em:"🌸",price:70000,tp:"recipe",recipes:'parfuemerie',desc:"Obst+Seife → Parfüm/Kosmetik",localCap:40,baseTick:110,lvl:9},
  // LVL 10 – High-End
  pharmafabrik:{name:"Pharmafabrik",em:"💊",price:120000,tp:"recipe",recipes:'pharmafabrik',desc:"Kohle+Honig → Medikamente",localCap:40,baseTick:130,lvl:10},
  destillerie:{name:"Destillerie",em:"🥃",price:80000,tp:"recipe",recipes:'destillerie',desc:"Trauben+Zucker → Spirituosen",localCap:40,baseTick:100,lvl:10},
  // LVL 11 – Brauerei, Glas, Keramik
  brauerei:{name:"Brauerei",em:"🍺",price:55000,tp:"recipe",recipes:'brauerei',desc:"Getreide+Honig → Bier",localCap:50,baseTick:80,lvl:11},
  glasfabrik:{name:"Glasfabrik",em:"🪟",price:60000,tp:"recipe",recipes:'glasfabrik',desc:"Kohle+Erz → Glas",localCap:40,baseTick:90,lvl:11},
  keramikwerk:{name:"Keramikwerk",em:"🏺",price:50000,tp:"recipe",recipes:'keramikwerk',desc:"Kohle → Keramik",localCap:40,baseTick:85,lvl:11},
  konditerei:{name:"Konditerei",em:"🎂",price:65000,tp:"recipe",recipes:'konditerei',desc:"Mehl+Zucker → Torte",localCap:40,baseTick:95,lvl:11},
  // LVL 12 – Luxus
  edelsteinmine:{name:"Edelsteinmine",em:"💎",price:100000,tp:"p",prod:"edelsteine",rate:1,inp:null,inpN:0,desc:"Edelsteine",localCap:30,baseTick:100,lvl:12},
  juwelier:{name:"Juwelier",em:"💍",price:130000,tp:"recipe",recipes:'juwelier',desc:"Edelsteine+Stahl → Schmuck",localCap:30,baseTick:120,lvl:12},
  uhrmacher:{name:"Uhrmacher",em:"⌚",price:140000,tp:"recipe",recipes:'uhrmacher',desc:"Stahl+Glas → Uhren",localCap:30,baseTick:130,lvl:12},
  seidenfarm:{name:"Seidenfarm",em:"🧣",price:45000,tp:"p",prod:"seide",rate:1,inp:null,inpN:0,desc:"Seide",localCap:30,baseTick:70,lvl:12,region:['asien']},
  // LVL 13 – Industrie 4.0
  kunststofffabrik:{name:"Kunststofffabrik",em:"🧪",price:70000,tp:"recipe",recipes:'kunststofffabrik',desc:"Öl → Kunststoff",localCap:40,baseTick:80,lvl:13},
  reifenwerk:{name:"Reifenwerk",em:"⚫",price:85000,tp:"recipe",recipes:'reifenwerk',desc:"Gummi+Stahl → Reifen",localCap:40,baseTick:90,lvl:13},
  automobilwerk:{name:"Automobilwerk",em:"🚗",price:200000,tp:"recipe",recipes:'automobilwerk',desc:"Stahl+Reifen → Automobile",localCap:30,baseTick:150,lvl:13},
  chipfabrik:{name:"Chipfabrik",em:"🔬",price:180000,tp:"recipe",recipes:'chipfabrik',desc:"Elektronik+Glas → Mikrochips",localCap:30,baseTick:140,lvl:13},
  // LVL 14 – Hightech
  raumfahrtzulieferer:{name:"Raumfahrtzulieferer",em:"🛰️",price:350000,tp:"recipe",recipes:'raumfahrt',desc:"Chips+Stahl → Satellitenteile",localCap:20,baseTick:180,lvl:14},
  biotechlabor:{name:"Biotech-Labor",em:"🧬",price:300000,tp:"recipe",recipes:'biotechlabor',desc:"Medikamente+Elektronik → Biotech",localCap:20,baseTick:160,lvl:14},
  // LVL 15 – Endgame
  luxusautofabrik:{name:"Luxusautofabrik",em:"🏎️",price:500000,tp:"recipe",recipes:'luxusautofabrik',desc:"Autos+Elektronik → Luxusautos",localCap:20,baseTick:200,lvl:15},
  supercomputerfabrik:{name:"Supercomputerfabrik",em:"🖥️",price:450000,tp:"recipe",recipes:'supercomputerfabrik',desc:"Chips+Stahl → Supercomputer",localCap:20,baseTick:190,lvl:15},
};

const UPGRADES={
  lager_cap:{name:"Kapazität",em:"📦",max:4,baseCost:10000,desc:l=>"Nächste Stufe: ×"+(l+2)+" Basiskapazität"},
  local_cap:{name:"Gebäudekapazität",em:"📦",max:3,baseCost:3000,desc:l=>"+"+(20*(l+1))+" Gebäudekapazität"},
  prod_out:{name:"Produktion",em:"📈",max:5,baseCost:6000,desc:l=>"×"+(l+2)+" Output"},
  prod_spd:{name:"Tempo",em:"⚡",max:3,baseCost:10000,desc:l=>"Zyklus beschleunigt"},
  fac_out:{name:"Produktion",em:"📈",max:5,baseCost:10000,desc:l=>"×"+(l+2)+" Output"},
  fac_spd:{name:"Tempo",em:"⚡",max:3,baseCost:15000,desc:l=>"Zyklus beschleunigt"},
  fac_eff:{name:"Effizienz",em:"♻️",max:3,baseCost:20000,desc:l=>{const p=[100,80,65,50];return p[l+1]+"% Input"}},
};

// Auto-generate BLD_UPGRADES
const BLD_UPGRADES={};
Object.entries(BLD).forEach(([k,d])=>{
  if(d.tp==='s')BLD_UPGRADES[k]=['lager_cap'];
  else if(d.tp==='p'&&d.inp)BLD_UPGRADES[k]=['fac_out','fac_spd','fac_eff','local_cap'];
  else if(d.tp==='recipe')BLD_UPGRADES[k]=['fac_out','fac_spd','fac_eff','local_cap'];
  else BLD_UPGRADES[k]=['prod_out','prod_spd','local_cap'];
});

function upCost(track,lvl){return UPGRADES[track].baseCost*(lvl+1)}
function bUp(b,track){return(b.ups&&b.ups[track])||0}
function bldOutput(b){const d=BLD[b.type];if(!d)return 0;if(d.tp==='recipe'){const r=getActiveRecipe(b);return r?(r.outR*(bUp(b,'fac_out')+1)):0}if(d.tp!=='p'&&d.tp!=='farm'&&d.tp!=='orchard')return 0;return d.rate*(bUp(b,d.inp?'fac_out':'prod_out')+1)}
function bldInput(b){const d=BLD[b.type];if(!d||!d.inp)return 0;const m=[1,.8,.65,.5];return Math.max(1,Math.ceil(d.inpN*(m[bUp(b,'fac_eff')]||1)))}
function bldTickInterval(b){const d=BLD[b.type];if(!d)return 60;const base=d.baseTick||60;const isFactory=d.tp==='p'||d.tp==='recipe';const m=[1,.75,.5,.35];return Math.max(8,Math.floor(base*(m[bUp(b,isFactory?'fac_spd':'prod_spd')]||1)))}
function bldCap(b){const d=BLD[b.type];if(!d||d.tp!=='s')return 0;return d.baseCap*(bUp(b,'lager_cap')+1)}
function bldLocalCap(b){const d=BLD[b.type];if(!d)return 0;return(d.localCap||10)+(bUp(b,'local_cap'))*20}
function vehCap(v){const vt=VT[v.type];if(!vt)return 0;let c=vt.cap;if(v.type==='gueterzug'&&v.wagons)c+=v.wagons*WAGON_UPGRADE.capPerLevel;return c}
function getActiveRecipe(b){if(!b.recipe)return null;const d=BLD[b.type];if(!d||!d.recipes)return null;const pool=RECIPES[d.recipes];return pool?pool.find(r=>r.id===b.recipe):null}

// Check if building can be built in city (region check)
function canBuildInCity(bldKey,cid){
  const d=BLD[bldKey];if(!d)return false;
  if(d.lvl&&d.lvl>playerLvl())return false;
  if(!d.region)return true;
  const c=C(cid);if(!c)return false;
  return d.region.includes(getRegion(c.co));
}

const TF=2700;const routeCache={};

const INFRA={
  lager_upgrade:{name:"Lagererweiterung",em:"📦",price:8000,desc:"Stadtlager +200 (einmalig)",req:null,effect:"+200 Lagerkapazität",storCap:200,stack:false},
  depot:{name:"Fahrzeug-Depot",em:"🏢",price:15000,desc:"Fahrzeugstellplätze (Basis 3, upgradbar)",req:null,effect:"Stellplätze für Fahrzeuge",depotCap:3,stack:false},
  bahnhof:{name:"Bahnhof",em:"🚉",price:35000,desc:"Ermöglicht Züge",req:null,effect:"Züge nutzbar"},
  flughafen:{name:"Flughafen",em:"✈️",price:200000,desc:"Ermöglicht Flüge",req:'airport',effect:"Flugzeuge nutzbar"},
  hafen:{name:"Hafen",em:"⚓",price:150000,desc:"Ermöglicht Schiffe",req:'harbor',effect:"Schiffe nutzbar"},
  logistikzentrum:{name:"Logistikzentrum",em:"📦",price:80000,desc:"Markt-Bonus +15%",req:null,effect:"+15% Marktpreise"},
  tankstelle:{name:"Tankstelle",em:"⛽",price:8000,desc:"Speed +10%",req:null,effect:"+10% Speed"},
};
// Depot capacity per city
function depotCap(cid){
  const inf=G.infra&&G.infra[cid]||[];
  const dep=inf.find(i=>i.type==='depot');
  if(!dep)return 2; // 2 without depot
  const lvl=dep.depotLvl||0;
  return 3+lvl*2; // 3,5,7,9,11,13
}
function depotUpgradeCost(cid){
  const inf=G.infra&&G.infra[cid]||[];
  const dep=inf.find(i=>i.type==='depot');
  if(!dep)return null;
  const lvl=dep.depotLvl||0;
  if(lvl>=5)return null;
  return 10000*(lvl+1);
}
function upgradeDepot(cid){
  if(!G)return;const inf=G.infra[cid]||[];const dep=inf.find(i=>i.type==='depot');
  if(!dep)return;const cost=depotUpgradeCost(cid);if(!cost||G.money<cost)return;
  G.money-=cost;dep.depotLvl=(dep.depotLvl||0)+1;
  addLog('🏢 Depot upgraded → '+(3+(dep.depotLvl)*2)+' Stellplätze');ua();
}

// ═══ REGIONAL MARKET: Dynamic prices per region ═══
const MARKET_REGIONS=['europa','nordamerika','suedamerika','asien','afrika','ozeanien'];
const BASE_PRICES={
  getreide:80,holz:120,eier:60,honig:100,milch:90,wolle:150,mehl:160,
  obst_apfel:70,obst_traube:90,obst_orange:85,obst_kirsche:110,
  schweinefleisch:200,rindfleisch:280,huehnchen:150,
  saft:180,marmelade:250,kaese:300,butter:220,brot:200,kuchen:350,
  moebel:500,stahl:400,oel:350,erz:180,kohle:150,
  elektronik:900,textilien:400,bier:280,glas:300,schokolade:450,
  wein:380,wurst:320,nudeln:260,pizza:400,
  seife:250,kosmetik:550,medikamente:1100,parfuem:750,
  tiefkuehlkost:300,konserven:230,spirituosen:480,
  gummi:200,zucker:140,kaffee_fertig:350,tee_fertig:300,
  reis:100,mais:90,baumwolle:130,kautschuk:180,kakao:160,
  fisch:170,gewuerze:220,
  schmuck:1200,uhren:1000,autos:3000,chips:2000,keramik:280,torte:380,
  kunststoff:250,reifen:350,edelsteine:600,
};
// Price multiplier per region (some goods more valuable in certain regions)
const REGION_DEMAND={
  europa:{elektronik:1.3,autos:1.2,moebel:1.1,bier:0.8,wein:1.2},
  nordamerika:{elektronik:1.2,autos:1.4,oel:0.7,stahl:1.1,chips:1.3},
  suedamerika:{kaffee_fertig:0.6,kakao:0.5,elektronik:1.5,medikamente:1.4},
  asien:{reis:0.6,elektronik:0.8,textilien:0.7,moebel:1.3,stahl:1.2},
  afrika:{elektronik:1.6,medikamente:1.5,textilien:1.3,getreide:1.2},
  ozeanien:{elektronik:1.3,wolle:0.6,stahl:1.2,medikamente:1.3},
};
function marketPrice(good,regionKey){
  const base=BASE_PRICES[good]||100;
  const regMult=REGION_DEMAND[regionKey]?.[good]||1;
  // 8h price cycle (28800 ticks) — prices shift each epoch
  const epoch=Math.floor((G?.tick||0)/28800);
  const seed=hashStr(good+epoch);
  const wave=(seed%200-100)/600; // ±16% per epoch
  // Supply/demand: recent deliveries lower price, scarcity raises it
  let sdMult=1;
  if(G&&G.supplyTrack){
    const delivered=G.supplyTrack[good]||0;
    // Compare to average supply across all goods
    const vals=Object.values(G.supplyTrack);
    const avg=vals.length?vals.reduce((s,v)=>s+v,0)/vals.length:0;
    if(avg>0){
      const ratio=delivered/avg; // >1 means oversupplied, <1 undersupplied
      sdMult=1+Math.max(-0.25,Math.min(0.25,(1-ratio)*0.3)); // ±25% max
    } else if(delivered>10){sdMult=0.9} // Some supply depression
  }
  return Math.round(base*regMult*(1+wave)*sdMult);
}
// Simple string hash for deterministic price waves
function hashStr(s){let h=0;for(let i=0;i<s.length;i++){h=((h<<5)-h)+s.charCodeAt(i);h|=0}return Math.abs(h)}

// ═══ EVENTS SYSTEM ═══
const EVENTS=[
  {id:'storm',name:'Sturmwarnung',desc:'Alle Schiffe fahren 50% langsamer',icon:'🌊',dur:25200,effect:{seaSpeed:0.5}},
  {id:'rail_strike',name:'Bahnstreik',desc:'Züge stehen still',icon:'🚆',dur:21600,effect:{railStop:true}},
  {id:'fuel_crisis',name:'Ölkrise',desc:'Alle Fahrzeuge 20% teurer in Wartung',icon:'⛽',dur:28800,effect:{mtMult:1.2}},
  {id:'boom_asia',name:'Asien-Boom',desc:'Exporte nach Asien bringen 30% mehr',icon:'📈',dur:32400,effect:{regionBonus:{asien:1.3}}},
  {id:'boom_eu',name:'EU-Konjunktur',desc:'Europa-Handel +25% Profit',icon:'📈',dur:32400,effect:{regionBonus:{europa:1.25}}},
  {id:'harvest',name:'Rekordernte',desc:'Alle Farmen produzieren doppelt',icon:'🌾',dur:28800,effect:{farmMult:2}},
  {id:'tech_rush',name:'Tech-Boom',desc:'Elektronik & Chips +40% Marktpreis',icon:'💻',dur:28800,effect:{goodBonus:{elektronik:1.4,chips:1.4}}},
  {id:'trade_deal',name:'Freihandelsabkommen',desc:'Alle Marktpreise +10%',icon:'🤝',dur:36000,effect:{globalMult:1.1}},
  {id:'recession',name:'Rezession',desc:'Alle Marktpreise -15%',icon:'📉',dur:25200,effect:{globalMult:0.85}},
  {id:'speed_bonus',name:'Freie Autobahn',desc:'Alle LKW +25% schneller',icon:'🛣️',dur:21600,effect:{landSpeed:1.25}},
];
function activeEvents(){return(G.events||[]).filter(e=>e.endTick>G.tick)}
function eventEffect(key){
  const evts=activeEvents();let val=null;
  evts.forEach(e=>{const def=EVENTS.find(x=>x.id===e.id);if(def&&def.effect[key]!==undefined)val=def.effect[key]});
  return val;
}

// ═══ EXPRESS ORDERS (time-limited, 3× reward) ═══
function genExpressOrder(){
  if(!G||cities.length<2)return;
  const fromC=cities[Math.floor(Math.random()*cities.length)];
  const stor=G.stor[fromC.id];if(!stor)return;
  const goods2=Object.entries(stor).filter(([,a])=>a>=3);if(!goods2.length)return;
  const [good,amt]=goods2[Math.floor(Math.random()*goods2.length)];
  const targets=cities.filter(c=>c.id!==fromC.id);if(!targets.length)return;
  const toC=targets[Math.floor(Math.random()*targets.length)];
  const dist=hav(fromC.lat,fromC.lng,toC.lat,toC.lng);
  const sendAmt=Math.min(amt,Math.max(3,Math.floor(amt*0.4)));
  const toReg=getRegion((toC.co||'').toUpperCase());
  const mktPrice=typeof marketPrice==='function'?marketPrice(good,toReg):(BASE_PRICES[good]||100);
  // Express pays 2× market (better than normal orders but not insane)
  const rew=Math.round(mktPrice*sendAmt*2);
  // Cap at 5% of company value to prevent doubling
  const maxRew=Math.max(20000,Math.round(companyValue()*0.05));
  const cappedRew=Math.min(rew,maxRew);
  const timeLimit=Math.max(60,Math.floor(dist/80*3.6+30));
  return{id:uid(),type:'express',from:fromC.id,to:toC.id,good,amt:sendAmt,rew:cappedRew,
    born:G.tick,tl:timeLimit,acc:false,shipped:0,delivered:0,num:G.orderNum=(G.orderNum||0)+1,
    pricePerUnit:Math.round(cappedRew/sendAmt),mktRef:mktPrice};
}

// City storage capacity: base 100 + infra storage + building storage (with upgrades)
function cityCap(cid){
  let cap=100;
  const inf=G.infra&&G.infra[cid]||[];
  inf.forEach(i=>{const d=INFRA[i.type];if(d&&d.storCap)cap+=d.storCap});
  const bs=G.blds&&G.blds[cid]||[];
  bs.forEach(b=>{const d=BLD[b.type];if(d&&d.storCap)cap+=d.storCap*(1+(bUp(b,'lager_cap')||0))});
  return cap;
}

function quickSend(fromCid,toCid,good,amt){
  if(!G)return;const s=G.stor[fromCid];if(!s||(s[good]||0)<amt)return addLog('❌ Nicht genug '+((GOODS[good]?.name)||good));
  const avl=G.vehs.filter(v=>v.st==='idle'&&v.loc===fromCid&&vehCap(v)>=amt&&canVehTravel(v,toCid));
  if(!avl.length)return addLog('❌ Kein passendes Fahrzeug in '+(C(fromCid)?.name||'?'));
  avl.sort((a,b)=>vehCap(a)-vehCap(b));const v=avl[0];
  const sendAmt=Math.min(amt,vehCap(v));
  s[good]-=sendAmt;if(s[good]<=0)delete s[good];
  v.st='moving';v.rt={from:fromCid,to:toCid};v.cargo={internal:true,good,amt:sendAmt};v.prog=0;
  if(typeof ensureRoute==='function')ensureRoute(v);
  addLog('📦 '+VT[v.type].em+' '+sendAmt+'× '+(GOODS[good]?.em||'')+' → '+(C(toCid)?.name||''));ua();
}
