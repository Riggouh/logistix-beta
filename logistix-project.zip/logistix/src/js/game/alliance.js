// ALLIANCE SYSTEM v3 — Country-based territories
const ALLIANCE_LEVELS=[
  {lvl:1,name:'Startup',maxMembers:10,slots:3,maxTerr:2},
  {lvl:2,name:'Genossenschaft',maxMembers:12,slots:3,maxTerr:4,cost:80000},
  {lvl:3,name:'Konsortium',maxMembers:14,slots:5,maxTerr:6,cost:250000},
  {lvl:4,name:'Kartell',maxMembers:16,slots:7,maxTerr:10,cost:600000},
  {lvl:5,name:'Konzern',maxMembers:18,slots:10,maxTerr:15,cost:1500000},
  {lvl:6,name:'Trust',maxMembers:20,slots:13,maxTerr:20,cost:3000000},
  {lvl:7,name:'Syndikat',maxMembers:24,slots:16,maxTerr:30,cost:6000000},
  {lvl:8,name:'Imperium',maxMembers:28,slots:20,maxTerr:40,cost:12000000},
  {lvl:9,name:'Weltmacht',maxMembers:35,slots:25,maxTerr:60,cost:25000000},
  {lvl:10,name:'Hegemonie',maxMembers:50,slots:30,maxTerr:100,cost:50000000},
];
// Countries with sub-regions (8 per major country)
const COUNTRIES={
  DE:{name:'Deutschland',em:'🇩🇪',cont:'europa',parts:['Nordwest','Nordost','West','Mitte','Ost','Südwest','Süd','Südost'],fee:3000},
  FR:{name:'Frankreich',em:'🇫🇷',cont:'europa',parts:['Norden','Île-de-France','Westen','Osten','Zentrum','Südwesten','Süden','Mittelmeer'],fee:3500},
  GB:{name:'Großbritannien',em:'🇬🇧',cont:'europa',parts:['London','Südengland','Midlands','Nordengland','Wales','Schottland','Nordirland','Ostengland'],fee:4000},
  IT:{name:'Italien',em:'🇮🇹',cont:'europa',parts:['Nordwest','Nordost','Zentrum','Latium','Kampanien','Süditalien','Sizilien','Sardinien'],fee:3000},
  ES:{name:'Spanien',em:'🇪🇸',cont:'europa',parts:['Katalonien','Madrid','Andalusien','Valencia','Baskenland','Galicien','Kastilien','Balearen'],fee:2800},
  PL:{name:'Polen',em:'🇵🇱',cont:'europa',parts:['Masowien','Schlesien','Großpolen','Kleinpolen','Pommern','Niederschlesien','Lodz','Karpatenvorland'],fee:2000},
  NL:{name:'Niederlande',em:'🇳🇱',cont:'europa',parts:['Noord-Holland','Zuid-Holland','Utrecht','Brabant','Gelderland','Limburg','Friesland','Overijssel'],fee:3500},
  AT:{name:'Österreich',em:'🇦🇹',cont:'europa',parts:['Wien','Niederösterreich','Oberösterreich','Steiermark','Tirol','Salzburg','Kärnten','Vorarlberg'],fee:2500},
  CH:{name:'Schweiz',em:'🇨🇭',cont:'europa',parts:['Zürich','Bern','Genf','Basel','Luzern','St.Gallen','Tessin','Wallis'],fee:4000},
  SE:{name:'Schweden',em:'🇸🇪',cont:'europa',parts:['Stockholm','Göteborg','Malmö','Uppsala','Norrbotten','Västerbotten','Dalarna','Skåne'],fee:3000},
  US:{name:'USA',em:'🇺🇸',cont:'nordamerika',parts:['Ostküste','Neuengland','Mittlerer Atlantik','Südosten','Mittlerer Westen','Südwesten','Westküste','Pazifischer NW'],fee:8000},
  CA:{name:'Kanada',em:'🇨🇦',cont:'nordamerika',parts:['Ontario','Quebec','British Columbia','Alberta','Manitoba','Saskatchewan','Atlantik','Norden'],fee:4000},
  MX:{name:'Mexiko',em:'🇲🇽',cont:'nordamerika',parts:['Mexico City','Nordwesten','Nordosten','Westen','Osten','Süden','Yucatán','Pazifik'],fee:2500},
  BR:{name:'Brasilien',em:'🇧🇷',cont:'suedamerika',parts:['São Paulo','Rio','Nordosten','Norden','Süden','Zentrum','Amazonas','Minas Gerais'],fee:3500},
  CN:{name:'China',em:'🇨🇳',cont:'asien',parts:['Ostchina','Südchina','Nordchina','Peking','Shanghai','Sichuan','Guangdong','Innere Mongolei'],fee:6000},
  JP:{name:'Japan',em:'🇯🇵',cont:'asien',parts:['Tokio','Osaka-Kobe','Nagoya','Hokkaido','Kyushu','Tohoku','Chugoku','Shikoku'],fee:5000},
  IN:{name:'Indien',em:'🇮🇳',cont:'asien',parts:['Delhi','Mumbai','Bangalore','Chennai','Kolkata','Hyderabad','Westindien','Ostindien'],fee:3000},
  AU:{name:'Australien',em:'🇦🇺',cont:'ozeanien',parts:['New South Wales','Victoria','Queensland','Westaustralien','Südaustralien','Tasmanien','NT','ACT'],fee:4000},
  ZA:{name:'Südafrika',em:'🇿🇦',cont:'afrika',parts:['Gauteng','Westkap','KwaZulu-Natal','Ostkap','Free State','Limpopo','Mpumalanga','Nordwest'],fee:2500},
  NG:{name:'Nigeria',em:'🇳🇬',cont:'afrika',parts:['Lagos','Abuja','Kano','Ibadan','Südwest','Südost','Norden','Niger-Delta'],fee:2000},
};
// Generate territory keys: DE_0, DE_1, ... DE_7
const TERRITORIES={};
Object.entries(COUNTRIES).forEach(([cc,co])=>{
  co.parts.forEach((pName,i)=>{
    TERRITORIES[cc+'_'+i]={name:pName,country:cc,countryName:co.name,em:co.em,cont:co.cont,fee:co.fee,idx:i};
  });
});

// Buildings: region-dependent via 'conts' (allowed continents)
const ALLIANCE_BUILDINGS={
  gemeinschaftslager:{name:'Gemeinschaftslager',em:'📦',price:15000,lvl:1,desc:'+500 Lager',conts:['all'],recipes:[]},
  handelsposten:{name:'Handelsposten',em:'🏪',price:25000,lvl:1,desc:'Allianz-Aufträge',conts:['all'],recipes:[]},
  grossbaeckerei:{name:'Großbäckerei',em:'🍞',price:40000,lvl:1,desc:'Mehl+Zucker→Brot',conts:['europa','nordamerika'],recipes:[{out:'brot',outR:8,in1:'mehl',in1N:5,in2:'zucker',in2N:3}]},
  raffinerie:{name:'Raffinerie',em:'🏭',price:100000,lvl:2,desc:'Öl→Treibstoff',conts:['asien','nordamerika','afrika'],recipes:[{out:'treibstoff',outR:6,in1:'oel',in1N:4}]},
  textilzentrum:{name:'Textilzentrum',em:'👔',price:120000,lvl:3,desc:'Baumwolle+Wolle→Mode',conts:['europa','asien'],recipes:[{out:'designermode',outR:3,in1:'baumwolle',in1N:6,in2:'wolle',in2N:4}]},
  konservenfabrik:{name:'Konservenfabrik',em:'🥫',price:80000,lvl:3,desc:'Obst→Konserven',conts:['all'],recipes:[{out:'konserven',outR:10,in1:'obst_apfel',in1N:8}]},
  chemiefabrik:{name:'Chemiefabrik',em:'🧪',price:200000,lvl:4,desc:'Öl+Kohle→Chemikalien',conts:['europa','nordamerika','asien'],recipes:[{out:'chemikalien',outR:4,in1:'oel',in1N:3,in2:'kohle',in2N:2}]},
  hightech_fabrik:{name:'Hightech-Fabrik',em:'🔬',price:300000,lvl:4,desc:'Elektronik+Glas→Smartphones',conts:['asien','nordamerika','europa'],recipes:[{out:'smartphones',outR:2,in1:'elektronik',in1N:4,in2:'glas',in2N:2}]},
  pharma_zentrum:{name:'Pharmazentrum',em:'💊',price:350000,lvl:5,desc:'Medikamente→Impfstoffe',conts:['europa','nordamerika'],recipes:[{out:'impfstoffe',outR:3,in1:'medikamente',in1N:6}]},
  luxus_werft:{name:'Luxuswerft',em:'🛥️',price:500000,lvl:5,desc:'Stahl+Holz→Yachten',conts:['europa','ozeanien'],recipes:[{out:'yachten',outR:1,in1:'stahl',in1N:10,in2:'holz',in2N:8}]},
  waffenfabrik:{name:'Rüstungskonzern',em:'🛡️',price:600000,lvl:6,desc:'Stahl+Chemikalien→Rüstung',conts:['nordamerika','europa','asien'],recipes:[{out:'ruestung',outR:2,in1:'stahl',in1N:8,in2:'chemikalien',in2N:4}]},
  raumfahrt:{name:'Raumfahrtzentrum',em:'🚀',price:800000,lvl:6,desc:'Chips+Stahl→Satelliten',conts:['nordamerika','europa','asien'],recipes:[{out:'satelliten',outR:1,in1:'chips',in1N:5,in2:'stahl',in2N:8}]},
  fusionsreaktor:{name:'Fusionsreaktor',em:'⚡',price:2000000,lvl:7,desc:'Erz+Chemikalien→Fusionszellen',conts:['europa','asien'],recipes:[{out:'fusionszellen',outR:1,in1:'erz',in1N:12,in2:'chemikalien',in2N:6}]},
  ki_zentrum:{name:'KI-Zentrum',em:'🤖',price:3000000,lvl:8,desc:'Chips+Elektronik→KI-Module',conts:['nordamerika','asien','europa'],recipes:[{out:'ki_module',outR:1,in1:'chips',in1N:8,in2:'elektronik',in2N:6}]},
};
const ALLIANCE_GOODS={treibstoff:{name:'Treibstoff',em:'⛽',bp:500},designermode:{name:'Designermode',em:'👗',bp:1800},smartphones:{name:'Smartphones',em:'📱',bp:2500},chemikalien:{name:'Chemikalien',em:'🧪',bp:800},impfstoffe:{name:'Impfstoffe',em:'💉',bp:3000},yachten:{name:'Yachten',em:'🛥️',bp:8000},satelliten:{name:'Satelliten',em:'🛰️',bp:15000},ruestung:{name:'Rüstungsgüter',em:'🛡️',bp:5000},fusionszellen:{name:'Fusionszellen',em:'⚡',bp:25000},ki_module:{name:'KI-Module',em:'🤖',bp:30000}};
Object.assign(GOODS,ALLIANCE_GOODS);

// Get cities in a territory (from DB by country code + approximate region)
function getCitiesInTerritory(tKey){
  const t=TERRITORIES[tKey];if(!t)return[];
  const cc=t.country;const idx=t.idx;const allDB=typeof DB!=='undefined'?DB:[];
  const countryCities=allDB.filter(d=>d[1]===cc);
  if(!countryCities.length)return[];
  // Split country cities into 8 roughly equal groups by latitude
  const sorted=[...countryCities].sort((a,b)=>b[3]-a[3]); // sort by lat desc (north first)
  const chunk=Math.ceil(sorted.length/8);
  const start=idx*chunk;
  return sorted.slice(start,start+chunk).map(d=>({name:d[0],co:d[1],lat:d[3],lng:d[4]}));
}

// Storage with fallback
const _allyCache={alliances:{},territories:{},market:[]};
async function getAlliances(){try{const r=await window.storage.get('alliances',true);if(r&&r.value){_allyCache.alliances=JSON.parse(r.value);return _allyCache.alliances}}catch(e){}return _allyCache.alliances}
async function saveAlliances(d){_allyCache.alliances=d;try{await window.storage.set('alliances',JSON.stringify(d),true)}catch(e){}}
async function getAlliance(id){const a=await getAlliances();return a[id]||null}
async function saveAlliance(a){const all=await getAlliances();all[a.id]=a;await saveAlliances(all)}
async function getTerritoryOwners(){try{const r=await window.storage.get('terr_owners',true);if(r&&r.value){_allyCache.territories=JSON.parse(r.value);return _allyCache.territories}}catch(e){}return _allyCache.territories}
async function saveTerritoryOwners(d){_allyCache.territories=d;try{await window.storage.set('terr_owners',JSON.stringify(d),true)}catch(e){}}
async function getTerritoryMarket(){try{const r=await window.storage.get('terr_market',true);if(r&&r.value){_allyCache.market=JSON.parse(r.value);return _allyCache.market}}catch(e){}return _allyCache.market}
async function saveTerritoryMarket(d){_allyCache.market=d;try{await window.storage.set('terr_market',JSON.stringify(d),true)}catch(e){}}
function RA(){if(typeof renderAlliance==='function')renderAlliance()}

// Actions
async function createAlliance(name,tag){if(!G||!currentUser)return;if(G.alliance){addLog('❌ Bereits in Allianz');return}if(!name||name.length<3){addLog('❌ Name min. 3');return}if(!tag||tag.length<2||tag.length>4){addLog('❌ Tag 2-4');return}const cost=300000;if(G.money<cost){addLog('❌ '+fmt(cost)+' nötig (150.000€ Startkapital)');return}G.money-=cost;const id=uid();const a={id,name,tag:tag.toUpperCase(),level:1,leader:currentUser,members:[{user:currentUser,role:'leader',joined:Date.now()}],treasury:250000,storage:{},buildings:[],territories:[],orders:[],created:Date.now()};await saveAlliance(a);G.alliance=id;addLog('🤝 ['+tag.toUpperCase()+'] '+name+' gegründet!');if(typeof toast==='function')toast('🤝 Allianz gegründet! 250.000€ Startkapital','#a855f7');ua();RA()}
async function joinAlliance(id){
  if(!G||!currentUser||G.alliance)return;
  const a=await getAlliance(id);if(!a)return;
  if(!a.applications)a.applications=[];
  if(a.applications.find(x=>x.user===currentUser)){addLog('❌ Bewerbung bereits eingereicht');return}
  a.applications.push({user:currentUser,applied:Date.now()});
  await saveAlliance(a);
  addLog('📨 Bewerbung eingereicht');if(typeof toast==='function')toast('📨 Bewerbung gesendet — warte auf Genehmigung');RA();
}
async function approveApplication(user){
  if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;
  if(!canDo(a,currentUser,'canRoles')&&!canDo(a,currentUser,'canInvite')){addLog('❌ Keine Berechtigung');return}
  const lv=ALLIANCE_LEVELS[a.level-1];
  if(a.members.length>=lv.maxMembers){addLog('❌ Allianz voll');return}
  if(!a.applications)return;
  a.applications=a.applications.filter(x=>x.user!==user);
  a.members.push({user,role:'member',joined:Date.now()});
  await saveAlliance(a);addLog('✅ '+user+' aufgenommen');if(typeof toast==='function')toast('✅ '+user+' aufgenommen');RA();
}
async function rejectApplication(user){
  if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;
  if(!a.applications)return;
  a.applications=a.applications.filter(x=>x.user!==user);
  await saveAlliance(a);addLog('❌ '+user+' abgelehnt');if(typeof toast==='function')toast('❌ Bewerbung abgelehnt','var(--r)');RA();
}
async function leaveAlliance(){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;if(a.leader===currentUser&&a.members.length>1){addLog('❌ Erst Leitung übergeben');return}a.members=a.members.filter(m=>m.user!==currentUser);if(!a.members.length){const al=await getAlliances();delete al[a.id];await saveAlliances(al)}else{if(a.leader===currentUser)a.leader=a.members[0].user;await saveAlliance(a)}G.alliance=null;ua();RA()}
async function upgradeAlliance(){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a||a.leader!==currentUser)return;const n=ALLIANCE_LEVELS[a.level];if(!n){addLog('❌ Max');return}if(a.treasury<n.cost){addLog('❌ Kasse: '+fmt(a.treasury));return}a.treasury-=n.cost;a.level++;await saveAlliance(a);addLog('⬆️ Level '+a.level);if(typeof toast==='function')toast('⬆️ Allianz Level '+a.level+'!','#a855f7');ua();RA()}
async function deliverToAlliance(cid,good,amt){
  if(!G||!G.alliance)return;
  const s=G.stor[cid];if(!s||(s[good]||0)<amt)return;
  const c=C(cid);if(!c)return;
  // Require idle vehicle
  const vehs=G.vehs.filter(v=>v.st==='idle'&&v.loc===cid);
  if(!vehs.length){addLog('❌ Kein Fahrzeug in '+c.name);if(typeof toast==='function')toast('❌ Kein Fahrzeug in '+c.name,'var(--r)');return}
  const v=vehs.sort((a2,b)=>vehCap(b)-vehCap(a2))[0];
  const maxAmt=Math.min(amt,vehCap(v));
  s[good]-=maxAmt;if(s[good]<=0)delete s[good];
  // Pick a nearby city as "alliance hub" destination (round trip)
  const allDB=typeof DB!=='undefined'?DB:[];
  const nearby=allDB.filter(x=>x[0]!==c.name).sort((a2,b)=>hav(c.lat,c.lng,a2[3],a2[4])-hav(c.lat,c.lng,b[3],b[4]));
  const dest=nearby[0]||[c.name,c.co,0,c.lat+0.1,c.lng+0.1];
  const dist=Math.round(hav(c.lat,c.lng,dest[3],dest[4]));
  const vt=VT[v.type];
  const tripTime=Math.round(dist/vt.spd*3.6*2);
  // Send vehicle
  const destId='ally_'+dest[0].toLowerCase().replace(/[^a-z0-9]/g,'');
  v.st='moving';v.rt={from:cid,to:destId,toLat:dest[3],toLng:dest[4],toName:dest[0],tripTime};
  v.cargo={allianceDelivery:true,good,amt:maxAmt,allianceId:G.alliance,destName:dest[0],returnTo:cid};
  v.prog=0;
  if(typeof ensureRoute==='function')ensureRoute(v);
  addLog('🤝 '+vehName(v)+': '+maxAmt+'× → Allianz');if(typeof toast==='function')toast('🚛 '+maxAmt+'× '+(GOODS[good]?.name||'')+' unterwegs zum Allianz-Lager','#a855f7');ua();RA();
}
async function buildAllianceBuilding(type,cityName,cityCountry){
  if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;
  const d=ALLIANCE_BUILDINGS[type];if(!d)return;
  const lv=ALLIANCE_LEVELS[a.level-1];
  if(a.buildings.length>=lv.slots){addLog('❌ Max '+lv.slots+' Gebäude');return}
  if(a.level<d.lvl){addLog('❌ Allianz Lvl '+d.lvl+' nötig');return}
  if(a.treasury<d.price){addLog('❌ Kasse: '+fmt(a.treasury));return}
  if(!canDo(a,currentUser,'canBuild')){addLog('❌ Keine Bauberechtigung');return}
  // Check continent from country code
  const cont=cityCountry?getRegion(cityCountry):'europa';
  if(!d.conts.includes('all')&&!d.conts.includes(cont)){addLog('❌ Nicht in dieser Region baubar');return}
  if(a.buildings.find(b=>b.cityName===cityName)){addLog('❌ Stadt bereits belegt');return}
  a.treasury-=d.price;
  a.buildings.push({type,cityName,continent:cont,recipe:0,built:Date.now()});
  await saveAlliance(a);addLog('🏭 '+d.em+' in '+cityName);if(typeof toast==='function')toast('🏭 '+d.name+' in '+cityName+' gebaut!','#a855f7');ua();RA();
}
async function allianceProduce(i){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;const b=a.buildings[i];if(!b)return;const d=ALLIANCE_BUILDINGS[b.type];if(!d||!d.recipes.length)return;const r=d.recipes[b.recipe||0];if(!r)return;if((a.storage[r.in1]||0)<r.in1N){addLog('❌ '+(GOODS[r.in1]?.name||'')+' fehlt');return}if(r.in2&&(a.storage[r.in2]||0)<r.in2N){addLog('❌ '+(GOODS[r.in2]?.name||'')+' fehlt');return}a.storage[r.in1]-=r.in1N;if(a.storage[r.in1]<=0)delete a.storage[r.in1];if(r.in2){a.storage[r.in2]-=r.in2N;if(a.storage[r.in2]<=0)delete a.storage[r.in2]}a.storage[r.out]=(a.storage[r.out]||0)+r.outR;await saveAlliance(a);addLog('🏭 '+(GOODS[r.out]?.em||'')+' '+r.outR+'×');if(typeof toast==='function')toast('🏭 '+r.outR+'× '+(GOODS[r.out]?.name||'')+' produziert!','#a855f7');ua();RA()}
async function claimTerritory(tKey){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a||a.leader!==currentUser)return;const t=TERRITORIES[tKey];if(!t)return;const lv=ALLIANCE_LEVELS[a.level-1];if(a.territories.length>=lv.maxTerr){addLog('❌ Max '+lv.maxTerr);return}const to=await getTerritoryOwners();if(to[tKey]){addLog('❌ Vergeben');return}const cost=t.fee*30;if(a.treasury<cost){addLog('❌ '+fmt(cost)+' nötig');return}a.treasury-=cost;a.territories.push(tKey);to[tKey]={alliance:a.id,tag:a.tag,name:a.name,missed:0};await saveAlliance(a);await saveTerritoryOwners(to);addLog('🏴 '+t.countryName+' · '+t.name);if(typeof toast==='function')toast('🏴 '+t.name+' beansprucht!','#a855f7');ua();RA()}
async function listTerritoryForSale(tKey,price){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a||a.leader!==currentUser||!a.territories.includes(tKey))return;const m=await getTerritoryMarket();m.push({territory:tKey,seller:a.id,sellerTag:a.tag,sellerName:a.name,price,listed:Date.now()});await saveTerritoryMarket(m);addLog('📋 Angeboten');RA()}
async function buyTerritoryFromMarket(idx){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a||a.leader!==currentUser)return;const m=await getTerritoryMarket();const l=m[idx];if(!l||a.treasury<l.price)return;a.treasury-=l.price;const s=await getAlliance(l.seller);if(s){s.treasury+=l.price;s.territories=s.territories.filter(t=>t!==l.territory);await saveAlliance(s)}a.territories.push(l.territory);const to=await getTerritoryOwners();to[l.territory]={alliance:a.id,tag:a.tag,name:a.name,missed:0};await saveTerritoryOwners(to);m.splice(idx,1);await saveTerritoryMarket(m);addLog('🏴 Gekauft!');ua();RA()}
async function acceptAllianceOrder(i){if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a||!a.orders)return;const o=a.orders[i];if(!o)return;if((a.storage[o.good]||0)<o.amt){addLog('❌ Fehlt');return}a.storage[o.good]-=o.amt;if(a.storage[o.good]<=0)delete a.storage[o.good];a.treasury+=o.rew;a.orders.splice(i,1);await saveAlliance(a);addLog('💰 Allianzauftrag +'+fmt(o.rew));if(typeof toast==='function')toast('💰 +'+fmt(o.rew)+' in die Allianzkasse','#a855f7');ua();RA()}

// ── Roles: leader, officer, member ──
const ALLY_ROLES={
  leader:{name:'CEO',em:'👑',canBuild:true,canClaim:true,canUpgrade:true,canRoles:true,canInvite:true,canProduce:true,canDeliver:true,canOrders:true,canMarket:true},
  vp:{name:'Vizepräsident',em:'🌟',canBuild:true,canClaim:true,canUpgrade:false,canRoles:true,canInvite:true,canProduce:true,canDeliver:true,canOrders:true,canMarket:true},
  hr:{name:'Personalmanager',em:'👥',canBuild:false,canClaim:false,canUpgrade:false,canRoles:true,canInvite:true,canProduce:false,canDeliver:false,canOrders:false,canMarket:false},
  prod:{name:'Produktionsleiter',em:'🏭',canBuild:true,canClaim:false,canUpgrade:false,canRoles:false,canInvite:false,canProduce:true,canDeliver:true,canOrders:false,canMarket:false},
  logistics:{name:'Auftragsmanager',em:'📋',canBuild:false,canClaim:false,canUpgrade:false,canRoles:false,canInvite:false,canProduce:false,canDeliver:true,canOrders:true,canMarket:true},
  territory:{name:'Gebietsmanager',em:'🏴',canBuild:false,canClaim:true,canUpgrade:false,canRoles:false,canInvite:false,canProduce:false,canDeliver:false,canOrders:false,canMarket:true},
  member:{name:'Mitglied',em:'👤',canBuild:false,canClaim:false,canUpgrade:false,canRoles:false,canInvite:false,canProduce:false,canDeliver:true,canOrders:false,canMarket:false},
};
function getMemberRole(a,user){const m=a.members.find(x=>x.user===user);return m?m.role:'member'}
function canDo(a,user,perm){const role=getMemberRole(a,user);return ALLY_ROLES[role]?.[perm]||false}
async function setMemberRole(targetUser,newRole){
  if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;
  if(!canDo(a,currentUser,'canRoles')){addLog('❌ Keine Berechtigung');return}
  if(newRole==='leader'){addLog('❌ CEO-Übertragung nur über Verlassen');return}
  const m=a.members.find(x=>x.user===targetUser);if(!m){addLog('❌ Nicht gefunden');return}
  if(m.role==='leader'){addLog('❌ CEO kann nicht degradiert werden');return}
  m.role=newRole;await saveAlliance(a);addLog('👤 '+targetUser+' → '+ALLY_ROLES[newRole].name);RA();
}
async function inviteToAlliance(userName){
  if(!G||!G.alliance)return;const a=await getAlliance(G.alliance);if(!a)return;
  if(!canDo(a,currentUser,'canInvite')){addLog('❌ Keine Einladeberechtigung');return}
  if(!a.invites)a.invites=[];
  if(a.invites.includes(userName)){addLog('❌ Bereits eingeladen');return}
  a.invites.push(userName);await saveAlliance(a);
  addLog('📨 '+userName+' eingeladen');RA();
}
async function acceptInvite(allyId){
  if(!G||!currentUser||G.alliance)return;
  const a=await getAlliance(allyId);if(!a)return;
  if(!a.invites||!a.invites.includes(currentUser)){addLog('❌ Keine Einladung');return}
  const lv=ALLIANCE_LEVELS[a.level-1];
  if(a.members.length>=lv.maxMembers){addLog('❌ Voll');return}
  a.invites=a.invites.filter(x=>x!==currentUser);
  a.members.push({user:currentUser,role:'member',joined:Date.now()});
  await saveAlliance(a);G.alliance=allyId;
  addLog('🤝 Einladung angenommen');ua();RA();
}
// Check if user has pending application somewhere
async function checkMyApplications(){
  const all=await getAlliances();const pending=[];
  Object.values(all).forEach(a=>{if(a.applications&&a.applications.find(x=>x.user===currentUser))pending.push(a)});
  return pending;
}

// Alliance value = treasury + buildings + territories + storage
function allianceValue(a){
  if(!a)return 0;let v=a.treasury||0;
  (a.buildings||[]).forEach(b=>{const d=ALLIANCE_BUILDINGS[b.type];if(d)v+=Math.floor(d.price*0.6)});
  (a.territories||[]).forEach(tK=>{const t=TERRITORIES[tK];if(t)v+=t.fee*30});
  Object.entries(a.storage||{}).forEach(([g,amt])=>{v+=amt*(GOODS[g]?.bp||50)});
  return v;
}

// ═══ ALLIANCE RESOURCE MARKET ═══
async function getAllianceMarket(){
  try{const r=await window.storage.get('ally_market',true);if(r&&r.value)return JSON.parse(r.value)}catch(e){}
  return[];
}
async function saveAllianceMarket(d){
  try{await window.storage.set('ally_market',JSON.stringify(d),true)}catch(e){}
}
async function postAllianceRequest(good,amt,ppu){
  if(!G||!G.alliance)return;
  const a=await getAlliance(G.alliance);if(!a)return;
  if(!canDo(a,currentUser,'canOrders')&&a.leader!==currentUser){addLog('❌ Keine Berechtigung');return}
  if(!good||!amt||amt<1||!ppu||ppu<1){addLog('❌ Ungültige Eingabe');return}
  const totalCost=amt*ppu;
  if(a.treasury<totalCost){addLog('❌ Kasse: '+fmt(a.treasury)+' ('+fmt(totalCost)+' nötig)');if(typeof toast==='function')toast('❌ Nicht genug in der Allianzkasse','var(--r)');return}
  // Reserve money
  a.treasury-=totalCost;
  await saveAlliance(a);
  const mk=await getAllianceMarket();
  mk.push({id:uid(),allianceId:a.id,allianceTag:a.tag,allianceName:a.name,good,amt,filled:0,ppu,totalCost,posted:Date.now()});
  await saveAllianceMarket(mk);
  addLog('📋 Kaufanfrage: '+amt+'× '+(GOODS[good]?.em||'')+' für '+fmt(ppu)+'/St.');
  if(typeof toast==='function')toast('📋 Anfrage erstellt ('+fmt(totalCost)+' reserviert)','#a855f7');
  RA();
}
async function fulfillAllianceRequest(reqId,cid,amt){
  if(!G)return;
  const mk=await getAllianceMarket();
  const req=mk.find(r=>r.id===reqId);if(!req)return;
  const remaining=req.amt-req.filled;
  if(amt>remaining)amt=remaining;
  const stor=G.stor[cid];if(!stor||(stor[req.good]||0)<amt){addLog('❌ Nicht genug Ware');return}
  // Need vehicle
  const c=C(cid);if(!c)return;
  const vehs=G.vehs.filter(v=>v.st==='idle'&&v.loc===cid);
  if(!vehs.length){addLog('❌ Kein Fahrzeug in '+(c.name||cid));if(typeof toast==='function')toast('❌ Kein Fahrzeug','var(--r)');return}
  const v=vehs.sort((a2,b)=>vehCap(b)-vehCap(a2))[0];
  const maxAmt=Math.min(amt,vehCap(v));
  // Remove from player storage
  stor[req.good]-=maxAmt;if(stor[req.good]<=0)delete stor[req.good];
  // Pay player
  const payment=maxAmt*req.ppu;
  G.money+=payment;G.earned+=payment;
  // Update request
  req.filled+=maxAmt;
  if(req.filled>=req.amt){
    // Fully filled — refund any overpayment
    mk.splice(mk.indexOf(req),1);
  }
  await saveAllianceMarket(mk);
  // Add to alliance storage (via vehicle delivery)
  const a=await getAlliance(req.allianceId);
  if(a){a.storage[req.good]=(a.storage[req.good]||0)+maxAmt;await saveAlliance(a)}
  addLog('💰 Allianzlieferung: '+maxAmt+'× '+(GOODS[req.good]?.em||'')+' → ['+req.allianceTag+'] +'+fmt(payment));
  if(typeof toast==='function')toast('💰 +'+fmt(payment)+' für '+maxAmt+'× '+(GOODS[req.good]?.name||''));
  ua();
}
async function cancelAllianceRequest(reqId){
  if(!G||!G.alliance)return;
  const a=await getAlliance(G.alliance);if(!a)return;
  const mk=await getAllianceMarket();
  const req=mk.find(r=>r.id===reqId);if(!req||req.allianceId!==a.id)return;
  // Refund remaining
  const refund=(req.amt-req.filled)*req.ppu;
  a.treasury+=refund;
  await saveAlliance(a);
  mk.splice(mk.indexOf(req),1);
  await saveAllianceMarket(mk);
  addLog('↩️ Anfrage zurückgezogen, '+fmt(refund)+' erstattet');
  if(typeof toast==='function')toast('↩️ '+fmt(refund)+' erstattet');
  RA();
}
