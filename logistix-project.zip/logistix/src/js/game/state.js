// ══════════════════════════════════════════
// AUTH + GAME STATE
// ══════════════════════════════════════════

let cities=[],G=null,gameStarted=false,tickIv=null;
let currentUser=null;
function C(id){return cities.find(c=>c.id===id)}
// Extended lookup: also check orders for non-unlocked city info
function Cx(id){
  const c=C(id);if(c)return c;
  // Check if any order has this as target with stored coords
  if(G&&G.orders){const o=G.orders.find(x=>x.to===id);
    if(o&&o.toName)return{id,name:o.toName,co:'',lat:o.toLat||0,lng:o.toLng||0,pop:0}}
  // Check DB
  if(typeof DB!=='undefined'){for(const d of DB){const did=d[0].toLowerCase().replace(/\s+/g,'_');
    if(id.startsWith(did))return{id,name:d[0],co:d[1],lat:d[3],lng:d[4],pop:d[2]}}}
  return null;
}
function addLog(m){if(!G)return;G.log.unshift(m);if(G.log.length>40)G.log.pop()}

// ── Auth System (window.storage with in-memory fallback) ──
const _memStore={};
async function storeGet(k){
  if(window.storage){try{const r=await window.storage.get(k);return r?r.value:null}catch(e){return null}}
  return _memStore[k]||null;
}
async function storeSet(k,v){
  _memStore[k]=v;
  if(window.storage){try{await window.storage.set(k,v)}catch(e){}}
}
async function storeDel(k){
  delete _memStore[k];
  if(window.storage){try{await window.storage.delete(k)}catch(e){}}
}

async function getUsers(){
  try{const r=await storeGet('lx_users');return r?JSON.parse(r):{}}catch(e){return{}}
}
async function saveUsers(users){
  try{await storeSet('lx_users',JSON.stringify(users))}catch(e){}
}

function showAuth(mode){
  ['authLogin','authRegister','authReset','authSettings'].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display='none'});
  const target=document.getElementById(mode==='login'?'authLogin':mode==='register'?'authRegister':mode==='reset'?'authReset':'authSettings');
  if(target)target.style.display='block';
  // Hide tabs when in settings mode
  document.getElementById('authTabs').style.display=mode==='settings'?'none':'flex';
  document.getElementById('resetStep2').style.display='none';
  document.querySelectorAll('.auth-tab').forEach((t,i)=>t.classList.toggle('on',i===(mode==='login'?0:1)));
  document.getElementById('authMsg').textContent='';
}

function authMsg(txt,ok){const el=document.getElementById('authMsg');el.textContent=txt;el.className=ok?'auth-msg-ok':'auth-msg-err'}

function togglePassVis(inputId){
  const el=document.getElementById(inputId);
  el.type=el.type==='password'?'text':'password';
}

async function doChangePass(){
  if(!currentUser)return;
  const oldP=document.getElementById('settOldPass').value;
  const newP=document.getElementById('settNewPass').value;
  if(!oldP||!newP){authMsg('Bitte ausfüllen',false);return}
  const users=await getUsers();const u=users[currentUser];
  if(!u||u.pass!==oldP){authMsg('Altes Passwort falsch',false);return}
  if(newP.length<3){authMsg('Neues Passwort zu kurz',false);return}
  u.pass=newP;await saveUsers(users);
  authMsg('✅ Passwort geändert!',true);
}

async function doChangeEmail(){
  if(!currentUser)return;
  const newE=document.getElementById('settNewEmail').value.trim();
  if(!newE||!newE.includes('@')){authMsg('Ungültige E-Mail',false);return}
  const users=await getUsers();const u=users[currentUser];
  if(!u)return;u.email=newE;await saveUsers(users);
  authMsg('✅ E-Mail geändert!',true);
}

async function doLogin(){
  const user=document.getElementById('loginUser').value.trim();
  const pass=document.getElementById('loginPass').value;
  if(!user||!pass){authMsg('Bitte ausfüllen',false);return}
  const users=await getUsers();
  const u=users[user.toLowerCase()];
  if(!u||u.pass!==pass){authMsg('Falscher Benutzername oder Passwort',false);return}
  currentUser=user.toLowerCase();
  authMsg('');
  try{adminLog('auth','🔑 Login: '+user)}catch(e){}
  afterLogin(u);
}

async function doRegister(){
  const user=document.getElementById('regUser').value.trim();
  const email=document.getElementById('regEmail').value.trim();
  const pass=document.getElementById('regPass').value;
  const pass2=document.getElementById('regPass2').value;
  const question=document.getElementById('regQuestion').value.trim();
  const answer=document.getElementById('regAnswer').value.trim();
  if(!user||!email||!pass||!question||!answer){authMsg('Bitte alle Felder ausfüllen',false);return}
  if(pass!==pass2){authMsg('Passwörter stimmen nicht überein',false);return}
  if(user.length<2){authMsg('Benutzername zu kurz',false);return}
  if(pass.length<3){authMsg('Passwort zu kurz',false);return}
  const users=await getUsers();
  if(users[user.toLowerCase()]){authMsg('Benutzername bereits vergeben',false);return}
  users[user.toLowerCase()]={user,email,pass,question,answer:answer.toLowerCase(),created:Date.now()};
  await saveUsers(users);
  try{adminLog('auth','📝 Neuer Spieler: '+user)}catch(e){}
  authMsg('✅ Registrierung erfolgreich! Bitte melde dich jetzt an.',true);
  setTimeout(()=>{showAuth('login');document.getElementById('loginUser').value=user},1200);
}

async function doResetStep1(){
  const user=document.getElementById('resetUser').value.trim();
  if(!user){authMsg('Benutzername eingeben',false);return}
  const users=await getUsers();
  const u=users[user.toLowerCase()];
  if(!u){authMsg('Benutzer nicht gefunden',false);return}
  document.getElementById('resetQ').textContent='Sicherheitsfrage: '+u.question;
  document.getElementById('resetStep2').style.display='block';
  document.getElementById('resetStep2')._user=user.toLowerCase();
}

async function doResetStep2(){
  const userKey=document.getElementById('resetStep2')._user;
  const answer=document.getElementById('resetAnswer').value.trim().toLowerCase();
  const newPass=document.getElementById('resetNewPass').value;
  if(!answer||!newPass){authMsg('Bitte ausfüllen',false);return}
  const users=await getUsers();
  const u=users[userKey];
  if(!u||u.answer!==answer){authMsg('Falsche Antwort',false);return}
  if(newPass.length<3){authMsg('Passwort zu kurz',false);return}
  u.pass=newPass;
  await saveUsers(users);
  authMsg('Passwort geändert! Du kannst dich jetzt anmelden.',true);
  setTimeout(()=>showAuth('login'),1500);
}

function doLogout(){
  save();
  currentUser=null;G=null;gameStarted=false;cities=[];
  if(tickIv){clearInterval(tickIv);tickIv=null}
  document.getElementById('loginScreen').style.display='flex';
  document.getElementById('startScreen').style.display='none';
  ['gameScreen','computer'].forEach(id=>document.getElementById(id).style.display='none');
  if(MP){Object.values(cMk).forEach(m=>MP.removeLayer(m));Object.values(cLb).forEach(m=>MP.removeLayer(m));
  Object.values(vMk).forEach(m=>MP.removeLayer(m));Object.values(rLn).forEach(l=>MP.removeLayer(l));
  Object.values(bMk).forEach(arr=>arr.forEach(m=>MP.removeLayer(m)));}
  showAuth('login');
}

async function deleteSave(){
  if(!currentUser)return;
  try{await storeSet('save_'+currentUser,null)}catch(e){}
  G=null;
}

function openSettings(){
  let existing=document.getElementById('settingsPopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='settingsPopup';popup.className='unlock-bg';
  let h='<div class="unlock-popup" style="width:460px;max-height:85vh;overflow-y:auto"><div class="unlock-body">';
  h+='<div style="text-align:center;margin-bottom:16px"><span style="font-size:28px">⚙️</span><div style="font-family:var(--mono);font-size:20px;font-weight:700;color:var(--a);margin-top:6px">Einstellungen</div></div>';
  h+='<div class="sec-label">Konto</div>';
  h+='<div class="crd"><div class="rw"><span>👤 Benutzer</span><span style="font-family:var(--mono);color:var(--a)">'+currentUser+'</span></div></div>';
  h+='<div class="crd"><div class="sub" style="margin-bottom:6px">Passwort ändern</div>';
  h+='<input type="password" id="setNewPw" class="auth-input" placeholder="Neues Passwort" style="margin-bottom:6px"/>';
  h+='<button class="btn full" onclick="const p=document.getElementById(\'setNewPw\').value;if(p.length<3){alert(\'Mindestens 3 Zeichen\');return}changePassword(p).then(()=>{alert(\'✅ Passwort geändert\')})">Passwort ändern</button></div>';
  h+='<div class="sec-label" style="margin-top:12px">Spielstand</div>';
  h+='<div class="crd"><button class="btn full" onclick="if(confirm(\'Spielstand wirklich löschen? Das kann nicht rückgängig gemacht werden!\')){deleteSave();document.getElementById(\'settingsPopup\').remove();location.reload()}">🗑️ Spielstand löschen</button></div>';
  h+='<div class="sec-label" style="margin-top:12px">Abmelden</div>';
  h+='<div class="crd"><button class="btn red full" onclick="document.getElementById(\'settingsPopup\').remove();doLogout()">🚪 Abmelden</button></div>';
  h+='<button class="btn full" style="margin-top:16px" onclick="document.getElementById(\'settingsPopup\').remove()">Schließen</button>';
  h+='</div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
}

async function afterLogin(userData){
  document.getElementById('loginScreen').style.display='none';
  // Try loading existing save
  const loaded=await load();
  if(loaded&&G&&cities.length>0){
    document.getElementById('startScreen').style.display='none';
    launchGame(cities[0]);
  } else {
    document.getElementById('startScreen').style.display='flex';
    document.getElementById('welcomeMsg').textContent='Willkommen, '+currentUser+'!';
    startRes.innerHTML='<div class="start-hint">z.B. "Alzey", "Berlin", "Tokyo"...</div>';
    setTimeout(()=>startIn.focus(),300);
  }
}

// ── Init test account ──
async function ensureTestAccount(){
  const users=await getUsers();
  // Always overwrite test account to ensure correct password
  users['test']={user:'Test',email:'test@logistix.de',pass:'test',question:'Was ist das Testpasswort?',answer:'test',created:Date.now()};
  await saveUsers(users);
}

// ── Game State ──
function newGame(city){
  cities=[city];
  G={money:50000,tick:0,sel:city.id,vehs:[],blds:{},infra:{},stor:{},orders:[],
    log:['🎮 Willkommen in '+city.name+'!','🎯 Schau dir deine Missionen an!'],
    earned:0,dels:0,level:1,unlockedCities:[city],quests:{tutorial:{},dailies:null,weeklies:null,dailyTs:0,weeklyTs:0},
    history:[],standingOrders:[]};
  if(currentUser==='test')G.money=10000000;
}

async function save(){
  if(!G||!currentUser)return;
  try{await storeSet('lx_save_'+currentUser,JSON.stringify({...G,_t:Date.now()}))}catch(e){}
}

async function load(){
  if(!currentUser)return false;
  try{const r=await storeGet('lx_save_'+currentUser);
  if(r){const d=JSON.parse(r);const off=d._t?Math.floor((Date.now()-d._t)/1000):0;delete d._t;
    if(d.unlockedCities&&d.unlockedCities.length){cities=[];d.unlockedCities.forEach(c=>{if(!cities.find(x=>x.id===c.id))cities.push(c)})}
    G=d;if(!G.history)G.history=[];if(!G.infra)G.infra={};if(!G.standingOrders)G.standingOrders=[];if(!G.level)G.level=1;
    const n=Math.min(off,7200);if(n>30){addLog('⏰ '+ftime(n)+' offline');for(let i=0;i<n;i++)tickCore();addLog('✅ Sim fertig!')}
    return true}}catch(e){}return false
}

async function reset(){
  if(!confirm('Spielstand komplett löschen?'))return;
  if(tickIv){clearInterval(tickIv);tickIv=null}
  if(MP){try{cities.forEach(c=>{if(cMk[c.id])MP.removeLayer(cMk[c.id]);if(cLb[c.id])MP.removeLayer(cLb[c.id]);(bMk[c.id]||[]).forEach(m=>MP.removeLayer(m))});
  Object.values(vMk).forEach(m=>MP.removeLayer(m));Object.values(rLn).forEach(l=>MP.removeLayer(l))}catch(e){}}
  cities=[];G=null;gameStarted=false;
  if(currentUser)try{await storeDel('lx_save_'+currentUser)}catch(e){}
  document.getElementById('startScreen').style.display='flex';
  ['gameScreen','computer'].forEach(id=>document.getElementById(id).style.display='none');
  startIn.value='';startRes.innerHTML='<div class="start-hint">z.B. "Alzey", "Berlin", "Tokyo"...</div>';startIn.focus();
  if(MP)MP.setView([30,10],3);
}

function genOrd(){
  if(!cities.length||!G)return null;
  const supply=[];
  Object.entries(G.stor).forEach(([cid,s])=>{Object.entries(s).forEach(([good,amt])=>{if(amt>=2)supply.push({cid,good,amt})})});
  if(!supply.length)return null;
  const pick=supply[Math.random()*supply.length|0];
  const f=C(pick.cid);if(!f)return null;
  const lvl=playerLvl();
  const maxDist=[25,35,50,100,200,500,1500,5000,12000,25000][Math.min(lvl-1,9)];
  const allDB=typeof DB!=='undefined'?DB:[];
  // ALL nearby cities from DB within range
  const dbPool=allDB.filter(x=>x[0]!==f.name&&hav(f.lat,f.lng,x[3],x[4])<maxDist);
  if(!dbPool.length)return null;
  // Pick target from dbPool (includes unlocked + non-unlocked)
  const td=dbPool[Math.floor(Math.random()*dbPool.length)];
  const match=cities.find(c=>c.name===td[0]);
  let tId,tName,tLat,tLng,tCo,tUnlocked;
  if(match){tId=match.id;tName=match.name;tLat=match.lat;tLng=match.lng;tCo=match.co;tUnlocked=true}
  else{tId='db_'+td[0].toLowerCase().replace(/[^a-z0-9]/g,'');tName=td[0];tLat=td[3];tLng=td[4];tCo=td[1];tUnlocked=false}
  const g=GOODS[pick.good];if(!g)return null;
  const maxAmt=Math.min(pick.amt,[6,10,15,20,28,35,40,50,60,80][Math.min(lvl-1,9)]);
  const amt=Math.max(2,Math.floor(Math.random()*maxAmt)+2);
  const d=hav(f.lat,f.lng,tLat,tLng);
  const toReg=getRegion((tCo||'').toUpperCase());
  const mktPrice=typeof marketPrice==='function'?marketPrice(pick.good,toReg):(g.bp||100);
  const distFactor=Math.min(d/maxDist,1);
  const orderMult=1.3+distFactor*1.2+Math.random()*0.5;
  const rew=Math.round(mktPrice*amt*orderMult);
  const tl=Math.max(3600,Math.floor(d/20*60+1800+Math.random()*3600));
  if(!G.orderNum)G.orderNum=0;G.orderNum++;
  return{id:uid(),num:G.orderNum,from:pick.cid,to:tId,good:pick.good,amt,rew,tl,born:G.tick,acc:false,
    pricePerUnit:Math.round(rew/amt),mktRef:mktPrice,toName:tName,toLat:tLat,toLng:tLng,toUnlocked:tUnlocked};
}
