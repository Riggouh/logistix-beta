// ══════════════════════════════════════════
// QUESTS & MISSIONS SYSTEM
// ══════════════════════════════════════════

// ═══ TUTORIAL: Core mechanics (always 2 visible) ═══
const TUTORIAL=[
  {id:'t1',name:'Fahrzeug kaufen',desc:'Öffne den Händler-Tab und kaufe deinen ersten Transporter',icon:'🚐',reward:5000,
    check:()=>G.vehs.length>=1,prog:()=>[G.vehs.length,1]},
  {id:'t2',name:'Gebäude errichten',desc:'Wechsel zum Gebäude-Tab und baue einen Bauernhof oder Forstwirtschaft',icon:'🌾',reward:6000,
    check:()=>Object.values(G.blds).flat().length>=1,prog:()=>[Object.values(G.blds).flat().length,1]},
  {id:'t3',name:'Zweite Stadt',desc:'Öffne die Suchleiste (oben) und kaufe eine zweite Stadt',icon:'🏙️',reward:8000,
    check:()=>cities.length>=2,prog:()=>[cities.length,2]},
  {id:'t4',name:'Auftrag annehmen',desc:'Schau in den Aufträge-Tab und nimm einen Transportauftrag an',icon:'📋',reward:4000,
    check:()=>G.orders.some(o=>o.acc)||G.dels>=1,prog:()=>[G.orders.some(o=>o.acc)||G.dels>=1?1:0,1]},
  {id:'t5',name:'Erste Lieferung',desc:'Gehe zu Routen, weise ein Fahrzeug zu und liefere den Auftrag aus',icon:'✅',reward:12000,
    check:()=>G.dels>=1,prog:()=>[Math.min(G.dels,1),1]},
  {id:'t6',name:'Lager erweitern',desc:'Kaufe unter Gebäude → Infra eine Lagererweiterung',icon:'📦',reward:5000,
    check:()=>{if(!G.infra)return false;return Object.values(G.infra).flat().some(i=>INFRA[i.type]?.storCap)},prog:()=>[Object.values(G.infra||{}).flat().filter(i=>INFRA[i.type]?.storCap).length?1:0,1]},
  {id:'t7',name:'Verarbeitung',desc:'Baue eine Mühle, Bäckerei oder ähnliche Fabrik',icon:'🏭',reward:10000,
    check:()=>Object.values(G.blds).flat().some(b=>{const d=BLD[b.type];return d&&(d.inp||d.tp==='recipe')}),prog:()=>[Object.values(G.blds).flat().filter(b=>{const d=BLD[b.type];return d&&(d.inp||d.tp==='recipe')}).length?1:0,1]},
  {id:'t8',name:'Upgrade',desc:'Upgrade ein Gebäude im Verwalten-Tab',icon:'⬆️',reward:8000,
    check:()=>Object.values(G.blds).flat().some(b=>b.ups&&Object.values(b.ups).some(l=>l>=1)),prog:()=>[Object.values(G.blds).flat().some(b=>b.ups&&Object.values(b.ups).some(l=>l>=1))?1:0,1]},
  {id:'t9',name:'Warentransfer',desc:'Sende Waren zu einem anderen Standort (Routen → Warentransfer)',icon:'📤',reward:8000,
    check:()=>G.vehs.some(v=>v.cargo?.internal),prog:()=>[G.vehs.some(v=>v.cargo?.internal)?1:0,1]},
  {id:'t10',name:'Dauerauftrag',desc:'Erstelle einen Dauerauftrag für automatische Lieferungen',icon:'🔄',reward:10000,
    check:()=>(G.standingOrders||[]).length>=1,prog:()=>[(G.standingOrders||[]).length,1]},
];

// ═══ LEVEL MISSIONS: Progressive challenges per level ═══
const LEVEL_MISSIONS=[
  // Level 1-2
  {id:'lm1',name:'Fleißiger Gründer',desc:'Liefere 5 Aufträge aus',icon:'📦',reward:15000,minLvl:1,
    check:()=>G.dels>=5,prog:()=>[G.dels,5]},
  {id:'lm2',name:'Viehzüchter',desc:'Kaufe Hühner oder Bienen für deinen Bauernhof',icon:'🐔',reward:8000,minLvl:1,
    check:()=>Object.values(G.blds).flat().some(b=>b.animals&&Object.values(b.animals).some(n=>n>0)),prog:()=>[Object.values(G.blds).flat().some(b=>b.animals&&Object.values(b.animals).some(n=>n>0))?1:0,1]},
  {id:'lm3',name:'Obstbauer',desc:'Baue eine Obstplantage und pflanze eine Sorte an',icon:'🍎',reward:10000,minLvl:2,
    check:()=>Object.values(G.blds).flat().some(b=>b.type==='obstplantage'&&b.fruits&&Object.values(b.fruits).some(n=>n>0)),prog:()=>[Object.values(G.blds).flat().some(b=>b.type==='obstplantage'&&b.fruits&&Object.values(b.fruits).some(n=>n>0))?1:0,1]},
  // Level 3-4
  {id:'lm4',name:'3 Standorte',desc:'Besitze 3 Städte gleichzeitig',icon:'🏙️',reward:20000,minLvl:3,
    check:()=>cities.length>=3,prog:()=>[cities.length,3]},
  {id:'lm5',name:'Fuhrpark',desc:'Besitze 5 Fahrzeuge',icon:'🚛',reward:15000,minLvl:3,
    check:()=>G.vehs.length>=5,prog:()=>[G.vehs.length,5]},
  {id:'lm6',name:'Lieferkette',desc:'Verarbeite Rohstoffe in 2 verschiedenen Fabriken',icon:'🔗',reward:25000,minLvl:4,
    check:()=>{const fabs=Object.values(G.blds).flat().filter(b=>{const d=BLD[b.type];return d&&(d.inp||d.tp==='recipe')});return fabs.length>=2},prog:()=>{const n=Object.values(G.blds).flat().filter(b=>{const d=BLD[b.type];return d&&(d.inp||d.tp==='recipe')}).length;return[n,2]}},
  // Level 5-6
  {id:'lm7',name:'Industrialisierung',desc:'Baue 10 Gebäude insgesamt',icon:'🏗️',reward:30000,minLvl:5,
    check:()=>Object.values(G.blds).flat().length>=10,prog:()=>[Object.values(G.blds).flat().length,10]},
  {id:'lm8',name:'Globaler Handel',desc:'Besitze Standorte in 2 verschiedenen Regionen',icon:'🌐',reward:50000,minLvl:6,
    check:()=>{const r=new Set();cities.forEach(c=>r.add(getRegion(c.co)));return r.size>=2},prog:()=>{const r=new Set();cities.forEach(c=>r.add(getRegion(c.co)));return[r.size,2]}},
  {id:'lm9',name:'50 Lieferungen',desc:'Schließe insgesamt 50 Aufträge ab',icon:'📦',reward:60000,minLvl:6,
    check:()=>G.dels>=50,prog:()=>[G.dels,50]},
  // Level 7-8
  {id:'lm10',name:'Großunternehmer',desc:'Besitze 8 Standorte',icon:'🌍',reward:80000,minLvl:7,
    check:()=>cities.length>=8,prog:()=>[cities.length,8]},
  {id:'lm11',name:'Lagerspezialist',desc:'Baue und upgrade eine Lagerhalle',icon:'📦',reward:40000,minLvl:7,
    check:()=>Object.values(G.blds).flat().some(b=>b.type==='lagerhalle'&&b.ups&&(b.ups.lager_cap||0)>=1),prog:()=>[Object.values(G.blds).flat().some(b=>b.type==='lagerhalle'&&b.ups&&(b.ups.lager_cap||0)>=1)?1:0,1]},
  {id:'lm12',name:'Schwerindustrie',desc:'Baue ein Stahlwerk oder eine Ölförderanlage',icon:'⛏️',reward:60000,minLvl:8,
    check:()=>Object.values(G.blds).flat().some(b=>b.type==='stahlwerk'||b.type==='oelquelle'),prog:()=>[Object.values(G.blds).flat().some(b=>b.type==='stahlwerk'||b.type==='oelquelle')?1:0,1]},
  // Level 9-10
  {id:'lm13',name:'100 Lieferungen',desc:'Schließe 100 Aufträge ab',icon:'🏅',reward:120000,minLvl:9,
    check:()=>G.dels>=100,prog:()=>[G.dels,100]},
  {id:'lm14',name:'Kontinente verbinden',desc:'Standorte in 3 verschiedenen Regionen',icon:'🌐',reward:100000,minLvl:9,
    check:()=>{const r=new Set();cities.forEach(c=>r.add(getRegion(c.co)));return r.size>=3},prog:()=>{const r=new Set();cities.forEach(c=>r.add(getRegion(c.co)));return[r.size,3]}},
  {id:'lm15',name:'Tycoon',desc:'Erreiche Level 10!',icon:'👑',reward:200000,minLvl:10,
    check:()=>playerLvl()>=10,prog:()=>[playerLvl(),10]},
  // Level 11-15
  {id:'lm16',name:'300 Lieferungen',desc:'Schließe 300 Aufträge ab',icon:'📦',reward:300000,minLvl:11,
    check:()=>G.dels>=300,prog:()=>[G.dels,300]},
  {id:'lm17',name:'Imperium',desc:'Besitze 20 Standorte weltweit',icon:'🌍',reward:500000,minLvl:12,
    check:()=>cities.length>=20,prog:()=>[cities.length,20]},
  {id:'lm18',name:'Legende',desc:'Erreiche Level 15 — Globale Dominanz!',icon:'🌌',reward:5000000,minLvl:15,
    check:()=>playerLvl()>=15,prog:()=>[playerLvl(),15]},
];

// ═══ DAILIES: Require real effort, achievable in one session ═══
const DAILY_POOL=[
  {id:'d_del3',name:'Tageslieferung',desc:'Liefere 3 Aufträge',icon:'📦',reward:8000,target:3,
    check:(s)=>(G.dels-(s.startDels||0))>=3,prog:(s)=>[G.dels-(s.startDels||0),3]},
  {id:'d_del6',name:'Dauerbrenner',desc:'Liefere 6 Aufträge',icon:'📦',reward:18000,target:6,
    check:(s)=>(G.dels-(s.startDels||0))>=6,prog:(s)=>[G.dels-(s.startDels||0),6]},
  {id:'d_earn20',name:'Umsatz',desc:'Verdiene 20.000€',icon:'💰',reward:6000,target:20000,
    check:(s)=>(G.earned-(s.startEarned||0))>=20000,prog:(s)=>[G.earned-(s.startEarned||0),20000]},
  {id:'d_earn50',name:'Großverdiener',desc:'Verdiene 50.000€',icon:'💰',reward:15000,target:50000,
    check:(s)=>(G.earned-(s.startEarned||0))>=50000,prog:(s)=>[G.earned-(s.startEarned||0),50000]},
  {id:'d_build',name:'Baumeister',desc:'Errichte 2 neue Gebäude',icon:'🏗️',reward:10000,target:2,
    check:(s)=>Object.values(G.blds).flat().length-(s.startBlds||0)>=2,prog:(s)=>[Object.values(G.blds).flat().length-(s.startBlds||0),2]},
  {id:'d_upgrade2',name:'Optimierer',desc:'Führe 2 Upgrades durch',icon:'⬆️',reward:12000,target:2,
    check:(s)=>{let t=0;Object.values(G.blds).flat().forEach(b=>{if(b.ups)Object.values(b.ups).forEach(l=>t+=l)});return t-(s.startUpgrades||0)>=2},
    prog:(s)=>{let t=0;Object.values(G.blds).flat().forEach(b=>{if(b.ups)Object.values(b.ups).forEach(l=>t+=l)});return[t-(s.startUpgrades||0),2]}},
  {id:'d_cities',name:'Expansion',desc:'Schalte eine neue Stadt frei',icon:'🔓',reward:8000,target:1,
    check:(s)=>cities.length>(s.startCities||0),prog:(s)=>[cities.length-(s.startCities||0),1]},
  {id:'d_veh',name:'Flottenausbau',desc:'Kaufe ein neues Fahrzeug',icon:'🚛',reward:5000,target:1,
    check:(s)=>G.vehs.length>(s.startVehs||0),prog:(s)=>[G.vehs.length-(s.startVehs||0),1]},
];

// ═══ WEEKLIES: Multi-day effort, NOT achievable in one sitting ═══
const WEEKLY_POOL=[
  {id:'w_del15',name:'Wochenmarathon',desc:'Liefere 15 Aufträge',icon:'📦',reward:40000,
    check:(s)=>(G.dels-(s.startDels||0))>=15,prog:(s)=>[G.dels-(s.startDels||0),15]},
  {id:'w_del30',name:'Logistik-Champion',desc:'Liefere 30 Aufträge',icon:'🏅',reward:80000,
    check:(s)=>(G.dels-(s.startDels||0))>=30,prog:(s)=>[G.dels-(s.startDels||0),30]},
  {id:'w_earn150',name:'Kapitalaufbau',desc:'Verdiene 150.000€',icon:'💰',reward:50000,
    check:(s)=>(G.earned-(s.startEarned||0))>=150000,prog:(s)=>[G.earned-(s.startEarned||0),150000]},
  {id:'w_earn500',name:'Millionärskurs',desc:'Verdiene 500.000€',icon:'💎',reward:120000,
    check:(s)=>(G.earned-(s.startEarned||0))>=500000,prog:(s)=>[G.earned-(s.startEarned||0),500000]},
  {id:'w_cities3',name:'Expansion',desc:'3 neue Städte freischalten',icon:'🌍',reward:60000,
    check:(s)=>cities.length-(s.startCities||0)>=3,prog:(s)=>[cities.length-(s.startCities||0),3]},
  {id:'w_build5',name:'Industrialisierung',desc:'5 neue Gebäude bauen',icon:'🏭',reward:50000,
    check:(s)=>Object.values(G.blds).flat().length-(s.startBlds||0)>=5,prog:(s)=>[Object.values(G.blds).flat().length-(s.startBlds||0),5]},
  {id:'w_upgrade5',name:'Modernisierung',desc:'5 Upgrades durchführen',icon:'⬆️',reward:55000,
    check:(s)=>{let t=0;Object.values(G.blds).flat().forEach(b=>{if(b.ups)Object.values(b.ups).forEach(l=>t+=l)});return t-(s.startUpgrades||0)>=5},
    prog:(s)=>{let t=0;Object.values(G.blds).flat().forEach(b=>{if(b.ups)Object.values(b.ups).forEach(l=>t+=l)});return[t-(s.startUpgrades||0),5]}},
  {id:'w_km500',name:'Langstrecke',desc:'500 km zurücklegen',icon:'🛣️',reward:45000,
    check:(s)=>{const totalKm=G.vehs.reduce((a,v)=>a+(v.km||0),0);return totalKm-(s.startKm||0)>=500},
    prog:(s)=>{const totalKm=G.vehs.reduce((a,v)=>a+(v.km||0),0);return[Math.round(totalKm-(s.startKm||0)),500]}},
];

function initQuests(){
  if(!G.quests) G.quests={tutorial:{},levelMissions:{},dailies:null,weeklies:null,dailyTs:0,weeklyTs:0};
  if(!G.quests.levelMissions) G.quests.levelMissions={};
}

function pickN(pool,n){
  const shuffled=[...pool].sort(()=>Math.random()-.5);
  const totalKm=G.vehs.reduce((a,v)=>a+(v.km||0),0);
  return shuffled.slice(0,n).map(q=>({
    ...q,done:false,claimed:false,
    startDels:G.dels,startEarned:G.earned,startCities:cities.length,
    startBlds:Object.values(G.blds).flat().length,
    startVehs:G.vehs.length,startKm:totalKm,
    startUpgrades:(()=>{let t=0;Object.values(G.blds).flat().forEach(b=>{if(b.ups)Object.values(b.ups).forEach(l=>t+=l)});return t})()
  }));
}

function refreshDailies(){
  const now=Date.now();
  if(!G.quests.dailies||now-G.quests.dailyTs>24*60*60*1000){
    G.quests.dailies=pickN(DAILY_POOL,3);
    G.quests.dailyTs=now;
    addLog('📅 Neue Tagesmissionen verfügbar!');
  }
}

function refreshWeeklies(){
  const now=Date.now();
  if(!G.quests.weeklies||now-G.quests.weeklyTs>7*24*60*60*1000){
    G.quests.weeklies=pickN(WEEKLY_POOL,3);
    G.quests.weeklyTs=now;
    addLog('📆 Neue Wochenmissionen verfügbar!');
  }
}

function checkQuests(){
  if(!G||!G.quests)return;
  // Tutorial
  TUTORIAL.forEach(q=>{
    if(!G.quests.tutorial[q.id]&&q.check()) G.quests.tutorial[q.id]='done';
  });
  // Level missions
  if(!G.quests.levelMissions)G.quests.levelMissions={};
  const lvl=playerLvl();
  LEVEL_MISSIONS.forEach(q=>{
    if(q.minLvl<=lvl&&!G.quests.levelMissions[q.id]&&q.check()) G.quests.levelMissions[q.id]='done';
  });
  // Dailies
  if(G.quests.dailies){
    G.quests.dailies.forEach(q=>{
      if(!q.done&&!q.claimed){
        const def=DAILY_POOL.find(d=>d.id===q.id);
        if(def&&def.check(q))q.done=true;
      }
    });
  }
  // Weeklies
  if(G.quests.weeklies){
    G.quests.weeklies.forEach(q=>{
      if(!q.done&&!q.claimed){
        const def=WEEKLY_POOL.find(w=>w.id===q.id);
        if(def&&def.check(q))q.done=true;
      }
    });
  }
}

function claimTutorial(qid){
  if(!G||!G.quests)return;
  if(G.quests.tutorial[qid]!=='done')return;
  const q=TUTORIAL.find(x=>x.id===qid);if(!q)return;
  G.money+=q.reward;G.quests.tutorial[qid]='claimed';
  addLog('🎁 Tutorial: +'+fmt(q.reward)+' ('+q.name+')');ua();
}

function claimLevelMission(qid){
  if(!G||!G.quests||!G.quests.levelMissions)return;
  if(G.quests.levelMissions[qid]!=='done')return;
  const q=LEVEL_MISSIONS.find(x=>x.id===qid);if(!q)return;
  G.money+=q.reward;G.quests.levelMissions[qid]='claimed';
  addLog('🎁 Level-Mission: +'+fmt(q.reward)+' ('+q.name+')');ua();
}

function claimDaily(idx){
  if(!G||!G.quests||!G.quests.dailies)return;
  const q=G.quests.dailies[idx];if(!q||!q.done||q.claimed)return;
  G.money+=q.reward;q.claimed=true;
  addLog('🎁 Tagesbelohnung: +'+fmt(q.reward)+' ('+q.name+')');ua();
}

function claimWeekly(idx){
  if(!G||!G.quests||!G.quests.weeklies)return;
  const q=G.quests.weeklies[idx];if(!q||!q.done||q.claimed)return;
  G.money+=q.reward;q.claimed=true;
  addLog('🎁 Wochenbelohnung: +'+fmt(q.reward)+' ('+q.name+')');ua();
}

function questBadgeCount(){
  if(!G||!G.quests)return 0;
  let n=0;
  TUTORIAL.forEach(q=>{if(G.quests.tutorial[q.id]==='done')n++});
  LEVEL_MISSIONS.forEach(q=>{if(G.quests.levelMissions&&G.quests.levelMissions[q.id]==='done')n++});
  if(G.quests.dailies)G.quests.dailies.forEach(q=>{if(q.done&&!q.claimed)n++});
  if(G.quests.weeklies)G.quests.weeklies.forEach(q=>{if(q.done&&!q.claimed)n++});
  return n;
}

function timeLeft(ts,dur){
  const left=Math.max(0,(ts+dur)-Date.now());
  const h=Math.floor(left/3600000),m=Math.floor((left%3600000)/60000);
  return h+'h '+m+'m';
}
