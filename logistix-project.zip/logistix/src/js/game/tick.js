// ══════════════════════════════════════════
// GAME TICK v4 – bulletproof production
// ══════════════════════════════════════════

function tickCore(){
  if(!G)return;
  G.tick++;
  if(!G.events)G.events=[];
  if(!G.market)G.market={};
  if(!G.supplyTrack)G.supplyTrack={};
  if(!G.supplyHist)G.supplyHist=[];

  // ── Supply epoch reset every 8h (28800 ticks) ──
  const epoch=Math.floor(G.tick/28800);
  if(!G.lastEpoch)G.lastEpoch=epoch;
  if(epoch>G.lastEpoch){
    // Save old supply data as history
    G.supplyHist.push({epoch:G.lastEpoch,supply:{...G.supplyTrack},tick:G.tick});
    if(G.supplyHist.length>6)G.supplyHist.shift(); // Keep ~48h of history
    // Decay supply tracking (halve instead of reset for smoother transitions)
    Object.keys(G.supplyTrack).forEach(g=>{G.supplyTrack[g]=Math.floor((G.supplyTrack[g]||0)*0.4)});
    G.lastEpoch=epoch;
  }

  // ── Price history (every 5 min, keep last 20 snapshots = ~100 min) ──
  if(G.tick%300===0){
    if(!G.priceHist)G.priceHist=[];
    const myRegs=new Set();cities.forEach(c=>myRegs.add(getRegion((c.co||'').toUpperCase())));
    const snap={tick:G.tick,prices:{}};
    Object.keys(BASE_PRICES).forEach(g=>{snap.prices[g]={};
      [...myRegs].forEach(r=>{snap.prices[g][r]=marketPrice(g,r)})});
    G.priceHist.push(snap);
    if(G.priceHist.length>20)G.priceHist.shift();
  }

  // ── Events: spawn every ~6h (21600 ticks), max 2 active ──
  if(G.tick%3600===0&&activeEvents().length<2&&Math.random()<0.6){
    const pool=EVENTS.filter(e=>!activeEvents().find(a=>a.id===e.id));
    if(pool.length){const ev=pool[Math.floor(Math.random()*pool.length)];
      G.events.push({id:ev.id,startTick:G.tick,endTick:G.tick+ev.dur});
      addLog(ev.icon+' EVENT: '+ev.name+' – '+ev.desc+' ('+ev.dur+'s)')}
  }
  // Clean expired events
  G.events=G.events.filter(e=>e.endTick>G.tick);

  // ── Orders + Express ──
  if(G.tick%60===0){
    if(cities.length>=2&&G.orders.filter(o=>!o.acc).length<10){
      const o=genOrd();if(o)G.orders.push(o);
    }
    G.orders=G.orders.filter(o=>o.acc||(G.tick-o.born<o.tl));
    // Express order every 2-3 min
    if(G.tick%120===0&&G.orders.filter(o=>o.type==='express'&&!o.acc).length<2){
      const eo=genExpressOrder();if(eo)G.orders.push(eo);
    }
  }

  // ── Auto-Manager: auto-accept orders if enabled (Level 5+) ──
  if(G.autoManager&&playerLvl()>=5&&G.tick%10===0){
    G.orders.filter(o=>!o.acc&&o.type!=='express').forEach(o=>{
      const avl=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from&&canVehTravel(v,o.to));
      const inS=G.stor[o.from]?.[o.good]||0;
      if(inS>=o.amt&&avl.length){o.acc=true;autoAssign(o.id)}
    });
  }

  // ── Vehicle maintenance is now km-based (checked on arrival) ──

  // ══ PRODUCTION ══
  try{
    Object.keys(G.blds).forEach(cid=>{
      const bs=G.blds[cid];if(!bs||!bs.length)return;
      if(!G.stor[cid])G.stor[cid]={};
      const stor=G.stor[cid];

      // City storage capacity
      let cc=cityCap(cid);
      
      const cityUsed=()=>{let t=0;for(const k in stor)t+=stor[k];return t};

      for(let bi=0;bi<bs.length;bi++){
        const b=bs[bi];
        const d=BLD[b.type];
        if(!d||d.tp==='s')continue;

        // Init
        if(!b.localStor)b.localStor={};
        if(b.overflow===undefined)b.overflow='city';
        if(typeof b._pt!=='number')b._pt=0;

        // Increment counter
        b._pt++;
        const interval=bldTickInterval(b);
        if(b._pt<interval)continue;
        b._pt=0;

        // Storage helpers
        const lCap=bldLocalCap(b);
        const lUsed=()=>{let t=0;for(const k in b.localStor)t+=b.localStor[k];return t};

        const canProduce=()=>lUsed()<lCap||(b.overflow==='city'&&cityUsed()<cc);

        const store=(good,amt)=>{
          if(!GOODS[good])return;
          const lu=lUsed();
          if(lu<lCap){
            const toLocal=Math.min(amt,lCap-lu);
            b.localStor[good]=(b.localStor[good]||0)+toLocal;
            const rest=amt-toLocal;
            if(rest>0&&b.overflow==='city'&&cityUsed()<cc){
              stor[good]=(stor[good]||0)+rest;
            }
          } else if(b.overflow==='city'&&cityUsed()<cc){
            stor[good]=(stor[good]||0)+amt;
          }
        };

        if(!canProduce())continue;

        // ── Farm: getreide + animals ──
        if(d.tp==='farm'){
          const outMult=bUp(b,'prod_out')+1;
          store(d.prod, d.rate*outMult);
          if(b.animals){
            for(const aKey in b.animals){
              const cnt=b.animals[aKey];
              const animal=ANIMALS[aKey];
              if(!animal||cnt<=0)continue;
              for(let ai=0;ai<animal.produces.length;ai++){
                const p=animal.produces[ai];
                if(canProduce())store(p.good, p.rate*cnt*outMult);
              }
            }
          }
          continue;
        }

        // ── Orchard: selected fruits ──
        if(d.tp==='orchard'){
          if(b.fruits){
            const outMult=bUp(b,'prod_out')+1;
            for(const fKey in b.fruits){
              const cnt=b.fruits[fKey];
              const fruit=FRUITS[fKey];
              if(!fruit||cnt<=0)continue;
              if(canProduce())store(fruit.good, d.rate*cnt*outMult);
            }
          }
          continue;
        }

        // ── Recipe factory: process ALL active recipes, split output ──
        if(d.tp==='recipe'){
          const pool=RECIPES[d.recipes];if(!pool)continue;
          const activeIds=(b.activeRecipes||[b.recipe].filter(Boolean)).filter(rid=>pool.find(r=>r.id===rid));
          if(!activeIds.length)continue;
          const effM=[1,.8,.65,.5];
          const eff=effM[bUp(b,'fac_eff')]||1;
          const outMult=bUp(b,'fac_out')+1;
          const split=activeIds.length; // 1=100%, 2=50%, 3=33%
          for(let ri=0;ri<activeIds.length;ri++){
            const recipe=pool.find(r=>r.id===activeIds[ri]);
            if(!recipe)continue;
            if(!canProduce())break;
            // Scale input needs by split (each recipe uses proportional resources)
            const need1=Math.max(1,Math.ceil(recipe.in1N*eff/split));
            const has1=(stor[recipe.in1]||0)>=need1;
            const need2=recipe.in2?Math.max(1,Math.ceil(recipe.in2N*eff/split)):0;
            const has2=!recipe.in2||(stor[recipe.in2]||0)>=need2;
            if(has1&&has2){
              stor[recipe.in1]-=need1;if(stor[recipe.in1]<=0)delete stor[recipe.in1];
              if(recipe.in2){stor[recipe.in2]-=need2;if(stor[recipe.in2]<=0)delete stor[recipe.in2]}
              const outAmt=Math.max(1,Math.round(recipe.outR*outMult/split));
              store(recipe.out, outAmt);
            }
          }
          continue;
        }

        // ── Simple production/processing ──
        if(d.inp){
          const effM=[1,.8,.65,.5];const eff=effM[bUp(b,'fac_eff')]||1;
          const need=Math.max(1,Math.ceil(d.inpN*eff));
          const need2=d.inp2?Math.max(1,Math.ceil(d.inpN2*eff)):0;
          if((stor[d.inp]||0)>=need&&(!d.inp2||(stor[d.inp2]||0)>=need2)){
            stor[d.inp]-=need;if(stor[d.inp]<=0)delete stor[d.inp];
            if(d.inp2){stor[d.inp2]-=need2;if(stor[d.inp2]<=0)delete stor[d.inp2]}
            store(d.prod, d.rate*(bUp(b,'fac_out')+1));
          }
        } else {
          store(d.prod, d.rate*(bUp(b,'prod_out')+1));
        }
      }
    });
  }catch(e){console.error('PRODUCTION ERROR:',e)}

  // ══ VEHICLE MOVEMENT (with event effects) ══
  try{
    const seaSpd=eventEffect('seaSpeed')||1;
    const landSpd=eventEffect('landSpeed')||1;
    const railStop=eventEffect('railStop');
    for(let vi=0;vi<G.vehs.length;vi++){
      const v=G.vehs[vi];
      if(v.st!=='moving'||!v.rt)continue;
      const vt=VT[v.type],f=C(v.rt.from)||Cx(v.rt.from),t=C(v.rt.to)||Cx(v.rt.to)||(v.rt.toLat?{lat:v.rt.toLat,lng:v.rt.toLng,name:v.rt.toName||'?'}:null);
      if(!f||!t)continue;
      // Apply speed modifiers from events + maintenance
      let spdMult=1;
      if(vt.cat==='sea')spdMult=seaSpd;
      else if(vt.cat==='land')spdMult=landSpd;
      else if(vt.cat==='rail'&&railStop){continue} // Trains stopped
      if(v.needsMaint)spdMult*=0.8; // 20% slower when needs maintenance
      const tn=v.rt.tripTime||tripT(f,t,vt.spd*spdMult);
      v.prog++;
      if(v.prog>=tn){
        // Arrived
        if(v.cargo&&v.cargo.oid){
          const o=G.orders.find(x=>x.id===v.cargo.oid);
          if(o){
            // Track delivered amount
            if(!o.delivered)o.delivered=0;
            o.delivered+=v.cargo.amt;
            if(o.delivered>=o.amt){
              // Order complete!
              G.money+=o.rew;G.earned+=o.rew;G.dels++;trackSupply(o.good,o.amt);
              if(!G.history)G.history=[];
              G.history.push({good:o.good,amt:o.amt,rew:o.rew,from:o.from,to:o.to,tick:G.tick,ts:Date.now(),express:o.type==='express',toName:o.toName||''});
              if(G.history.length>200)G.history.shift();
              addLog('✅ '+(GOODS[o.good]?.em||'')+o.amt+'×→'+t.name+' +'+fmt(o.rew));
              G.orders=G.orders.filter(x=>x.id!==o.id);
            } else {
              trackSupply(o.good,v.cargo.amt);addLog('📦 Teillieferung '+(GOODS[o.good]?.em||'')+v.cargo.amt+'× ('+o.delivered+'/'+o.amt+')');
            }
          }
        } else if(v.cargo&&v.cargo.allianceDelivery){
          // Alliance delivery
          if(!v.cargo.returning){
            // Arrived at hub — add to alliance storage
            const aId=v.cargo.allianceId;
            if(aId){(async()=>{try{const al=await getAlliance(aId);if(al){al.storage[v.cargo.good]=(al.storage[v.cargo.good]||0)+v.cargo.amt;await saveAlliance(al)}}catch(e){}})()}
            addLog('🤝 Allianz-Lieferung: '+(GOODS[v.cargo.good]?.em||'')+v.cargo.amt+'× angekommen');
            const retTo=v.cargo.returnTo||v.rt.from;
            v.st='moving';v.rt={from:v.rt.to||v.rt.from,to:retTo,toLat:C(retTo)?.lat,toLng:C(retTo)?.lng,toName:C(retTo)?.name||'Depot'};
            v.cargo={allianceDelivery:true,returning:true};v.prog=0;
            if(typeof ensureRoute==='function')ensureRoute(v);
            continue;
          } else {
            addLog('🔙 Fahrzeug zurück von Allianzlieferung');
          }
        } else if(v.cargo&&v.cargo.market){
          // Market sale
          if(!v.cargo.returning){
            // First leg done: complete sale, start return
            const profit=v.cargo.revenue||0;
            G.money+=profit;G.earned+=profit;G.dels++;trackSupply(v.cargo.good,v.cargo.amt);
            if(!G.history)G.history=[];
            G.history.push({good:v.cargo.good,amt:v.cargo.amt,rew:profit,from:v.rt.from,to:'market_'+v.cargo.destName,tick:G.tick,ts:Date.now()});
            addLog('💰 Marktverkauf: +'+fmt(profit)+' ('+v.cargo.destName+')');
            // Return trip
            const returnTo=v.cargo.returnTo||v.rt.from;
            v.st='moving';v.rt={from:v.rt.to,to:returnTo,toLat:C(returnTo)?.lat,toLng:C(returnTo)?.lng,toName:C(returnTo)?.name||'Depot'};
            v.cargo={market:true,returning:true};v.prog=0;
            if(typeof ensureRoute==='function')ensureRoute(v);
            continue; // Don't idle yet
          } else {
            // Return trip done
            addLog('🔙 Fahrzeug zurück von Marktfahrt');
          }
        } else if(v.cargo&&v.cargo.internal){
          if(!G.stor[v.rt.to])G.stor[v.rt.to]={};
          G.stor[v.rt.to][v.cargo.good]=(G.stor[v.rt.to][v.cargo.good]||0)+v.cargo.amt;
          addLog('📦 '+v.cargo.amt+'× '+(GOODS[v.cargo.good]?.em||'')+' → '+t.name);
        }
        v.st='idle';v.loc=v.rt.to||v.rt.from;
        // Track kilometers
        if(typeof v.km!=='number')v.km=0;
        v.km+=Math.round(hav(f.lat,f.lng,t.lat,t.lng));
        // Market/alliance trips return to origin
        if(v.cargo&&(v.cargo.market||v.cargo.allianceDelivery)){v.loc=v.rt.to||v.rt.from||v.loc}
        v.cargo=null;
        // Check if arrived at non-unlocked city → go to nearest unlocked
        if(!cities.find(c=>c.id===v.loc)){
          const nearest=cities.reduce((best,c)=>{const d=hav(f.lat,f.lng,c.lat,c.lng);return(!best||d<best.d)?{id:c.id,d}:best},null);
          if(nearest){v.st='moving';v.rt={from:v.loc,to:nearest.id};v.prog=0;
            addLog('🔄 '+vehName(v)+' kehrt zurück → '+(C(nearest.id)?.name||''));}
        }
        v.rt=null;v.prog=0;
        // Maintenance check based on km
        const vt2=VT[v.type];if(vt2){
          const maintKm2={land:10000,rail:25000,sea:50000,air:15000}[vt2.cat]||10000;
          if((v.km||0)-(v.lastMaintKm||0)>=maintKm2){v.needsMaint=true;addLog('⚠ '+vehName(v)+' braucht Wartung!')}}
        // Recall to depot after order completion
        if(v.st==='idle'&&v.recallToDepot&&v.depot&&v.loc!==v.depot){
          v.st='moving';v.rt={from:v.loc,to:v.depot};v.prog=0;v.cargo=null;
          v.recallToDepot=false;
          if(typeof ensureRoute==='function')ensureRoute(v);
          addLog('🔙 '+vehName(v)+' kehrt zum Depot zurück → '+(C(v.depot)?.name||''));
          continue;
        }
        if(v.recallToDepot&&v.st==='idle'&&v.loc===v.depot)v.recallToDepot=false;
        // Follow-up order
        if(v.followUpOrder){
          const fuo=G.orders.find(x=>x.id===v.followUpOrder&&x.acc);
          if(fuo&&v.loc===fuo.from){
            const avail=G.stor[fuo.from]?.[fuo.good]||0;
            const canLoad=Math.min(fuo.amt-(fuo.shipped||0),avail,vehCap(v));
            if(canLoad>0){
              G.stor[fuo.from][fuo.good]-=canLoad;if(G.stor[fuo.from][fuo.good]<=0)delete G.stor[fuo.from][fuo.good];
              if(!fuo.shipped)fuo.shipped=0;fuo.shipped+=canLoad;
              v.st='moving';v.rt={from:fuo.from,to:fuo.to};v.cargo={oid:fuo.id,good:fuo.good,amt:canLoad};v.prog=0;
              if(typeof ensureRoute==='function')ensureRoute(v);
              addLog('📋 Folgeauftrag: '+(GOODS[fuo.good]?.em||'')+canLoad+'× → '+(C(fuo.to)?.name||''));
            }
          }
          v.followUpOrder=null;
        }
        // Post-delivery destination
        if(v.st==='idle'&&v.postDelivery&&typeof canVehTravel==='function'&&canVehTravel(v,v.postDelivery)&&v.loc!==v.postDelivery){
          v.st='moving';v.rt={from:v.loc,to:v.postDelivery};v.prog=0;
          if(typeof ensureRoute==='function')ensureRoute(v);
          v.postDelivery=null;
        } else if(v.st==='idle'&&v.queue&&v.queue.length){
          v.queue.shift();
          if(v.queue.length&&typeof startNextRoute==='function')startNextRoute(v);
        }
        // Auto-return: if idle at a city we don't own, go to nearest owned city
        if(v.st==='idle'&&!cities.find(c2=>c2.id===v.loc)){
          let nearest=null,nd=Infinity;
          const here=C(v.loc)||{lat:0,lng:0};
          cities.forEach(c2=>{const d2=hav(here.lat,here.lng,c2.lat,c2.lng);if(d2<nd&&canVehTravel(v,c2.id)){nd=d2;nearest=c2}});
          if(nearest){v.st='moving';v.rt={from:v.loc,to:nearest.id};v.prog=0;
            if(typeof ensureRoute==='function')ensureRoute(v);
            addLog('🔙 '+VT[v.type].em+' → '+nearest.name+' (nächster Standort)');}
        }
      }
    }
  }catch(e){console.error('VEHICLE ERROR:',e)}

  // Maintenance (every 10min)
  if(G.tick%600===0){
    const c=G.vehs.reduce((s,v)=>s+(VT[v.type]?.mt||0),0);
    if(c>0){G.money-=c;addLog('🔧 Wartung: '+fmt(c))}
  }

  // Quests
  if(G.tick%5===0){
    try{initQuests();refreshDailies();refreshWeeklies();checkQuests()}catch(e){}
  }

  // Standing orders (every 60s)
  if(G.tick%60===0&&G.standingOrders){
    try{
      G.standingOrders.forEach(so=>{
        // Auto-resume check: if auto-paused and dest now has space, resume
        if(so.autoPaused&&!so.active){
          const destStor=G.stor[so.to]||{};const destTot=Object.values(destStor).reduce((a,v)=>a+v,0);
          const destCap=cityCap(so.to);
          if(destTot<destCap*0.9){so.active=true;so.autoPaused=false;addLog('🔄 Dauerauftrag fortgesetzt: '+(GOODS[so.good]?.em||''))}
        }
        if(!so.active)return;
        // Check destination capacity
        const destStor=G.stor[so.to]||{};const destTot=Object.values(destStor).reduce((a,v)=>a+v,0);
        const destCap=cityCap(so.to);
        if(destTot>=destCap){so.active=false;so.autoPaused=true;addLog('⚠️ Dauerauftrag pausiert: Lager in '+(C(so.to)?.name||'?')+' voll');return}
        // Find and send vehicles
        const s=G.stor[so.from];if(!s||(s[so.good]||0)<1)return;
        const vids=so.vehicleIds||(so.vehicleId?[so.vehicleId]:[]);
        const candidates=vids.length
          ?G.vehs.filter(x=>vids.includes(x.id)&&x.st==='idle'&&x.loc===so.from)
          :[G.vehs.find(x=>x.st==='idle'&&x.loc===so.from&&(typeof canVehTravel!=='function'||canVehTravel(x,so.to)))].filter(Boolean);
        candidates.forEach(v=>{
          if((s[so.good]||0)<1)return;
          let loadAmt;
          if(so.fillMode){loadAmt=Math.min(s[so.good]||0,vehCap(v))}
          else{loadAmt=Math.min(so.amt,s[so.good]||0,vehCap(v))}
          if(loadAmt<=0)return;
          s[so.good]-=loadAmt;if(s[so.good]<=0)delete s[so.good];
          v.st='moving';v.rt={from:so.from,to:so.to};
          v.cargo={internal:true,good:so.good,amt:loadAmt};v.prog=0;
          v.postDelivery=so.from;
          if(typeof ensureRoute==='function')ensureRoute(v);
        });
      });
    }catch(e){}
  }

  // Auto-transfer Gebäudekapazität → city storage (every 10s)
  if(G.tick%10===0){
    try{
      Object.keys(G.blds).forEach(cid=>{
        const bs=G.blds[cid];if(!bs)return;
        if(!G.stor[cid])G.stor[cid]={};
        const stor=G.stor[cid];
        let cc=cityCap(cid);
        
        const cityUsed=()=>{let t=0;for(const k in stor)t+=stor[k];return t};

        for(let i=0;i<bs.length;i++){
          const b=bs[i];
          if(!b.localStor)continue;
          for(const g in b.localStor){
            const a=b.localStor[g];
            if(a>0&&cityUsed()<cc){
              const mv=Math.min(a,cc-cityUsed());
              stor[g]=(stor[g]||0)+mv;
              b.localStor[g]-=mv;
              if(b.localStor[g]<=0)delete b.localStor[g];
            }
          }
        }
      });
    }catch(e){}
  }
}

let tc=0;let renderBlocked=false;
document.addEventListener('focusin',e=>{if(e.target.tagName==='SELECT'||e.target.tagName==='INPUT'||e.target.type==='checkbox')renderBlocked=true});
document.addEventListener('focusout',e=>{setTimeout(()=>{renderBlocked=false},200)});
function tick(){
  if(!gameStarted||!G)return;
  try{tickCore()}catch(e){console.error('TICK ERROR:',e)}
  tc++;
  if(tc%2===0){try{uhud()}catch(e){}}
  // Only re-render dashboard on tick, not terminal (terminal re-renders on ua())
  if(tc%2===0&&!renderBlocked){try{if(computerOpen)renComp();else ren()}catch(e){}}
  if(tc%3===0){try{uvmk()}catch(e){}}
  if(tc%5===0)try{uvmk()}catch(e){}
  if(tc%30===0)try{markDirty()}catch(e){}
}
