// ══════════════════════════════════════════
// PLAYER ACTIONS (with Route Queue)
// ══════════════════════════════════════════

function sel(id){if(!G)return;G.sel=id;udots();if(typeof updateMinimap==='function')updateMinimap();ren();const c=C(id);if(c&&!computerOpen)MP&&MP.flyTo([c.lat,c.lng],Math.max(MP.getZoom(),9),{duration:.5})}
// ── Vehicle infrastructure check ──
function cityHasInfra(cid,type){if(!G||!G.infra)return false;return(G.infra[cid]||[]).some(i=>i.type===type)}
function canBuyVehAt(vtype,cid){
  const d=VT[vtype];if(!d)return false;
  if(d.cat==='rail'&&!cityHasInfra(cid,'bahnhof'))return false;
  if(d.cat==='sea'&&!cityHasInfra(cid,'hafen'))return false;
  if(d.cat==='air'&&!cityHasInfra(cid,'flughafen'))return false;
  return true;
}
function canVehTravel(v,toCid){
  const vt=VT[v.type];if(!vt)return false;
  if(vt.cat==='rail')return cityHasInfra(toCid,'bahnhof');
  if(vt.cat==='sea')return cityHasInfra(toCid,'hafen');
  if(vt.cat==='air')return cityHasInfra(toCid,'flughafen');
  return true; // land vehicles go anywhere
}
function reachableCities(v){return cities.filter(c=>canVehTravel(v,c.id))}
function reachableExcept(v,excId){return cities.filter(c=>c.id!==excId&&canVehTravel(v,c.id))}

function buyV(type){
  if(!G)return;const d=VT[type];if(!d||G.money<d.price)return;
  const loc=G.sel||cities[0]?.id;
  if(!canBuyVehAt(type,loc)){addLog('❌ Infrastruktur fehlt!');return}
  const vAtDepot=G.vehs.filter(v=>(v.depot||v.loc)===loc).length;
  const cap=depotCap(loc);
  if(vAtDepot>=cap){addLog('❌ Depot voll! ('+vAtDepot+'/'+cap+') – Depot ausbauen');return}
  G.money-=d.price;const v={id:uid(),type,st:'idle',loc,depot:loc,cargo:null,rt:null,prog:0,queue:[],km:0,lastMaintKm:0};
  if(type==='gueterzug')v.wagons=0;
  G.vehs.push(v);addLog(d.em+' '+vehName(v)+' gekauft in '+(C(loc)?.name||''));ua();
}

// ═══ MARKET SELL: Popup + vehicle drives to market city ═══
function showMarketSellPopup(cid,good){
  if(!G)return;const c=C(cid);if(!c)return;
  const stor=G.stor[cid];const stock=(stor&&stor[good])||0;if(!stock)return;
  const reg=getRegion((c.co||'').toUpperCase());const ri=REGIONS[reg];
  // Pick destination
  const allDB=typeof DB!=='undefined'?DB:[];
  const regCities=allDB.filter(x=>getRegion(x[1])===reg&&x[0]!==c.name);
  if(!regCities.length){addLog('❌ Kein Marktplatz in Region');return}
  const destPick=regCities[Math.floor(Math.random()*regCities.length)];
  const dest={name:destPick[0],co:destPick[1],lat:destPick[3],lng:destPick[4]};
  const dist=Math.round(hav(c.lat,c.lng,dest.lat,dest.lng));
  // Available vehicles
  const vehs=G.vehs.filter(v=>v.st==='idle'&&v.loc===cid);
  const maxCap=vehs.reduce((s,v)=>s+vehCap(v),0);
  const maxAmt=Math.min(stock,maxCap);
  // Price
  let price=marketPrice(good,reg);
  const gm=eventEffect('globalMult')||1;price=Math.round(price*gm);
  const inf=G.infra[cid]||[];if(inf.find(i=>i.type==='logistikzentrum'))price=Math.round(price*1.15);

  let existing=document.getElementById('mktPopup');if(existing)existing.remove();
  const popup=document.createElement('div');popup.id='mktPopup';popup.className='unlock-bg';
  let h='<div class="unlock-popup" style="width:420px;max-height:85vh;overflow-y:auto"><div class="unlock-body">';
  h+='<div style="text-align:center;margin-bottom:12px"><span style="font-size:24px">💰</span>';
  h+='<div style="font-family:var(--mono);font-size:16px;font-weight:700;color:var(--a);margin-top:4px">Marktverkauf</div></div>';
  h+='<div class="crd"><div class="rw"><span>'+(GOODS[good]?.em||'')+' <b>'+(GOODS[good]?.name||good)+'</b></span>';
  h+='<span style="font-family:var(--mono);color:var(--a)">'+price.toLocaleString('de-DE')+'/St.</span></div>';
  h+='<div class="sub">Bestand: '+stock+' · Max. Kapazität: '+maxAmt+'</div></div>';
  // Destination
  h+='<div class="crd"><div class="rw"><span>📍 '+c.name+' → 🏪 '+dest.name+'</span>';
  h+='<span class="sub">'+dist+' km</span></div>';
  h+='<div class="sub">'+(ri?.em||'')+' '+(ri?.name||'')+'</div></div>';
  // Vehicles
  if(!vehs.length){h+='<div style="padding:12px;text-align:center;color:var(--r)">❌ Kein Fahrzeug am Standort</div>';
    h+='<button class="btn full" onclick="document.getElementById(\'mktPopup\').remove()">Schließen</button>';
    h+='</div></div>';popup.innerHTML=h;popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});document.body.appendChild(popup);return}
  h+='<div class="sec-label">Fahrzeuge · 🚛'+vehs.length+'</div>';
  vehs.slice(0,5).forEach(v=>{const vt=VT[v.type];h+='<div class="sub">'+vt.em+' '+vehName(v)+' · Kap: '+vehCap(v)+'</div>'});
  // Quantity
  h+='<div class="sec-label">Menge</div>';
  h+='<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">';
  h+='<input type="range" id="mktAmt" min="1" max="'+maxAmt+'" value="'+maxAmt+'" style="flex:1;accent-color:var(--a)" oninput="updMktCalc()">';
  h+='<input type="number" id="mktAmtN" min="1" max="'+maxAmt+'" value="'+maxAmt+'" style="width:60px;padding:4px 6px;border-radius:6px;border:1px solid var(--bd);background:rgba(255,255,255,.05);color:var(--t);font-family:var(--mono);font-size:13px;text-align:center" oninput="document.getElementById(\'mktAmt\').value=this.value;updMktCalc()">';
  h+='</div>';
  // Price breakdown (updated dynamically)
  h+='<div id="mktCalc" class="crd" style="font-family:var(--mono);font-size:12px"></div>';
  // Buttons
  h+='<div style="display:flex;gap:8px;margin-top:12px">';
  h+='<button class="btn full" style="background:rgba(251,191,36,.1);color:var(--go);border-color:rgba(251,191,36,.3)" onclick="execMarketSell(\''+cid+'\',\''+good+'\',\''+dest.name+'\','+dest.lat+','+dest.lng+','+price+','+dist+')">💰 Verkaufen</button>';
  h+='<button class="btn full" onclick="document.getElementById(\'mktPopup\').remove()">Abbrechen</button>';
  h+='</div></div></div>';
  popup.innerHTML=h;
  popup.addEventListener('click',e=>{if(e.target===popup)popup.remove()});
  document.body.appendChild(popup);
  // Store price for calc
  window._mktPrice=price;window._mktDist=dist;window._mktMaxAmt=maxAmt;
  updMktCalc();
}
function updMktCalc(){
  const el=document.getElementById('mktCalc');if(!el)return;
  const amt=parseInt(document.getElementById('mktAmt')?.value||1);
  document.getElementById('mktAmtN').value=amt;
  const price=window._mktPrice||100;const dist=window._mktDist||50;
  const revenue=price*amt;const transport=Math.round(dist*0.8+amt*3);
  const profit=revenue-transport;
  el.innerHTML='<div class="rw"><span>Erlös</span><span style="color:var(--a)">'+fmt(revenue)+'</span></div>'+
    '<div class="rw"><span>Transport (~'+dist+' km)</span><span style="color:var(--r)">-'+fmt(transport)+'</span></div>'+
    '<div style="border-top:1px solid var(--bd);padding-top:4px;margin-top:4px" class="rw"><span style="font-weight:700">Gewinn</span><span style="color:'+(profit>0?'var(--a)':'var(--r)')+';font-weight:700">'+fmt(profit)+'</span></div>';
}
function execMarketSell(cid,good,destName,destLat,destLng,price,dist){
  if(!G)return;const stor=G.stor[cid];if(!stor)return;
  const amt=parseInt(document.getElementById('mktAmt')?.value||1);
  if((stor[good]||0)<amt){addLog('❌ Nicht genug Ware');return}
  const c=C(cid);if(!c)return;
  // Select vehicles greedily
  const vehs=G.vehs.filter(v=>v.st==='idle'&&v.loc===cid).sort((a,b)=>vehCap(b)-vehCap(a));
  let remaining=amt;let sent=0;
  const transport=Math.round(dist*0.8+amt*3);
  const revenue=price*amt;const profit=revenue-transport;
  if(profit<=0){addLog('❌ Transportkosten übersteigen Erlös');return}
  for(const v of vehs){
    if(remaining<=0)break;
    const load=Math.min(remaining,vehCap(v));
    stor[good]-=load;if(stor[good]<=0)delete stor[good];
    remaining-=load;sent+=load;
    const vt=VT[v.type];
    // Route TO destination
    const destId='mkt_'+destName.toLowerCase().replace(/[^a-z0-9]/g,'');
    v.st='moving';v.rt={from:cid,to:destId,toLat:destLat,toLng:destLng,toName:destName};
    v.cargo={market:true,good,amt:load,revenue:Math.round(profit*(load/amt)),destName,returnTo:cid};
    v.prog=0;
    if(typeof ensureRoute==='function')ensureRoute(v);
    addLog('💰 '+vehName(v)+': '+load+'× → '+destName);if(typeof toast==='function')toast('💰 Marktverkauf gestartet: '+load+'× → '+destName);
  }
  if(!G.history)G.history=[];
  document.getElementById('mktPopup')?.remove();ua();
}

// ═══ MAINTENANCE ═══
function doMaintenance(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||v.st!=='idle')return;
  const cost=maintCost(v);
  if(G.money<cost){addLog('❌ Nicht genug Geld für Wartung ('+fmt(cost)+')');return}
  G.money-=cost;v.lastMaintKm=v.km||0;v.needsMaint=false;
  addLog('🔧 Wartung: '+vehName(v)+' · -'+fmt(cost));ua();
}

function recallVehicle(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);
  if(!v||v.st!=='moving')return;
  const from=v.rt?.from;
  if(v.cargo&&v.cargo.oid){
    const o=G.orders.find(x=>x.id===v.cargo.oid);
    if(o){o.shipped=Math.max(0,(o.shipped||0)-v.cargo.amt)}
    if(!G.stor[from])G.stor[from]={};
    G.stor[from][v.cargo.good]=(G.stor[from][v.cargo.good]||0)+v.cargo.amt;
  } else if(v.cargo&&v.cargo.internal){
    if(!G.stor[from])G.stor[from]={};
    G.stor[from][v.cargo.good]=(G.stor[from][v.cargo.good]||0)+v.cargo.amt;
  }
  v.st='idle';v.loc=from;v.rt=null;v.cargo=null;v.prog=0;v.postDelivery=null;
  addLog('🔙 '+vehName(v)+' zurückgerufen → '+(C(from)?.name||''));ua();
}
// Quick recall: send idle vehicle back to its home depot
function quickRecall(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||v.st!=='idle')return;
  const home=v.depot||v.loc;if(v.loc===home)return;
  v.st='moving';v.rt={from:v.loc,to:home};v.prog=0;v.cargo=null;
  if(typeof ensureRoute==='function')ensureRoute(v);
  addLog('🔙 '+vehName(v)+' → '+(C(home)?.name||'Depot'));ua();
}

// ═══ AUTO-MANAGER toggle (Level 5+) ═══
function toggleAutoManager(){
  if(!G)return;
  if(playerLvl()<5){addLog('❌ Auto-Manager erst ab Level 5 verfügbar');return}
  G.autoManager=!G.autoManager;
  addLog(G.autoManager?'🤖 Auto-Manager aktiviert':'🤖 Auto-Manager deaktiviert');ua();
}

// Vehicle condition: based on km since last maintenance
function vehCondition(v){
  if(!G)return 100;
  const vt=VT[v.type];if(!vt)return 100;
  const maintKm={land:10000,rail:25000,sea:50000,air:15000}[vt.cat]||10000;
  const kmSince=(v.km||0)-(v.lastMaintKm||0);
  return Math.max(0,Math.round(100-kmSince/maintKm*100));
}
function maintCost(v){
  const vt=VT[v.type];if(!vt)return 0;
  return Math.round(vt.price*0.08); // 8% of purchase price
}

// Vehicle naming: EU/WEN-01 format
const REG_ABBR={europa:'EU',nordamerika:'NA',suedamerika:'SA',asien:'AS',afrika:'AF',ozeanien:'OZ'};
const VEH_ABBR={kleintransporter:'KT',lieferwagen:'LW',lkw75:'LK',kuehlwagen:'KW',sattelzug:'SZ',tankwagen:'TW',
  gueterzug:'GZ',schnellzug:'IC',kuestenfrachter:'KF',containerschiff:'CS',propeller:'PP',frachtjet:'FJ',
  cargojet:'CJ',doppelstock:'DS',schwertransporter:'ST',superfrachter:'SF',megatransporter:'MT'};
function vehName(v){
  if(!v||!VT[v.type])return'?';
  if(!v.depot)v.depot=v.loc; // auto-assign depot for legacy saves
  const depotC=C(v.depot)||C(v.loc);
  const regKey=depotC?getRegion((depotC.co||'').toUpperCase()):'europa';
  const rAbbr=REG_ABBR[regKey]||'??';
  const cAbbr=depotC?(depotC.name||'???').substring(0,3).toUpperCase():'???';
  const abbr=VEH_ABBR[v.type]||v.type.substring(0,2).toUpperCase();
  const sameType=G.vehs.filter(x=>(x.depot||x.loc)===(v.depot||v.loc)&&x.type===v.type);
  const num=Math.max(1,sameType.indexOf(v)+1);
  return rAbbr+'/'+cAbbr+'-'+abbr+(num<10?'0':'')+num;
}
function sellVehicle(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v)return;
  if(v.st!=='idle'){addLog('❌ Fahrzeug ist unterwegs – erst zurückrufen');return}
  const home=v.depot||v.loc;
  if(v.depot&&v.loc!==v.depot){addLog('❌ Nur im Heimat-Depot verkaufbar. Zurückrufen nach '+(C(v.depot)?.name||'Depot')+'!');return}
  const vt=VT[v.type];if(!vt)return;const refund=Math.floor(vt.price*0.4);
  G.vehs=G.vehs.filter(x=>x.id!==vid);G.money+=refund;
  addLog(vt.em+' '+vt.name+' verkauft → +'+fmt(refund));ua();
}

function upgradeWagon(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||v.type!=='gueterzug')return;
  const lvl=v.wagons||0;if(lvl>=WAGON_UPGRADE.max)return;
  const cost=WAGON_UPGRADE.baseCost*(lvl+1);
  if(G.money<cost){addLog('❌ '+fmt(cost)+' nötig');return}
  G.money-=cost;v.wagons=lvl+1;
  addLog('🚃 +1 Wagon → Kapazität: '+vehCap(v));ua();
}
function bld(cid,type){if(!G)return;const d=BLD[type];if(!d||G.money<d.price)return;if(!canBuildInCity(type,cid)){addLog('❌ Kann hier nicht gebaut werden');return}const c=C(cid);if(!c)return;const ex=G.blds[cid]||[];if(ex.length>=mxB(c.pop))return;G.money-=d.price;if(!G.blds[cid])G.blds[cid]=[];
  const b={type,id:uid(),ups:{},localStor:{},overflow:'city'};
  if(type==='bauernhof')b.animals={};
  if(type==='obstplantage')b.fruits={};
  if(d.tp==='recipe'){const pool=RECIPES[d.recipes];if(pool&&pool.length)b.activeRecipes=pool.map(r=>r.id)}
  G.blds[cid].push(b);addLog('🏗️ '+d.em+' '+d.name+' in '+c.name);ubmk(cid);udots();ua()}

function buyAnimal(cid,bid,animalKey){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b||b.type!=='bauernhof')return;
  const a=ANIMALS[animalKey];if(!a)return;
  if(a.lvl&&a.lvl>playerLvl()){addLog('❌ Benötigt Level '+a.lvl);return}
  if(G.money<a.price){addLog('❌ '+fmt(a.price)+' nötig');return}
  if(!b.animals)b.animals={};
  b.animals[animalKey]=(b.animals[animalKey]||0)+1;
  G.money-=a.price;addLog(a.em+' +1 '+a.name);ua();
}
function sellAnimal(cid,bid,animalKey){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b||!b.animals||!b.animals[animalKey]||b.animals[animalKey]<=0)return;
  const a=ANIMALS[animalKey];if(!a)return;
  b.animals[animalKey]--;if(b.animals[animalKey]<=0)delete b.animals[animalKey];
  const refund=Math.floor(a.price*0.4);G.money+=refund;
  addLog(a.em+' −1 '+a.name+' → +'+fmt(refund));ua();
}

function buyFruit(cid,bid,fruitKey){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b||b.type!=='obstplantage')return;
  const f=FRUITS[fruitKey];if(!f)return;
  if(f.lvl&&f.lvl>playerLvl()){addLog('❌ Benötigt Level '+f.lvl);return}
  if(G.money<f.price){addLog('❌ '+fmt(f.price)+' nötig');return}
  if(!b.fruits)b.fruits={};
  b.fruits[fruitKey]=(b.fruits[fruitKey]||0)+1;
  G.money-=f.price;addLog(f.em+' +1 '+f.name);ua();
}
function sellFruit(cid,bid,fruitKey){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b||!b.fruits||!b.fruits[fruitKey]||b.fruits[fruitKey]<=0)return;
  const f=FRUITS[fruitKey];if(!f)return;
  b.fruits[fruitKey]--;if(b.fruits[fruitKey]<=0)delete b.fruits[fruitKey];
  const refund=Math.floor(f.price*0.4);G.money+=refund;
  addLog(f.em+' −1 '+f.name+' → +'+fmt(refund));ua();
}

function toggleRecipe(cid,bid,recipeId){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b)return;
  if(!b.activeRecipes)b.activeRecipes=b.recipe?[b.recipe]:[];
  const idx=b.activeRecipes.indexOf(recipeId);
  if(idx>=0){b.activeRecipes.splice(idx,1);addLog('📋 Rezept deaktiviert: '+recipeId)}
  else{b.activeRecipes.push(recipeId);addLog('📋 Rezept aktiviert: '+recipeId)}
  ua();
}

function toggleOverflow(cid,bid){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b)return;
  b.overflow=b.overflow==='city'?'stop':'city';
  addLog(b.overflow==='city'?'📦 Überlauf → Stadtlager':'⛔ Produktion stoppt bei vollem Gebäudekapazität');ua();
}

function collectLocalStor(cid,bid){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b||!b.localStor)return;
  if(!G.stor[cid])G.stor[cid]={};const s=G.stor[cid];let moved=0;
  Object.entries(b.localStor).forEach(([g,a])=>{if(a>0){s[g]=(s[g]||0)+a;moved+=a;delete b.localStor[g]}});
  if(moved)addLog('📦 '+moved+' → Stadtlager');ua();
}

function demolishBld(cid,bid){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const idx=bs.findIndex(x=>x.id===bid);if(idx<0)return;
  const b=bs[idx];const d=BLD[b.type];if(!d)return;
  const refund=Math.floor(d.price*0.3);
  bs.splice(idx,1);
  G.money+=refund;
  addLog('🔨 '+d.em+' '+d.name+' abgerissen → +'+fmt(refund));
  ubmk(cid);udots();ua();
}

// ── Internal transport: load goods onto a vehicle and send ──
function sendGoods(vid,good,amt,toCid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||v.st!=='idle')return;
  const fromCid=v.loc;const s=G.stor[fromCid];
  if(!s||(s[good]||0)<amt){addLog('❌ Nicht genug '+GOODS[good].name);return}
  const cap=vehCap(v);
  if(amt>cap){addLog('❌ Fahrzeug kann nur '+cap+' laden');return}
  // Deduct from storage
  s[good]-=amt;if(s[good]<=0)delete s[good];
  // Send vehicle
  v.st='moving';v.rt={from:fromCid,to:toCid};
  v.cargo={internal:true,good,amt};v.prog=0;
  ensureRoute(v);
  const vt=VT[v.type],f=C(fromCid),t=C(toCid);
  addLog('📦 '+vt.em+' '+amt+'× '+GOODS[good].em+' → '+t?.name);ua();
}

// ── Infrastructure ──
function buildInfra(cid,type){
  if(!G)return;const d=INFRA[type];if(!d||G.money<d.price)return;
  const c=C(cid);if(!c)return;
  if(d.req==='airport'&&!c.airport){addLog('❌ Kein Flughafen-Standort!');return}
  if(d.req==='harbor'&&!c.harbor){addLog('❌ Kein Hafen-Standort!');return}
  if(!G.infra)G.infra={};
  if(!G.infra[cid])G.infra[cid]=[];
  // Non-stackable: check not already built
  if(!d.stack&&G.infra[cid].find(x=>x.type===type)){addLog('❌ Bereits vorhanden!');return}
  G.money-=d.price;
  G.infra[cid].push({type,id:uid()});
  addLog('🏗️ '+d.em+' '+d.name+' in '+c.name+(d.storCap?' (+'+d.storCap+' Lager)':''));ua();
}

// ── Upgrades ──
function upgBld(cid,bid,track){
  if(!G)return;const bs=G.blds[cid];if(!bs)return;
  const b=bs.find(x=>x.id===bid);if(!b)return;
  const upDef=UPGRADES[track];if(!upDef)return;
  if(!b.ups)b.ups={};
  const lvl=b.ups[track]||0;
  if(lvl>=upDef.max)return;
  const cost=upCost(track,lvl);
  if(G.money<cost){addLog('❌ '+fmt(cost)+' nötig');return}
  G.money-=cost;b.ups[track]=lvl+1;
  addLog('⬆️ '+upDef.em+' '+upDef.name+' → Lvl '+(lvl+1));ua();
}

// ── Route Queue ──
function addToRoute(vid,cid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v)return;
  if(!canVehTravel(v,cid)){addLog('❌ Kann dort nicht hin!');return}
  if(!v.queue)v.queue=[];
  v.queue.push({city:cid});
  if(v.st==='idle'&&v.queue.length===1) startNextRoute(v);
  addLog('📍 '+C(cid)?.name+' zur Route');ua();
}

function setPostDelivery(vid,cid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v)return;
  if(cid&&!canVehTravel(v,cid)){addLog('❌ Kann dort nicht hin!');return}
  v.postDelivery=cid||null;v.followUpOrder=null;
  if(cid)addLog('📍 Nach Auftrag → '+C(cid)?.name);ua();
}

function setFollowUpOrder(vid,oid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v)return;
  if(!oid){v.followUpOrder=null;ua();return}
  const o=G.orders.find(x=>x.id===oid&&x.acc);if(!o)return;
  v.followUpOrder=oid;v.postDelivery=o.from;
  const fc=C(o.from);
  addLog('📋 Folgeauftrag: '+(GOODS[o.good]?.em||'')+' → '+(fc?.name||''));ua();
}

function rmFromRoute(vid,idx){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||!v.queue)return;
  v.queue.splice(idx,1);ua();
}

function clearRoute(vid){
  if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v)return;
  v.queue=[];addLog('🗑️ Route gelöscht');ua();
}

function startNextRoute(v){
  if(!v.queue||!v.queue.length)return;
  const next=v.queue[0];
  if(v.loc===next.city){v.queue.shift();startNextRoute(v);return}
  v.st='moving';v.rt={from:v.loc,to:next.city};v.cargo=null;v.prog=0;
  ensureRoute(v);
}

// ── Orders ──
function accO(oid){if(!G)return;const o=G.orders.find(x=>x.id===oid);if(!o)return;
  const s=G.stor[o.from]||{};const avail=s[o.good]||0;
  if(avail<1){addLog('❌ Kein '+GOODS[o.good].name+' in '+(C(o.from)?.name||''));G.orders=G.orders.filter(x=>x.id!==oid);ua();return}
  o.acc=true;o.shipped=0;o.delivered=0;
  if(avail<o.amt)addLog('📋 Angenommen ('+avail+'/'+o.amt+' vorrätig – Teillieferung möglich)');
  else addLog('📋 Angenommen – weise ein Fahrzeug zu!');ua()}
function declineO(oid){if(!G)return;G.orders=G.orders.filter(x=>x.id!==oid);addLog('✖️ Abgelehnt');ua()}
function cancelO(oid){if(!G)return;const o=G.orders.find(x=>x.id===oid);if(!o)return;const v=G.vehs.find(x=>x.cargo&&x.cargo.oid===oid);
  if(v){const rc=v.rt?v.rt.from:v.loc;if(!G.stor[rc])G.stor[rc]={};G.stor[rc][o.good]=(G.stor[rc][o.good]||0)+o.amt;v.st='idle';v.loc=rc;v.cargo=null;v.rt=null;v.prog=0}
  else{if(!G.stor[o.from])G.stor[o.from]={};G.stor[o.from][o.good]=(G.stor[o.from][o.good]||0)+o.amt}
  const penalty=Math.floor(o.rew*0.2);G.money-=penalty;G.orders=G.orders.filter(x=>x.id!==oid);addLog('❌ Storniert (−'+fmt(penalty)+')');ua()}

function shAsgn(oid){if(!G)return;const o=G.orders.find(x=>x.id===oid);if(!o)return;const fc=C(o.from),tc=C(o.to);if(!fc||!tc)return;const avl=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from);document.getElementById('mT').textContent=fc.name+' → '+tc.name;let h='<div class="crd"><div class="rw"><span>'+GOODS[o.good].em+' '+o.amt+'× '+GOODS[o.good].name+'</span><span style="color:var(--a);font-family:Chakra Petch;font-weight:600">'+fmt(o.rew)+'</span></div><div class="sub">'+fdist(fc,tc)+' km</div></div>';if(!avl.length)h+='<div style="color:var(--r);font-size:12px;padding:10px;text-align:center">⚠️ Kein Fahrzeug in '+fc.name+'!<br><span style="color:var(--td);font-size:10px">Sende eines im Fuhrpark-Tab.</span></div>';else avl.forEach(v=>{const vt=VT[v.type],ok=vehCap(v)>=o.amt;h+='<div class="crd'+(ok?' active':'')+'" style="cursor:'+(ok?'pointer':'default')+';'+(ok?'':'opacity:.4')+'" '+(ok?'onclick="asgn(\''+v.id+'\',\''+oid+'\')"':'')+'><div class="rw"><span>'+vt.em+' '+vt.name+'</span><span class="sub">Kap: '+vehCap(v)+' · ⏱'+ftime(tripT(fc,tc,vt.spd))+'</span></div></div>'});document.getElementById('mB').innerHTML=h;document.getElementById('mBg').style.display='flex'}
function closeMdl(){document.getElementById('mBg').style.display='none'}
function asgn(vid,oid){if(!G)return;const o=G.orders.find(x=>x.id===oid),v=G.vehs.find(x=>x.id===vid);if(!o||!v)return;
  const s=G.stor[o.from];if(!s)return;
  // How much is already shipped/loading?
  if(!o.shipped)o.shipped=0;
  const remaining=o.amt-o.shipped;
  const inStor=s[o.good]||0;
  const canLoad=Math.min(remaining,inStor,vehCap(v));
  if(canLoad<=0){addLog('❌ Nichts zu laden');closeMdl();return}
  s[o.good]-=canLoad;if(s[o.good]<=0)delete s[o.good];
  o.shipped+=canLoad;
  v.st='moving';v.rt={from:o.from,to:o.to,toLat:o.toLat,toLng:o.toLng,toName:o.toName};v.cargo={oid:o.id,good:o.good,amt:canLoad};v.prog=0;ensureRoute(v);
  const vt=VT[v.type],f=Cx(o.from),t=Cx(o.to);
  const info=canLoad<remaining?' ('+canLoad+'/'+o.amt+' Teilladung)':'';
  addLog('🚀 '+vt.em+' '+canLoad+'× '+(GOODS[o.good]?.em||'')+' '+f?.name+'→'+t?.name+info);closeMdl();ua()}
function multiAssign(oid){
  if(!G)return;const o=G.orders.find(x=>x.id===oid);if(!o)return;
  const checks=document.querySelectorAll('.vc[data-oid="'+oid+'"]:checked');
  if(!checks.length){addLog('❌ Kein Fahrzeug ausgewählt');return}
  _doMultiAssign(o,Array.from(checks).map(cb=>cb.dataset.vid));
}
function autoAssign(oid){
  if(!G)return;const o=G.orders.find(x=>x.id===oid);if(!o)return;
  if(!o.shipped)o.shipped=0;
  const remaining=o.amt-o.shipped;if(remaining<=0)return;
  const avl=G.vehs.filter(v=>v.st==='idle'&&v.loc===o.from&&canVehTravel(v,o.to)).sort((a,b)=>vehCap(b)-vehCap(a));
  if(!avl.length){addLog('❌ Kein Fahrzeug in '+(C(o.from)?.name||''));return}
  // Pick vehicles greedily until remaining covered
  const picks=[];let cap=0;
  for(const v of avl){if(cap>=remaining)break;picks.push(v.id);cap+=vehCap(v)}
  _doMultiAssign(o,picks);
}
function _doMultiAssign(o,vids){
  const s=G.stor[o.from];if(!s)return;
  if(!o.shipped)o.shipped=0;
  const startShipped=o.shipped;
  let totalLoaded=0,vehCount=0;
  vids.forEach(vid=>{
    const v=G.vehs.find(x=>x.id===vid);
    if(!v||v.st!=='idle')return;
    const remaining=o.amt-startShipped-totalLoaded;
    if(remaining<=0)return;
    const avail=s[o.good]||0;
    const canLoad=Math.min(remaining,avail,vehCap(v));
    if(canLoad<=0)return;
    s[o.good]-=canLoad;if(s[o.good]<=0)delete s[o.good];
    totalLoaded+=canLoad;vehCount++;
    v.st='moving';v.rt={from:o.from,to:o.to,toLat:o.toLat,toLng:o.toLng,toName:o.toName};
    v.cargo={oid:o.id,good:o.good,amt:canLoad};v.prog=0;
    if(typeof ensureRoute==='function')ensureRoute(v);
  });
  o.shipped+=totalLoaded;
  if(totalLoaded>0){
    const f=Cx(o.from),t=Cx(o.to);
    addLog('🚀 '+vehCount+'× · '+totalLoaded+'× '+(GOODS[o.good]?.em||'')+' '+f?.name+'→'+t?.name);
  } else addLog('❌ Nichts geladen');
  ua();
}
function sndV(vid,cid){if(!G)return;const v=G.vehs.find(x=>x.id===vid);if(!v||v.st!=='idle'||v.loc===cid)return;
  if(!canVehTravel(v,cid)){addLog('❌ '+VT[v.type].name+' kann dort nicht hin!');return}
  v.st='moving';v.rt={from:v.loc,to:cid};v.cargo=null;v.prog=0;ensureRoute(v);const vt=VT[v.type],f=C(v.loc),t=C(cid);addLog(vt.em+'→'+t?.name+' ('+ftime(tripT(f,t,vt.spd))+')');ua()}

function goCity(id){sr.classList.remove('open');si.value='';sel(id)}

function assignVehToSO(soId,vid){
  if(!G||!G.standingOrders)return;
  const so=G.standingOrders.find(x=>x.id===soId);if(!so)return;
  so.vehicleId=vid||null;
  if(!so.vehicleIds)so.vehicleIds=[];
  ua();
}

function toggleSOVehicle(soId,vid){
  if(!G||!G.standingOrders)return;
  const so=G.standingOrders.find(x=>x.id===soId);if(!so)return;
  if(!so.vehicleIds)so.vehicleIds=so.vehicleId?[so.vehicleId]:[];
  const idx=so.vehicleIds.indexOf(vid);
  if(idx>=0){so.vehicleIds.splice(idx,1);addLog('🔄 Fahrzeug entfernt')}
  else{so.vehicleIds.push(vid);addLog('🔄 Fahrzeug hinzugefügt')}
  so.vehicleId=so.vehicleIds[0]||null;
  ua();
}

function updateSOAmt(soId,val){
  if(!G||!G.standingOrders)return;
  const so=G.standingOrders.find(x=>x.id===soId);if(!so)return;
  const amt=parseInt(val)||1;
  so.amt=Math.max(1,amt);
  // If has assigned vehicle, cap to its capacity
  if(so.vehicleId&&!so.fillMode){const v=G.vehs.find(x=>x.id===so.vehicleId);if(v)so.amt=Math.min(so.amt,vehCap(v))}
  addLog('🔄 Menge geändert: '+so.amt+'×');
}

function toggleSOFillMode(soId){
  if(!G||!G.standingOrders)return;
  const so=G.standingOrders.find(x=>x.id===soId);if(!so)return;
  so.fillMode=!so.fillMode;
  if(so.fillMode)addLog('🔄 Modus: Voll beladen');
  else addLog('🔄 Modus: Feste Menge ('+so.amt+'×)');
  ua();
}

// ── Sell/close a city ──
function sellCity(cid){
  if(!G)return;const c=C(cid);if(!c)return;
  if(cities.length<=1){addLog('❌ Letzten Standort kann man nicht verkaufen');return}
  // Check no vehicles here
  const vHere=G.vehs.filter(v=>v.loc===cid&&v.st==='idle');
  if(vHere.length){addLog('❌ Erst Fahrzeuge woanders hinschicken!');return}
  if(!confirm(c.name+' schließen? Gebäude werden verkauft (30% Rückerstattung).'))return;
  // Refund buildings
  let refund=0;
  (G.blds[cid]||[]).forEach(b=>{const d=BLD[b.type];if(d)refund+=Math.floor(d.price*0.3)});
  (G.infra&&G.infra[cid]||[]).forEach(i=>{const d=INFRA[i.type];if(d)refund+=Math.floor(d.price*0.3)});
  // Sell stored goods at 50% base price
  Object.entries(G.stor[cid]||{}).forEach(([g,a])=>{if(GOODS[g])refund+=Math.floor(a*GOODS[g].bp*0.5)});
  G.money+=refund;
  delete G.blds[cid];delete G.stor[cid];if(G.infra)delete G.infra[cid];
  // Remove from cities
  const idx=cities.findIndex(x=>x.id===cid);if(idx>=0)cities.splice(idx,1);
  G.unlockedCities=G.unlockedCities.filter(x=>x.id!==cid);
  // Remove map markers
  if(MP){if(cMk[cid]){MP.removeLayer(cMk[cid]);delete cMk[cid]}
  if(cLb[cid]){MP.removeLayer(cLb[cid]);delete cLb[cid]}
  (bMk[cid]||[]).forEach(m=>MP.removeLayer(m));delete bMk[cid]}
  // Select another city
  if(G.sel===cid)G.sel=cities[0]?.id||null;
  addLog('🏙️ '+c.name+' geschlossen → +'+fmt(refund));updCnt();ua();
}

// ── Standing orders (recurring transport between cities) ──
function createStandingOrder(){
  renderBlocked=true;
  const g=document.getElementById('soGood')?.value;
  const a=parseInt(document.getElementById('soAmt')?.value)||0;
  const f=document.getElementById('soFrom')?.value;
  const t=document.getElementById('soTo')?.value;
  renderBlocked=false;
  if(!g||!a||!f||!t||f===t){addLog('❌ Bitte alle Felder ausfüllen');return}
  addStandingOrder(f,t,g,a);
}
function addStandingOrder(fromCid,toCid,good,amt){
  if(!G)return;if(!G.standingOrders)G.standingOrders=[];
  G.standingOrders.push({id:uid(),from:fromCid,to:toCid,good,amt,active:true});
  addLog('🔄 Dauerauftrag: '+(GOODS[good]?.em||'')+amt+'× '+C(fromCid)?.name+' → '+C(toCid)?.name);ua();
}
function removeStandingOrder(soId){
  if(!G||!G.standingOrders)return;
  G.standingOrders=G.standingOrders.filter(x=>x.id!==soId);addLog('🗑️ Dauerauftrag gelöscht');ua();
}
function toggleStandingOrder(soId){
  if(!G||!G.standingOrders)return;
  const so=G.standingOrders.find(x=>x.id===soId);if(!so)return;
  so.active=!so.active;so.autoPaused=false;ua();
}

// ═══ REMOTE ASSIGN: Send vehicle from another city to pick up order ═══
function remoteAssign(vid,oid){
  const v=G.vehs.find(x=>x.id===vid);if(!v||v.st!=='idle')return;
  const o=G.orders.find(x=>x.id===oid);if(!o||!o.acc)return;
  const from=C(o.from);if(!from)return;
  if(v.loc===o.from){autoAssign(oid);return} // Already there
  // Send vehicle to order origin, then auto-assign
  v.st='moving';v.rt={from:v.loc,to:o.from};v.prog=0;
  v.followUpOrder=oid;
  if(typeof ensureRoute==='function')ensureRoute(v);
  const loc=C(v.loc);
  addLog('🚛 '+vehName(v)+' fährt von '+(loc?.name||'?')+' → '+(from?.name||'?')+' für Auftrag '+fmtOrd(o.num));
  if(typeof toast==='function')toast('🚛 '+vehName(v)+' unterwegs zum Abholort');
  ua();
}
