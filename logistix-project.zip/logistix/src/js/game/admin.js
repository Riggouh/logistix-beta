// ══════════════════════════════════════════
// ADMIN PANEL – hidden (Ctrl+Shift+A)
// ══════════════════════════════════════════

let adminOpen=false;
const _adminLog=[];
const ADMIN_MAX_LOG=500;

function adminLog(type,msg,data){
  _adminLog.unshift({ts:Date.now(),type,msg,data:data||null,user:currentUser||'—'});
  if(_adminLog.length>ADMIN_MAX_LOG)_adminLog.pop();
  saveAdminLog();
}

async function saveAdminLog(){
  try{await storeSet('lx_admin_log',JSON.stringify(_adminLog.slice(0,200)))}catch(e){}
}
async function loadAdminLog(){
  try{const r=await storeGet('lx_admin_log');if(r){const d=JSON.parse(r);if(Array.isArray(d))_adminLog.push(...d)}}catch(e){}
}

// Hook into key actions for logging
const _origAddLog=addLog;
addLog=function(m){
  _origAddLog(m);
  adminLog('game',m);
};

// Open admin panel with Ctrl+Shift+A
document.addEventListener('keydown',e=>{
  if(e.ctrlKey&&e.shiftKey&&(e.key==='A'||e.key==='a'||e.code==='KeyA')){e.preventDefault();toggleAdmin()}
});

const ADMIN_PASS='logistix2026';
let adminAuthed=false;

function toggleAdmin(){
  adminOpen=!adminOpen;
  let panel=document.getElementById('adminPanel');
  if(!adminOpen){if(panel)panel.remove();return}
  if(panel)panel.remove();
  panel=document.createElement('div');panel.id='adminPanel';panel.className='admin-bg';
  document.body.appendChild(panel);
  if(!adminAuthed){
    panel.innerHTML='<div class="admin-frame" style="max-width:400px;height:auto"><div class="admin-bar"><span class="admin-title">🔐 Admin-Login</span><button class="admin-close" onclick="toggleAdmin()">✕</button></div><div class="admin-body" style="padding:24px"><input type="password" id="adminPwInput" class="auth-input" placeholder="Admin-Passwort" style="margin-bottom:12px" onkeydown="if(event.key===\'Enter\')adminLogin()"/><button class="btn full" onclick="adminLogin()">Anmelden</button><div id="adminPwErr" style="color:var(--r);text-align:center;margin-top:8px;font-size:13px"></div></div></div>';
    setTimeout(()=>{const inp=document.getElementById('adminPwInput');if(inp)inp.focus()},100);
    return;
  }
  renderAdmin();
}
function adminLogin(){
  const inp=document.getElementById('adminPwInput');if(!inp)return;
  if(inp.value===ADMIN_PASS){adminAuthed=true;renderAdmin()}
  else{const err=document.getElementById('adminPwErr');if(err)err.textContent='❌ Falsches Passwort'}
}

let adminTab='log';
function setAdminTab(t){adminTab=t;renderAdmin()}

async function renderAdmin(){
  const panel=document.getElementById('adminPanel');if(!panel)return;
  const users=await getUsers();
  const userKeys=Object.keys(users);

  let h='<div class="admin-frame">';
  h+='<div class="admin-bar"><span class="admin-title">🔐 LogistiX Admin</span>';
  h+='<div style="display:flex;gap:4px">';
  ['log','players','stats','tools'].forEach(t=>{
    h+='<button class="admin-tab'+(adminTab===t?' on':'')+'" onclick="setAdminTab(\''+t+'\')">'+
      {log:'📋 Log',players:'👥 Spieler',stats:'📊 Stats',tools:'🔧 Tools'}[t]+'</button>';
  });
  h+='</div><button class="admin-close" onclick="toggleAdmin()">✕</button></div>';
  h+='<div class="admin-body">';

  if(adminTab==='log'){
    h+='<div class="admin-section">Aktivitäts-Log ('+_adminLog.length+')</div>';
    h+='<div class="admin-log-controls"><button class="btn sm" onclick="clearAdminLog()">🗑️ Log leeren</button>';
    h+=' <button class="btn sm" onclick="exportAdminLog()">📥 Exportieren</button></div>';
    h+='<div class="admin-log">';
    _adminLog.slice(0,100).forEach(l=>{
      const d=new Date(l.ts);
      const ts=d.toLocaleString('de-DE',{hour:'2-digit',minute:'2-digit',second:'2-digit',day:'2-digit',month:'2-digit'});
      const typeC={game:'var(--a)',auth:'var(--go)',admin:'var(--bl)',error:'var(--r)'}[l.type]||'var(--td)';
      h+='<div class="admin-log-row"><span class="admin-log-ts">'+ts+'</span>';
      h+='<span class="admin-log-user">'+l.user+'</span>';
      h+='<span class="admin-log-type" style="color:'+typeC+'">'+l.type+'</span>';
      h+='<span class="admin-log-msg">'+l.msg+'</span></div>';
    });
    h+='</div>';

  } else if(adminTab==='players'){
    h+='<div class="admin-section">Registrierte Spieler ('+userKeys.length+')</div>';
    h+='<table class="admin-table"><tr><th>User</th><th>E-Mail</th><th>Erstellt</th><th>Aktion</th></tr>';
    for(const k of userKeys){
      const u=users[k];
      const created=u.created?new Date(u.created).toLocaleDateString('de-DE'):'—';
      h+='<tr><td><b>'+u.user+'</b></td><td>'+( u.email||'—')+'</td><td>'+created+'</td>';
      h+='<td><button class="btn sm" onclick="adminViewSave(\''+k+'\')">💾</button> ';
      if(k!=='test')h+='<button class="btn red sm" onclick="adminDeleteUser(\''+k+'\')">🗑️</button>';
      h+='</td></tr>';
    }
    h+='</table>';

  } else if(adminTab==='stats'){
    h+='<div class="admin-section">Server-Statistiken</div>';
    // Memory usage
    h+='<div class="admin-stat"><span>Spieler registriert</span><span>'+userKeys.length+'</span></div>';
    h+='<div class="admin-stat"><span>Route Cache</span><span>'+Object.keys(routeCache).length+' Einträge</span></div>';
    h+='<div class="admin-stat"><span>Such-Cache</span><span>'+Object.keys(_searchCache).length+' Einträge</span></div>';
    h+='<div class="admin-stat"><span>Admin Log</span><span>'+_adminLog.length+' Einträge</span></div>';
    // Current game stats if logged in
    if(G){
      h+='<div class="admin-section" style="margin-top:12px">Aktuelles Spiel ('+currentUser+')</div>';
      h+='<div class="admin-stat"><span>Tick</span><span>'+G.tick+'</span></div>';
      h+='<div class="admin-stat"><span>Geld</span><span>'+fmt(G.money)+'</span></div>';
      h+='<div class="admin-stat"><span>Unternehmenswert</span><span>'+fmt(companyValue())+'</span></div>';
      h+='<div class="admin-stat"><span>Städte</span><span>'+cities.length+'</span></div>';
      h+='<div class="admin-stat"><span>Fahrzeuge</span><span>'+G.vehs.length+'</span></div>';
      h+='<div class="admin-stat"><span>Gebäude</span><span>'+Object.values(G.blds).flat().length+'</span></div>';
      h+='<div class="admin-stat"><span>Lieferungen</span><span>'+G.dels+'</span></div>';
      h+='<div class="admin-stat"><span>Verdient</span><span>'+fmt(G.earned)+'</span></div>';
    }

  } else if(adminTab==='tools'){
    h+='<div class="admin-section">Admin-Tools</div>';
    h+='<div style="display:flex;flex-direction:column;gap:8px">';
    h+='<div class="crd"><div class="rw"><span>💰 Geld hinzufügen</span>';
    h+='<div style="display:flex;gap:4px"><input type="number" class="sl" id="adminMoney" value="100000" style="width:100px" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
    h+='<button class="btn sm" onclick="adminAddMoney()">Hinzufügen</button></div></div></div>';
    h+='<div class="crd"><div class="rw"><span>⏩ Ticks simulieren</span>';
    h+='<div style="display:flex;gap:4px"><input type="number" class="sl" id="adminTicks" value="3600" style="width:80px" onfocus="renderBlocked=true" onblur="renderBlocked=false"/>';
    h+='<button class="btn sm" onclick="adminSimTicks()">Ausführen</button></div></div></div>';
    h+='<div class="crd"><div class="rw"><span>🗑️ Route Cache</span>';
    h+='<button class="btn red sm" onclick="adminClearRouteCache()">Leeren ('+Object.keys(routeCache).length+')</button></div></div>';
    h+='<div class="crd"><div class="rw"><span>📦 Alle Lager füllen</span>';
    h+='<button class="btn sm" onclick="adminFillStorage()">+20 je Ware</button></div></div>';
    h+='<div class="crd"><div class="rw"><span>💾 Cache speichern</span>';
    h+='<button class="btn sm" onclick="saveCache().then(()=>alert(\'Gespeichert!\'))">Jetzt speichern</button></div></div>';
    h+='</div>';
  }

  h+='</div></div>';
  panel.innerHTML=h;
}

// Admin actions
function adminAddMoney(){
  if(!G)return;const v=parseInt(document.getElementById('adminMoney')?.value)||0;
  G.money+=v;adminLog('admin','💰 +'+fmt(v)+' hinzugefügt');uhud();renderAdmin();
}
function adminSimTicks(){
  if(!G)return;const n=parseInt(document.getElementById('adminTicks')?.value)||0;
  adminLog('admin','⏩ '+n+' Ticks simuliert');
  for(let i=0;i<Math.min(n,7200);i++)tickCore();
  uhud();markDirty();ren();renderAdmin();
}
function adminClearRouteCache(){
  for(const k in routeCache)delete routeCache[k];
  adminLog('admin','🗑️ Route Cache geleert');renderAdmin();
}
function adminFillStorage(){
  if(!G)return;
  cities.forEach(c=>{if(!G.stor[c.id])G.stor[c.id]={};
    Object.keys(GOODS).forEach(g=>{G.stor[c.id][g]=(G.stor[c.id][g]||0)+20})});
  adminLog('admin','📦 Alle Lager +20');uhud();markDirty();ren();renderAdmin();
}
function clearAdminLog(){_adminLog.length=0;saveAdminLog();renderAdmin()}
function exportAdminLog(){
  const blob=new Blob([JSON.stringify(_adminLog,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='logistix-admin-log.json';a.click();
}
async function adminViewSave(userKey){
  try{const raw=await storeGet('lx_save_'+userKey);
    if(!raw){alert('Kein Spielstand');return}
    const d=JSON.parse(raw);
    alert('Spielstand '+userKey+':\n\nGeld: '+fmt(d.money)+'\nTick: '+d.tick+'\nStädte: '+(d.unlockedCities||[]).length+'\nFahrzeuge: '+(d.vehs||[]).length+'\nGebäude: '+Object.values(d.blds||{}).flat().length+'\nLieferungen: '+(d.dels||0)+'\nVerdient: '+fmt(d.earned||0));
  }catch(e){alert('Fehler: '+e)}
}
async function adminDeleteUser(userKey){
  if(!confirm('Spieler "'+userKey+'" wirklich löschen?'))return;
  const users=await getUsers();delete users[userKey];await saveUsers(users);
  try{await storeDel('lx_save_'+userKey)}catch(e){}
  adminLog('admin','👥 Spieler gelöscht: '+userKey);
  renderAdmin();
}
