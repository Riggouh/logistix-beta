// ══════════════════════════════════════════
// CACHE SYSTEM – persistent route + search cache
// ══════════════════════════════════════════

const CACHE_KEY='lx_cache';
const CACHE_MAX_ROUTES=500;
const CACHE_MAX_SEARCH=200;
let _searchCache={};

// Save route cache + search cache to storage periodically
async function saveCache(){
  try{
    // Trim route cache to max size
    const rk=Object.keys(routeCache);
    if(rk.length>CACHE_MAX_ROUTES){rk.slice(0,rk.length-CACHE_MAX_ROUTES).forEach(k=>delete routeCache[k])}
    // Trim search cache
    const sk=Object.keys(_searchCache);
    if(sk.length>CACHE_MAX_SEARCH){sk.slice(0,sk.length-CACHE_MAX_SEARCH).forEach(k=>delete _searchCache[k])}
    const data={routes:routeCache,search:_searchCache,ts:Date.now()};
    await storeSet(CACHE_KEY,JSON.stringify(data));
  }catch(e){}
}

async function loadCache(){
  try{
    const raw=await storeGet(CACHE_KEY);if(!raw)return;
    const data=JSON.parse(raw);
    // Only use cache if less than 7 days old
    if(data.ts&&Date.now()-data.ts>7*86400000)return;
    if(data.routes){Object.assign(routeCache,data.routes)}
    if(data.search){_searchCache=data.search}
  }catch(e){}
}

// Cached Nominatim search wrapper
function getCachedSearch(q){
  const k=q.toLowerCase().trim();
  if(_searchCache[k]&&Date.now()-_searchCache[k].ts<86400000)return _searchCache[k].data;
  return null;
}
function setCachedSearch(q,data){
  _searchCache[q.toLowerCase().trim()]={data,ts:Date.now()};
}
